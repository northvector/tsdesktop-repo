// Sends files straight to other TeamSpeak Desktop users over App.p2p: no upload permission, quota or size
// limit on the server, encrypted end to end. Received files go to the Downloads folder. Files need a
// direct route or a TURN relay; over the TeamSpeak server alone (both behind CGNAT, no relay) they can't go.

// By `connection:clientId`: the person, the session with them, a request of theirs, whether the file
// picker opens once the session does, when we asked (for "waiting 12 s"), and a note about how it went.
const people = new Map();
// Starting P2P right away lets others find us before the panel is ever opened.
App.p2p.peers();

const keyOf = (connection, clientId) => `${connection}:${clientId}`;
const person = (connection, clientId, name) => {
  const k = keyOf(connection, clientId);
  if (!people.has(k)) people.set(k, { key: k, connection, clientId, name, session: null, route: null, request: null, wantSend: false, since: 0, note: null });
  const p = people.get(k);
  if (name) p.name = name;
  return p;
};
const bySession = (session) => [...people.values()].find((p) => p.session === session || p.request === session);
const NO_ROUTE = "No direct route to them, and files can't go through the TeamSpeak server. Both of you can add a TURN relay in Settings > Plugins > P2P connections.";

const size = (n) => {
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
  return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
};
const duration = (s) => (s < 60 ? `${Math.ceil(s)} s` : s < 3600 ? `${Math.floor(s / 60)} min ${Math.round(s % 60)} s` : `${Math.floor(s / 3600)} h ${Math.round((s / 60) % 60)} min`);
const ago = (t) => Math.floor((Date.now() - t) / 1000);

const pick = (p) => {
  if (p.route === "server") return (p.note = { text: NO_ROUTE, color: "orange" });
  try {
    App.p2p.sendFile(p.session);
  } catch (e) {
    p.note = { text: `Couldn't send: ${e.message}`, color: "red" };
  }
};

const sendTo = (p) => {
  p.note = null;
  if (p.route) return pick(p);
  p.wantSend = true;
  if (p.session) return;
  try {
    p.session = App.p2p.connect(p.connection, p.clientId);
    p.since = Date.now();
  } catch (e) {
    p.wantSend = false;
    p.note = { text: `Couldn't reach them: ${e.message}`, color: "red" };
  }
};

const cancel = (p) => {
  p.wantSend = false;
  if (p.session) App.p2p.close(p.session);
};

App.events.on("p2p.request", (r) => {
  const p = person(r.connection, r.clientId, r.name);
  p.request = r.session;
  p.since = Date.now();
  App.ui.notify(`${r.name} wants to send you files`);
  App.ui.open("files");
});
App.events.on("p2p.open", ({ session, route }) => {
  const p = bySession(session);
  if (!p || p.session !== session) return;
  p.route = route;
  if (p.wantSend) {
    p.wantSend = false;
    pick(p);
  }
});
App.events.on("p2p.closed", ({ session, reason }) => {
  const p = bySession(session);
  if (!p) return;
  if (p.request === session) p.request = null;
  if (p.session !== session) return;
  if (p.wantSend) p.note = { text: reason === "declined" ? `${p.name} declined.` : `Didn't connect${reason ? `: ${reason}` : ""}.`, color: "red" };
  Object.assign(p, { session: null, route: null, wantSend: false });
});
App.events.on("p2p.file", (f) => {
  const p = bySession(f.session);
  App.ui.notify(`${p ? p.name : "Someone"} wants to send you ${f.name} (${size(f.size)})`);
  App.ui.open("files");
});
App.events.on("p2p.fileDone", (d) => {
  if (d.ok && d.path) App.ui.notify(`Saved ${d.path}`);
});

const accept = (p) => {
  if (p.session && p.session !== p.request) App.p2p.close(p.session);
  p.session = p.request;
  p.request = null;
  p.since = Date.now();
  App.p2p.accept(p.session);
};
const decline = (p) => {
  App.p2p.close(p.request);
  p.request = null;
};

// Transfer speed by file, smoothed: { done, at, rate } (bytes a second).
const speeds = new Map();
const speedOf = (s, f) => {
  const k = `${s.id}/${f.id}`;
  const t = Date.now();
  const was = speeds.get(k);
  if (!was) return speeds.set(k, { done: f.done, at: t, rate: 0 }), 0;
  if (t - was.at >= 500) {
    const rate = ((f.done - was.done) * 1000) / (t - was.at);
    speeds.set(k, { done: f.done, at: t, rate: was.rate ? was.rate * 0.6 + rate * 0.4 : rate });
  }
  return speeds.get(k).rate;
};

const ROUTE = { direct: "direct connection", relay: "through a TURN relay" };

// One person: who, what is happening with them right now, and the one thing to do about it.
const personRow = (p, sess) => {
  const st = sess ? sess.status : "";
  const busy = !!p.session && !p.route;
  const line =
    st === "waiting" ? { text: `Waiting for ${p.name} to accept · ${ago(p.since)} s`, color: "dim" }
    : st === "connecting" ? { text: `Connecting · finding a route · ${ago(p.since)} s`, color: "dim" }
    : p.route === "server" ? { text: "Connected through the server only: files can't go this way", color: "orange" }
    : p.route ? { text: `Connected · ${ROUTE[p.route] || p.route}`, color: "green" }
    : null;
  return {
    type: "group",
    children: [
      {
        type: "bar",
        left: [busy && { type: "spinner" }, { type: "label", text: p.name, strong: true }],
        right: [
          busy
            ? { type: "button", label: "Cancel", onClick: () => cancel(p) }
            : { type: "button", label: "Send files…", variant: "filled", enabled: p.route !== "server", onClick: () => sendTo(p) },
        ],
      },
      line && { type: "label", text: line.text, color: line.color, small: true },
      st === "waiting" && ago(p.since) > 10 && { type: "label", text: "They get a notification and have two minutes to accept.", color: "dim", small: true },
      p.note && { type: "label", text: p.note.text, color: p.note.color, small: true },
    ],
  };
};

const STATUS = { offered: "Waiting for them to accept", sending: "Sending", receiving: "Receiving", done: "Done", failed: "Failed", declined: "Declined", cancelled: "Cancelled" };

// A file someone offers us: it waits for an answer, so it goes at the top.
const offerCard = (s, f, name) => ({
  type: "group",
  children: [
    { type: "label", text: `${name} wants to send you a file`, strong: true },
    { type: "label", text: `${f.name}  ·  ${size(f.size)}`, color: "dim" },
    { type: "space", size: 6 },
    { type: "row", children: [
      { type: "button", label: "Save to Downloads", variant: "filled", onClick: () => App.p2p.acceptFile(s.id, f.id) },
      { type: "button", label: "Decline", width: 96, height: 36, onClick: () => App.p2p.cancelFile(s.id, f.id) },
    ] },
  ],
});

const fileRow = (s, f, name) => {
  const active = ["sending", "receiving"].includes(f.status);
  const rate = active ? speedOf(s, f) : 0;
  const pct = f.size ? f.done / f.size : 0;
  const detail = active
    ? `${size(f.done)} of ${size(f.size)}${rate > 0 ? ` · ${size(rate)}/s · ${duration((f.size - f.done) / rate)} left` : ""}`
    : `${size(f.size)} · ${STATUS[f.status] || f.status}${f.error && !["declined", "cancelled"].includes(f.status) ? `: ${f.error}` : ""}`;
  return {
    type: "group",
    children: [
      {
        type: "bar",
        left: [{ type: "label", text: `${f.incoming ? "↓" : "↑"}  ${f.name}`, strong: true }],
        right: [
          (active || f.status === "offered") && { type: "button", label: "Cancel", onClick: () => App.p2p.cancelFile(s.id, f.id) },
          f.status === "done" && f.incoming && { type: "button", label: "Show in folder", onClick: () => App.p2p.showFile(s.id, f.id) },
        ],
      },
      { type: "label", text: `${f.incoming ? "From" : "To"} ${name} · ${detail}`, color: f.status === "failed" ? "red" : f.status === "done" ? "green" : "dim", small: true },
      active && { type: "progress", value: pct, text: `${Math.floor(pct * 100)} %` },
      f.status === "offered" && { type: "row", children: [{ type: "spinner" }, { type: "label", text: `Waiting for ${name} to save it`, color: "dim", small: true }] },
    ],
  };
};

App.ui.registerPanel({
  id: "files",
  title: "Direct files",
  width: 560,
  height: 520,
  render: () => {
    const peers = App.p2p.peers();
    for (const p of peers) person(p.connection, p.clientId, p.name);
    const here = new Set(peers.map((p) => keyOf(p.connection, p.clientId)));
    const sessions = App.p2p.sessions();
    const sessionOf = new Map(sessions.map((s) => [s.id, s]));
    const nameOf = (s) => (people.get(keyOf(s.connection, s.clientId)) || s).name || "?";
    const requests = [...people.values()].filter((p) => p.request);
    const all = sessions.flatMap((s) => s.files.map((f) => ({ s, f }))).reverse();
    const offers = all.filter((x) => x.f.status === "incoming");
    const files = all.filter((x) => x.f.status !== "incoming");
    const list = [...people.values()].filter((p) => here.has(p.key) || p.session);
    return [
      requests.map((p) => ({
        type: "group",
        children: [
          { type: "label", text: `${p.name} wants to send you files`, strong: true },
          { type: "label", text: `Asked ${ago(p.since)} s ago. Accepting connects you straight to them, so they can see your IP address (unless Relay only is on in Settings > Plugins).`, color: "dim", small: true },
          { type: "space", size: 6 },
          { type: "row", children: [
            { type: "button", label: "Accept", variant: "filled", onClick: () => accept(p) },
            { type: "button", label: "Decline", width: 96, height: 36, onClick: () => decline(p) },
          ] },
        ],
      })),
      offers.map(({ s, f }) => offerCard(s, f, nameOf(s))),
      { type: "heading", text: "Send to" },
      list.length
        ? list.map((p) => personRow(p, sessionOf.get(p.session)))
        : { type: "label", text: "Nobody on your servers runs TeamSpeak Desktop with Direct files yet. They show up here once they do.", color: "dim" },
      files.length > 0 && [{ type: "space", size: 6 }, { type: "heading", text: "Transfers" }, { type: "scroll", children: files.map(({ s, f }) => fileRow(s, f, nameOf(s))) }],
    ];
  },
});
App.ui.registerMenu({ id: "files", label: "Direct files", icon: "📨", onClick: () => App.ui.toggle("files") });
