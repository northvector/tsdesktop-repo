// Screen sharing through an OmeGa Meet server (https://meet.ts22.ir by default), in the info panel. You go
// to the room of your TeamSpeak channel (same name and password) under your nickname; browsers can join too.
const saved = App.storage.create("screenshare");
let server = saved.get("server", "https://meet.ts22.ir");
let monitor = saved.get("monitor", 0);
// A window to share instead of a screen (its id, for this run of the app only); null for the screen.
let win = null;
let height = saved.get("height", 720);
let fps = saved.get("fps", 30);
let encoder = saved.get("encoder", "gpu");
let audio = saved.get("audio", true);
let camera = saved.get("camera", 0);
// Video kbps, 0 for one fitting the size.
let bitrate = saved.get("bitrate", 0);
// "thumbs": small pictures, as many to a row as fit; "side": all side by side across the panel.
let layout = saved.get("layout", "thumbs");
// Choices saved by earlier versions that the toggles no longer offer: the nearest one that is.
const nearest = (v, list) => list.reduce((a, b) => (Math.abs(b - v) < Math.abs(a - v) ? b : a));
height = nearest(height, [480, 720, 1080, 4320]);
fps = nearest(fps, [15, 30, 60]);
// Bitrates offered as toggles; any other is typed in as a custom one (Mbps).
const PRESETS = [2500, 4000, 8000, 12000, 20000];
let custom = bitrate && !PRESETS.includes(bitrate) ? String(bitrate / 1000) : null;
let newRoom = "";
let password = "";
// Connect once by ourselves when the panel first shows; after that only on request.
let autoConnect = true;
// The channel whose room we went to, and on which server; moving to another channel there takes us to
// its room, while switching the active server tab keeps us where we are.
let followed = null;
let followedConn = null;
// Every share is watched as it appears, apart from the ones stopped; `asked` keeps a watch from being
// asked for twice. Both are for the room in `forRoom`.
let asked = new Set();
let stopped = new Set();
let forRoom = null;

// Where we are on TeamSpeak: our nickname and the name of our channel, for the room; on the server we
// followed while it is still open, else the active one.
const here = () => {
  const s = App.app.state();
  const c = s.connections.find((c) => c.id === followedConn) || s.connections.find((c) => c.id === s.active) || s.connections[0];
  if (!c) return { nick: "", channel: "", conn: null };
  const me = c.clients.find((x) => x.id === c.ownClientId);
  const ch = c.channels.find((x) => x.id === c.channelId);
  return { nick: me ? me.name : "", channel: ch ? ch.name : "", conn: c.id };
};

// Our TeamSpeak nickname, or the last one used while not connected.
const nick = () => {
  const n = here().nick;
  if (n && n !== saved.get("nick", "")) saved.set("nick", n);
  return n || saved.get("nick", "") || "TeamSpeak user";
};

const connect = () => {
  saved.set("server", server);
  followed = null;
  followedConn = null;
  App.meet.connect(server, nick());
};

const joinOrCreate = (roomName) => App.meet.enter(roomName, password);

const share = () => {
  saved.set("monitor", monitor);
  saved.set("height", height);
  saved.set("fps", fps);
  saved.set("encoder", encoder);
  saved.set("audio", audio);
  saved.set("bitrate", bitrate);
  App.meet.share({ ...(win == null ? { monitor } : { window: win }), height, fps, encoder, audio, bitrate });
};

// The camera goes out at the screen's quality and frame rate, at most 1080p.
const shareCamera = () => {
  saved.set("camera", camera);
  App.meet.shareCamera({ camera, height: Math.min(height, 1080), fps, encoder, bitrate });
};

// A small caption over a set of controls, with more room above it than below.
const heading = (text) => ({ type: "label", text, small: true, color: "dim" });
const field = (text, ...controls) => [{ type: "space", size: 10 }, heading(text), { type: "space", size: 2 }, ...controls];

const lobby = (st) => {
  const { channel, conn } = here();
  return [
    {
      type: "row",
      children: [
        { type: "label", text: `Connected to ${st.server} as ${st.name}`, color: "dim", small: true },
        { type: "link", text: "Disconnect", onClick: () => App.meet.disconnect() },
      ],
    },
    channel && [
      { type: "space", size: 6 },
      { type: "button", variant: "filled", width: "fill", label: `Join the room of "${channel}"`, tooltip: "With the channel's password, if you typed one", onClick: () => { followed = channel; followedConn = conn; App.meet.enterChannel(conn); } },
    ],
    field(
      "ROOMS",
      st.rooms.length
        ? st.rooms.map((r) => ({
            type: "row",
            children: [
              { type: "button", label: "Join", onClick: () => App.meet.join(r.id, password) },
              { type: "label", text: `${r.isPrivate ? "🔒 " : ""}${r.name} · ${r.participantCount} in it${r.participantNames.length ? `: ${r.participantNames.join(", ")}` : ""}` },
            ],
          }))
        : { type: "label", text: "No rooms yet.", color: "faint" },
      { type: "input", value: password, hint: "Password, for private rooms", password: true, width: 240, onChange: (v) => (password = v) },
    ),
    field("NEW ROOM", {
      type: "row",
      children: [
        { type: "input", value: newRoom, hint: "Room name", width: 160, onChange: (v) => (newRoom = v), onSubmit: () => newRoom.trim() && joinOrCreate(newRoom.trim()) },
        { type: "button", label: "Create", enabled: !!newRoom.trim(), onClick: () => joinOrCreate(newRoom.trim()) },
      ],
    }),
  ];
};

// The typed custom bitrate in kbps, kept between 0.25 and 50 Mbps; 0 (auto) while it isn't a number.
const customKbps = () => {
  const m = parseFloat(String(custom).replace(",", "."));
  return m > 0 ? Math.round(Math.min(50, Math.max(0.25, m)) * 1000) : 0;
};

// Choices as round toggles.
const pills = (value, options, set) => ({
  type: "row",
  children: options.map((o) => ({ type: "button", variant: "pill", label: o.label, tooltip: o.tooltip, selected: value === o.value, onClick: () => set(o.value) })),
});

// A picture with who it is and what it is, and a button under it.
const tile = (who, what, stream, button) => ({
  type: "column",
  children: [
    { type: "row", children: [{ type: "label", text: who, strong: true, small: true }, what && { type: "label", text: what, small: true, color: "dim" }] },
    stream ? { type: "video", stream, height: layout === "thumbs" ? 140 : undefined } : { type: "label", text: "Not watching", color: "faint" },
    button,
  ],
});

// The screens as small pictures to pick from, the chosen one ringed in the accent colour.
const screenPicker = () =>
  ({
    type: "row",
    children: App.meet.monitors().map((m) => {
      const on = win == null && monitor === m.index;
      return {
        type: "column",
        children: [
          { type: "video", stream: m.thumb, height: 72, controls: false, selected: on, tooltip: `${m.width}×${m.height}`, onClick: () => { monitor = m.index; win = null; } },
          { type: "label", text: m.name || `Screen ${m.index + 1}`, small: true, color: on ? "accent" : "dim" },
        ],
      };
    }),
  });

// Or one window, by its title; a window that closed goes back to the screen.
const windowPicker = () => {
  const wins = App.meet.windows();
  if (win != null && !wins.some((w) => w.id === win)) win = null;
  return {
    type: "select",
    value: win,
    options: [{ value: null, label: "Whole screen (above)" }, ...wins.map((w) => ({ value: w.id, label: `${w.title.length > 50 ? `${w.title.slice(0, 49)}…` : w.title}${w.app ? ` · ${w.app}` : ""}` }))],
    onChange: (v) => (win = v),
  };
};

const room = (st) => {
  const videos = st.peers.flatMap((p) => p.streams.filter((s) => s.kind === "video").map((s) => ({ ...s, peer: p.name })));
  if (forRoom !== st.room.id) {
    forRoom = st.room.id;
    asked = new Set();
    stopped = new Set();
  }
  for (const v of videos) {
    if (!asked.has(v.producerId) && !stopped.has(v.producerId)) {
      asked.add(v.producerId);
      App.meet.watch(v.producerId);
    }
  }
  const tiles = videos.map((v) => {
    const what = `${v.source === "camera" ? "camera" : "screen"}${v.width ? ` · ${v.width}×${v.height}` : ""}`;
    return stopped.has(v.producerId)
      ? tile(v.peer, what, null, { type: "button", label: "Watch", onClick: () => { stopped.delete(v.producerId); asked.delete(v.producerId); } })
      : tile(v.peer, what, v.producerId, { type: "button", label: "Stop watching", tooltip: "Stop watching (and hearing) this share", onClick: () => { stopped.add(v.producerId); App.meet.unwatch(v.producerId); } });
  });
  if (st.camera) {
    tiles.unshift(tile("You", "camera", "local-camera", { type: "button", label: "Stop camera", primary: true, onClick: () => App.meet.stopCamera() }));
  }
  if (st.sharing) {
    const how = [st.encoder, st.bitrate && `${(st.bitrate / 1000).toFixed(1)} Mbps`, st.sharingSound && "with sound"].filter(Boolean).join(" · ");
    tiles.unshift(tile("You", how, "local", { type: "button", label: "Stop sharing", primary: true, onClick: () => App.meet.stopShare() }));
  }
  const cameras = st.camera ? [] : App.meet.cameras();
  const setLayout = (v) => { layout = v; saved.set("layout", v); };
  const others = st.peers.length;
  return [
    {
      type: "row",
      children: [
        { type: "label", text: st.room.name, strong: true },
        { type: "label", text: others ? `· ${others} other${others === 1 ? "" : "s"} here` : "· just you", color: "dim", small: true },
        { type: "button", label: "Leave", onClick: () => App.meet.leave() },
      ],
    },
    { type: "separator" },
    tiles.length
      ? [
          pills(layout, [{ value: "thumbs", label: "Thumbnails", tooltip: "Small pictures, as many to a row as fit" }, { value: "side", label: "Side by side", tooltip: "All in one row across the panel" }], setLayout),
          { type: "space", size: 6 },
          { type: "grid", fill: true, columns: tiles.length, minWidth: layout === "thumbs" ? 180 : 40, children: tiles },
        ]
      : { type: "label", text: others ? "Nobody else is sharing." : "Nobody else is here yet.", color: "faint" },
    !st.sharing && [
      { type: "space", size: 12 },
      {
        type: "group",
        children: [
          { type: "label", text: "Share your screen", strong: true },
          field("SCREEN", screenPicker()),
          field("OR A WINDOW", windowPicker()),
          field("QUALITY", pills(height, [{ value: 480, label: "480p" }, { value: 720, label: "720p" }, { value: 1080, label: "1080p" }, { value: 4320, label: "Native" }], (v) => (height = v))),
          field("FRAME RATE", pills(fps, [15, 30, 60].map((f) => ({ value: f, label: `${f} fps` })), (v) => (fps = v))),
          { type: "space", size: 8 },
          { type: "checkbox", label: "Share sound", checked: audio, onChange: (v) => (audio = v) },
          { type: "space", size: 4 },
          {
            type: "collapsing",
            title: "Advanced",
            children: [
              heading("BITRATE"),
              pills(custom === null ? bitrate : "custom", [{ value: 0, label: "Auto", tooltip: "One fitting the size" }, ...PRESETS.map((k) => ({ value: k, label: `${k / 1000} Mbps` })), { value: "custom", label: "Custom" }], (v) => {
                if (v === "custom") custom = custom ?? String(bitrate / 1000 || 6);
                else (custom = null), (bitrate = v);
                if (custom !== null) bitrate = customKbps();
              }),
              custom !== null && {
                type: "row",
                children: [
                  { type: "input", value: custom, hint: "6", width: 70, onChange: (v) => { custom = v; bitrate = customKbps(); } },
                  { type: "label", text: `Mbps (0.25–50)${bitrate ? `: ${bitrate / 1000} Mbps` : ""}`, color: "dim", small: true },
                ],
              },
              field("ENCODER", pills(encoder, [
                { value: "gpu", label: "GPU", tooltip: "H.264 on the graphics card (NVIDIA, Intel, AMD)" },
                { value: "h264", label: "CPU", tooltip: "H.264 in software" },
                { value: "vp8", label: "VP8", tooltip: "6 Mbps at most" },
              ], (v) => (encoder = v))),
            ],
          },
          { type: "space", size: 10 },
          { type: "button", variant: "filled", width: "fill", label: win == null ? "🖥  Share Screen" : "🗔  Share Window", onClick: share },
        ],
      },
    ],
    cameras.length > 0 && [
      { type: "space", size: 12 },
      {
        type: "group",
        children: [
          { type: "label", text: "Share your camera", strong: true },
          field("CAMERA", pills(camera, cameras.map((c) => ({ value: c.index, label: c.name })), (v) => (camera = v))),
          { type: "space", size: 10 },
          { type: "button", variant: "filled", width: "fill", label: "📷  Share Camera", tooltip: "Beside your screen, or on its own", onClick: shareCamera },
        ],
      },
    ],
  ];
};

App.ui.registerPanel({
  id: "screenshare",
  title: "Screen Share",
  dock: "info",
  render: () => {
    const st = App.meet.state();
    if (st.status === "idle" && autoConnect) {
      autoConnect = false;
      connect();
    }
    // Into the room of our channel when connected, and again whenever we move to another channel.
    const { channel, conn } = here();
    if (st.status === "connected" && channel && channel !== followed) {
      followed = channel;
      followedConn = conn;
      App.meet.enterChannel(conn);
    }
    const error = st.error && { type: "label", text: st.error, color: "red" };
    if (st.status === "connecting") return { type: "label", text: `Connecting to ${server}…`, color: "dim" };
    if (st.status !== "connected") {
      return [
        { type: "label", text: `Share your screen with your channel through an OmeGa Meet server, as ${nick()}.` },
        field("SERVER", {
          type: "row",
          children: [
            { type: "input", value: server, hint: "https://…", width: 240, onChange: (v) => (server = v), onSubmit: connect },
            { type: "button", label: "Connect", primary: true, enabled: !!server.trim(), onClick: connect },
          ],
        }),
        error && [{ type: "space", size: 4 }, error],
      ];
    }
    return [error, st.room ? room(st) : lobby(st)];
  },
});

App.ui.registerMenu({ id: "screenshare", label: "Screen share", icon: "🖥", onClick: () => App.ui.toggle("screenshare") });
