// @ts-check
/// <reference path="../../app.d.ts" />
// Broadside: a two-player fleet-hunting game over App.p2p. Each side keeps its own fleet secret and
// answers the other's shots: {t:"ready"}, {t:"shot", c}, {t:"res", c, hit, sunk?: cells}, {t:"fleet", cells}
// (the winner shows what was left) and {t:"again"}. A hit shoots again; a sunk ship's surroundings are
// marked for both, since ships never touch. Whoever invited fires first, then you take turns starting.
// shortcut: each side trusts the other's answers, so a cheat could call every shot a miss; fine among friends, commit to a hashed fleet before the first shot for strangers.

const N = 10;
const FLEET = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1];
const COLS = "ABCDEFGHIJ";
const nameOf = (c) => `${COLS[c % N]}${Math.floor(c / N) + 1}`;

// ---- rules. A cell is r * 10 + c; a ship is its cells, bow first ----

/** @returns {number[] | null} null when it leaves the sea. */
const shipAt = (c, r, len, across) => (c < 0 || r < 0 || (across ? c + len > N || r >= N : r + len > N || c >= N) ? null : Array.from({ length: len }, (_, i) => (across ? r * N + c + i : (r + i) * N + c)));
/** The cells and everything touching them, corners too. */
const around = (cells) => {
  const out = new Set();
  for (const x of cells) for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
    const c = (x % N) + dc, r = Math.floor(x / N) + dr;
    if (c >= 0 && c < N && r >= 0 && r < N) out.add(r * N + c);
  }
  return out;
};
const fits = (ships, cells) => {
  if (!cells) return false;
  const zone = around(cells);
  return !ships.some((s) => s.some((x) => zone.has(x)));
};
const randomFleet = () => {
  for (;;) {
    /** @type {number[][]} */
    const ships = [];
    for (const len of FLEET) {
      let cells = null;
      for (let tries = 0; tries < 200 && !fits(ships, cells); tries++) cells = shipAt(Math.floor(Math.random() * N), Math.floor(Math.random() * N), len, Math.random() < 0.5);
      if (!fits(ships, cells)) break; // boxed in: start over
      ships.push(/** @type {number[]} */ (cells));
    }
    if (ships.length === FLEET.length) return ships;
  }
};

/**
 * `mine`: their shots at my sea (0 none, 1 miss, 2 hit). `theirs`: what I know of their sea (0 unknown,
 * 1 miss, 2 hit, 3 sunk, 4 shown after the game). `pending`: my shot waiting for its answer; `sunk`: the lengths of their ships I sank.
 * @typedef {{ phase: "place" | "play" | "over"; ships: number[][]; mine: number[]; theirs: number[]; ready: boolean; theirReady: boolean; turn: "me" | "them"; pending: number; sunk: number[]; won: boolean; games: number; inviter: boolean; sel: number }} Game
 */
/** @returns {Game} */
const newGame = (inviter, games = 0) => ({ phase: "place", ships: randomFleet(), mine: Array(N * N).fill(0), theirs: Array(N * N).fill(0), ready: false, theirReady: false, turn: "me", pending: -1, sunk: [], won: false, games, inviter, sel: -1 });
const isInt = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
const begin = (g) => {
  if (g.phase === "place" && g.ready && g.theirReady) Object.assign(g, { phase: "play", sel: -1, turn: g.inviter === (g.games % 2 === 0) ? "me" : "them" });
};
/** Their shot at my sea: the answer to send, or null when it isn't a legal shot. */
const takeShot = (g, c) => {
  if (g.phase !== "play" || g.turn !== "them" || !isInt(c, 0, N * N - 1) || g.mine[c]) return null;
  const ship = g.ships.find((s) => s.includes(c));
  g.mine[c] = ship ? 2 : 1;
  if (!ship) return (g.turn = "me"), { t: "res", c, hit: false };
  if (!ship.every((x) => g.mine[x] === 2)) return { t: "res", c, hit: true };
  for (const x of around(ship)) if (!g.mine[x]) g.mine[x] = 1;
  if (g.ships.every((s) => s.every((x) => g.mine[x] === 2))) g.phase = "over";
  return { t: "res", c, hit: true, sunk: ship };
};
/** The answer to my shot; false when it isn't one. */
const takeResult = (g, m) => {
  if (g.phase !== "play" || g.turn !== "me" || m.c !== g.pending || g.pending < 0 || typeof m.hit !== "boolean") return false;
  const c = g.pending;
  if (m.sunk !== undefined && !(m.hit && Array.isArray(m.sunk) && isInt(m.sunk.length, 1, 4) && m.sunk.includes(c) && m.sunk.every((x) => isInt(x, 0, N * N - 1) && (x === c || g.theirs[x] === 2)))) return false;
  g.pending = -1;
  g.theirs[c] = m.hit ? 2 : 1;
  if (!m.hit) g.turn = "them";
  if (m.sunk) {
    for (const x of around(m.sunk)) if (!g.theirs[x]) g.theirs[x] = 1;
    for (const x of m.sunk) g.theirs[x] = 3;
    if (g.sunk.push(m.sunk.length) === FLEET.length) Object.assign(g, { phase: "over", won: true });
  }
  return true;
};

// Self-check of the fleet and a whole game.
{
  const ok = (c, what) => c || App.log(`Broadside: ${what} is broken`);
  const a = newGame(true), b = newGame(false);
  ok(a.ships.length === 10 && new Set(a.ships.flat()).size === 20 && a.ships.every((s, i) => s.length === FLEET[i] && fits(a.ships.filter((o) => o !== s), s)), "randomFleet");
  ok(shipAt(8, 0, 3, true) === null && String(shipAt(0, 7, 3, false)) === "70,80,90" && around([0]).size === 4, "shipAt/around");
  a.ready = a.theirReady = b.ready = b.theirReady = true;
  begin(a), begin(b);
  ok(a.turn === "me" && b.turn === "them", "begin");
  let shots = 0;
  for (let c = 0; c < N * N && a.phase === "play"; c++) {
    if (a.theirs[c]) continue;
    Object.assign(a, { turn: "me", pending: c }), (b.turn = "them"), shots++;
    const res = takeShot(b, c);
    ok(res && takeResult(a, JSON.parse(JSON.stringify(res))), `shot ${c}`);
  }
  ok(a.won && a.sunk.length === 10 && b.phase === "over" && !b.won && shots < 100 && takeShot(b, 99) === null, "a whole game");
}

// ---- network: one match at a time ----

/** @type {null | { name: string; session: string | null; open: boolean; g: Game; note: string }} */
let match = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const send = (msg, tries = 0) => {
  const session = match?.open && match.session;
  if (!session) return;
  try {
    App.p2p.send(session, typeof msg === "string" ? msg : (msg = JSON.stringify(msg)));
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => match?.session === session && send(msg, tries + 1), 500);
    else App.log(`Broadside: not sent: ${e.message}`);
  }
};
const leave = () => {
  if (match?.session) App.p2p.close(match.session);
  match = null;
  fx = [];
};
const invite = (peer) => {
  leave();
  try {
    match = { name: peer.name, session: App.p2p.connect(peer.connection, peer.clientId), open: false, g: newGame(true), note: "" };
  } catch (e) {
    App.ui.notify(`Can't reach ${peer.name}: ${e.message}`, "error");
  }
};
const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  match = { name: req.name, session: req.session, open: false, g: newGame(false), note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};

// The local player's moves.
const ready = () => {
  if (!match || match.g.phase !== "place" || match.g.ready) return;
  match.g.ready = true;
  send({ t: "ready" });
  begin(match.g);
  if (match.g.phase === "play") started();
};
const fire = (c) => {
  const g = match?.g;
  if (!g || !match?.open || g.phase !== "play" || g.turn !== "me" || g.pending >= 0 || g.theirs[c]) return;
  g.pending = c;
  sfx("fire", 0.5);
  send({ t: "shot", c });
};
const again = () => {
  if (!match || match.g.phase !== "over") return;
  send({ t: "again" });
  rematch();
};
const rematch = () => {
  if (!match) return;
  match.g = newGame(match.g.inviter, match.g.games + 1);
  fx = [];
};
const started = () => match && match.g.turn === "me" && sfx("ping", 0.45);
const finished = (won) => setTimeout(() => sfx(won ? "win" : "lose", 0.6), 700);

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} challenges you to Broadside`);
  App.ui.open("broadside");
});
App.events.on("p2p.open", ({ session }) => {
  if (match?.session === session) match.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  if (match?.session !== session) return;
  // The app answers this way when their side doesn't run Broadside: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? `${match.name} doesn't have Broadside installed and enabled.` : match.open ? `${match.name} left${reason ? ` (${reason})` : ""}.` : `Couldn't connect to ${match.name}${reason ? ` (${reason})` : ""}.`;
  Object.assign(match, { session: null, open: false, note: why });
});
App.events.on("p2p.message", ({ session, data }) => {
  if (match?.session !== session) return;
  const g = match.g;
  let m;
  try {
    m = JSON.parse(data);
  } catch {
    return;
  }
  if (m?.t === "ready" && g.phase === "place" && !g.theirReady) {
    g.theirReady = true;
    begin(g);
    if (g.phase === "play") started();
  } else if (m?.t === "shot") {
    const res = takeShot(g, m.c);
    if (!res) return;
    send(res);
    boom("mine", res);
    if (g.phase === "over") finished(false);
    else if (!res.hit) setTimeout(started, 600);
  } else if (m?.t === "res") {
    if (!takeResult(g, m)) return;
    boom("theirs", m);
    if (g.won) finished(true), send({ t: "fleet", cells: g.ships.flat().filter((x) => g.mine[x] !== 2) });
  } else if (m?.t === "fleet" && g.phase === "over" && !g.won && Array.isArray(m.cells) && m.cells.length <= 20) {
    for (const x of m.cells) if (isInt(x, 0, N * N - 1) && !g.theirs[x]) g.theirs[x] = 4;
  } else if (m?.t === "again" && g.phase === "over") {
    rematch();
    App.ui.notify(`${match.name} wants a rematch`);
  }
});

// ---- view ----

const SEA = "#12344f", SEA_LIT = "#1b4a6e", HULL = "#93a7b8", HULL_SEL = "#e3b23c", INK = "#16242f";
const FIRE = "#e8590c", WRECK = "#7d2020", FOAM = "#7fb2d6", GHOST = "#4a6278";

// Sound effects on your own speakers only (never the mic), synthesized into sounds/ by the author.
// shortcut: mute lasts until the plugin restarts; keep it in App.storage if people ask (a new permission).
let muted = false;
const sfx = (name, volume = 0.5) => {
  if (muted) return;
  try {
    App.audio.play(`sounds/${name}.wav`, { volume, mic: false });
  } catch (e) {
    App.log(`Broadside: no sound: ${e.message}`);
  }
};

// A shot's answer plays out on its cell: a blast or a ripple, a sunk ship flashing along its length.
/** @type {{ board: "mine" | "theirs"; cells: number[]; kind: "hit" | "miss" | "sunk"; start: number }[]} */
let fx = [];
const FX_MS = { hit: 600, miss: 550, sunk: 1300 };
const boom = (board, res) => {
  const kind = res.sunk ? "sunk" : res.hit ? "hit" : "miss";
  fx.push({ board, cells: res.sunk || [res.c], kind, start: Date.now() });
  sfx(kind === "miss" ? "splash" : kind, kind === "sunk" ? 0.7 : 0.55);
};
/** The glyph playing on this cell right now, if any. */
const effect = (board, c, now) => {
  const e = fx.find((e) => e.board === board && e.cells.includes(c));
  if (!e) return null;
  const t = (now - e.start) / FX_MS[e.kind];
  if (e.kind === "miss") return { label: "○", color: FOAM, size: Math.round(8 + 20 * t) };
  if (e.kind === "hit") return { label: "✹", color: t < 0.5 ? "#ffd43b" : "#ffffff", size: Math.round(10 + 22 * Math.sin(t * Math.PI)), fill: FIRE };
  return { label: Math.floor(t * 8) % 2 ? "✹" : "✕", color: "#ffffff", size: 22, fill: Math.floor(t * 8) % 2 ? FIRE : WRECK };
};

let ticker = 0;
const ticking = (on) => {
  if (on && !ticker) ticker = setInterval(() => {}, 60); // a timer firing redraws the window
  else if (!on && ticker) (clearInterval(ticker), (ticker = 0));
};

const cell = (label, more) => ({ type: "button", variant: "icon", label, size: 16, fill: SEA, ...more });
const mark = (text) => ({ type: "button", variant: "icon", label: text, size: 13, color: "faint" });
/** A ship's cell as part of a hull: pointed at both ends. */
const hull = (ship, c) => {
  if (ship.length === 1) return "◆";
  const across = ship[1] - ship[0] === 1, i = ship.indexOf(c);
  return i === 0 ? (across ? "◀" : "▲") : i === ship.length - 1 ? (across ? "▶" : "▼") : "■";
};

// Placing: click a ship to pick it up, click it again to turn it, click the sea to move it there.
const pick = (g, si) => {
  if (g.sel !== si) return void (g.sel = si);
  const s = g.ships[si], others = g.ships.filter((o) => o !== s);
  const turned = shipAt(s[0] % N, Math.floor(s[0] / N), s.length, !(s.length > 1 && s[1] - s[0] === 1));
  if (s.length > 1 && fits(others, turned)) (g.ships[si] = /** @type {number[]} */ (turned)), sfx("place", 0.5);
  else if (s.length > 1 && match) match.note = "No room to turn it there: ships can't touch.";
};
const drop = (g, c) => {
  const s = g.ships[g.sel];
  if (!s) return;
  const moved = shipAt(c % N, Math.floor(c / N), s.length, s.length < 2 || s[1] - s[0] === 1);
  if (fits(g.ships.filter((o) => o !== s), moved)) (g.ships[g.sel] = /** @type {number[]} */ (moved)), sfx("place", 0.5), match && (match.note = "");
  else if (match) match.note = "It doesn't fit there: ships can't touch, not even at the corners.";
};

const myCell = (g, c, now) => {
  const si = g.ships.findIndex((s) => s.includes(c));
  const ship = g.ships[si];
  const e = effect("mine", c, now);
  if (e) return cell(e.label, e);
  if (g.phase === "place") {
    const free = !g.ready;
    if (!ship) return cell("", { onClick: free && g.sel >= 0 ? () => drop(g, c) : undefined });
    return cell(hull(ship, c), { color: INK, fill: si === g.sel ? HULL_SEL : HULL, tooltip: free ? (si === g.sel ? "Click again to turn it, or click the sea to move it" : "Pick up this ship") : undefined, onClick: free ? () => pick(g, si) : undefined });
  }
  if (!ship) return cell(g.mine[c] ? "•" : "", { color: FOAM });
  if (ship.every((x) => g.mine[x] === 2)) return cell("✕", { color: "#ffffff", fill: WRECK });
  return g.mine[c] ? cell("✕", { color: "#ffffff", fill: FIRE }) : cell(hull(ship, c), { color: INK, fill: HULL });
};
const theirCell = (g, c, now, canFire, blink) => {
  const e = effect("theirs", c, now);
  if (e) return cell(e.label, e);
  const v = g.theirs[c];
  if (g.pending === c) return cell("◎", { color: "#ffd43b", size: blink ? 22 : 16, fill: SEA_LIT });
  if (v === 1) return cell("•", { color: FOAM });
  if (v === 2) return cell("✕", { color: "#ffffff", fill: FIRE });
  if (v === 3) return cell("✕", { color: "#ffffff", fill: WRECK });
  if (v === 4) return cell("■", { color: INK, fill: GHOST });
  return cell("", canFire ? { fill: SEA_LIT, tooltip: `Fire at ${nameOf(c)}`, onClick: () => fire(c) } : {});
};

/** Both seas side by side in one block of rows, so they stay level. */
const seasView = (g, now, canFire) => {
  const blink = Math.floor(now / 250) % 2 === 0;
  const gap = { type: "space", size: 34 };
  const header = [mark(""), ...[...COLS].map(mark), gap, mark(""), ...[...COLS].map(mark)];
  const rows = [{ type: "row", children: header }];
  for (let r = 0; r < N; r++) {
    const row = [mark(String(r + 1))];
    for (let c = 0; c < N; c++) row.push(myCell(g, r * N + c, now));
    row.push(gap, mark(String(r + 1)));
    for (let c = 0; c < N; c++) row.push(theirCell(g, r * N + c, now, canFire, blink));
    rows.push({ type: "row", children: row });
  }
  return { type: "group", padding: 14, children: [{ type: "column", spacing: 8, children: rows }] };
};

const fleetLine = (label, alive) => ({ type: "label", text: `${label}: ${alive.map((n) => "■".repeat(n)).join("  ") || "nothing left"}`, small: true, color: "dim", monospace: true });

const playView = (m) => {
  const g = m.g, now = Date.now();
  fx = fx.filter((e) => now < e.start + FX_MS[e.kind]);
  const live = m.open && g.phase === "play";
  const canFire = live && g.turn === "me" && g.pending < 0;
  ticking(fx.length > 0 || g.pending >= 0);
  const [title, tint, detail] =
    g.phase === "over" ? (g.won ? ["Victory!", "green", `You sank ${m.name}'s whole fleet.`] : ["Defeat", "red", `${m.name} sank your fleet. Their surviving ships are shown in grey.`])
    : !m.session ? ["Game ended", "dim", m.note]
    : g.phase === "place" ? (g.ready ? ["Fleet ready", "accent", g.theirReady ? "Starting..." : `Waiting for ${m.name} to place their ships...`] : ["Place your fleet", "accent", "Click a ship to pick it up, again to turn it, then the sea to move it. Ships can't touch."])
    : g.turn === "me" ? ["Your shot", "green", g.pending >= 0 ? `Firing at ${nameOf(g.pending)}...` : "Pick a square in their waters. A hit fires again."]
    : [`${m.name} is aiming`, "orange", "Brace for impact."];
  const mineLeft = g.ships.filter((s) => !s.every((x) => g.mine[x] === 2)).map((s) => s.length);
  const theirLeft = [...FLEET];
  for (const len of g.sunk) theirLeft.splice(theirLeft.indexOf(len), 1);
  return [
    {
      type: "bar",
      left: [{ type: "space", size: 4 }, { type: "button", variant: "icon", label: g.phase === "play" ? (g.turn === "me" ? "▶" : "◀") : "⚓", size: 30, color: tint }, { type: "space", size: 6 }, { type: "column", spacing: 2, children: [{ type: "label", text: title, color: tint, strong: true }, { type: "label", text: detail, color: "dim", small: true }] }],
      right: [
        { type: "button", variant: "icon", label: muted ? "🔇" : "🔊", size: 18, tooltip: muted ? "Turn sounds on" : "Mute sounds", onClick: () => (muted = !muted) },
        g.phase === "place" && !g.ready && m.session && { type: "button", label: "Shuffle", tooltip: "Scatter the fleet at random", onClick: () => ((g.ships = randomFleet()), (g.sel = -1), (m.note = ""), sfx("place", 0.5)) },
        g.phase === "place" && !g.ready && m.session && { type: "button", label: "Battle!", variant: "filled", onClick: ready },
        g.phase === "over" && m.session && { type: "button", label: "Rematch", variant: "filled", onClick: again },
      ],
    },
    { type: "space", size: 4 },
    { type: "bar", left: { type: "label", text: "   Your waters", strong: true }, right: { type: "label", text: `${m.name}'s waters   `, strong: true } },
    seasView(g, now, canFire),
    { type: "bar", left: fleetLine("Your fleet", mineLeft), right: fleetLine("Still hiding", theirLeft) },
    m.session && m.note && { type: "label", text: m.note, small: true, color: "orange" },
    { type: "button", label: g.phase === "over" || !m.session ? "Close game" : "Leave game", onClick: leave },
  ];
};

const requestView = (req) => ({
  type: "group",
  children: [
    { type: "label", text: `${req.name} challenges you to Broadside`, strong: true },
    { type: "label", text: `Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", onClick: () => accept(req) }, { type: "button", label: "Decline", onClick: () => decline(req) }] },
  ],
});
const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });

const render = () => {
  const reqs = [...requests.values()].map(requestView);
  const m = match;
  if (!m || (m.session && !m.open)) ticking(false);
  if (!m) {
    const peers = App.p2p.peers();
    return [
      ...reqs,
      { type: "heading", text: "Broadside" },
      { type: "label", text: "Hide ten ships, then trade shots until one fleet is gone. Challenge someone from your servers; they need Broadside installed too.", color: "dim" },
      { type: "space", size: 6 },
      { type: "label", text: "People you can challenge", strong: true },
      {
        type: "scroll",
        spacing: 2,
        children: peers.length
          ? peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: { type: "button", label: "Challenge", onClick: () => invite(p) } }))
          : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }],
      },
    ];
  }
  if (m.session && !m.open) {
    const pending = App.p2p.sessions().find((x) => x.id === m.session)?.status === "waiting";
    return [...reqs, waiting(pending ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`), { type: "button", label: "Cancel", onClick: leave }];
  }
  return [...reqs, ...playView(m)];
};

App.ui.registerWindow({ id: "broadside", title: "Broadside", width: 1040, height: 640, render });
const menuButton = () => App.ui.registerMenu({ id: "broadside", label: "Broadside", icon: "⚓", active: App.ui.isOpen("broadside"), onClick: () => App.ui.toggle("broadside") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", (w) => (menuButton(), w?.id === "broadside" && ticking(false)));
menuButton();
App.onUnload(leave);
