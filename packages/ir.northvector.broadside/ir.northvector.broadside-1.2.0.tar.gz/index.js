// @ts-check
/// <reference path="../../app.d.ts" />
// Broadside: a two-player fleet-hunting game over App.p2p. Each side keeps its own fleet secret and
// answers the other's shots: {t:"ready"}, {t:"shot", c}, {t:"res", c, hit, sunk?: cells, mine?},
// {t:"strike", c} answered by {t:"sres", c, res: [answers]}, {t:"echo", c, hit, sunk?, mine?, none?},
// {t:"fleet", cells, mines} (the winner shows what was left) and {t:"again"}. A hit shoots again; a sunk
// ship's surroundings are marked for both, since ships never touch. Whoever invited fires first, then you
// take turns starting.
// The arsenal: each side hides MINES mines among its ships. A cannon shot on a mine ends the turn and the
// blast echoes back onto the shooter's own sea at the same square (the shooter answers with "echo"). Each
// side also has PLANES air strikes, bombing up to three unknown squares in a row; a strike always ends the
// turn and sets off mines harmlessly.
// shortcut: each side trusts the other's answers, so a cheat could call every shot a miss; fine among friends, commit to a hashed fleet before the first shot for strangers.

const N = 10;
const FLEET = [4, 3, 3, 2, 2, 2, 1, 1, 1, 1];
const MINES = 2, PLANES = 1;
const COLS = "ABCDEFGHIJ";
const nameOf = (c) => `${COLS[c % N]}${Math.floor(c / N) + 1}`;

// ---- rules. A cell is r * 10 + c; a ship is its cells, bow first; a mine is a one-cell piece ----

/** @returns {number[] | null} null when it leaves the sea. */
const shipAt = (c, r, len, across) => (c < 0 || r < 0 || (across ? c + len > N || r >= N : r + len > N || c >= N) ? null : Array.from({ length: len }, (_, i) => (across ? r * N + c + i : (r + i) * N + c)));
/** The cells and everything touching them, corners too. */
const around = (cells) => {
  const out = new Set();
  for (const x of cells) for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
    const c = (x % N) + dc, r = Math.floor(x / N) + dr;
    if (c >= 0 && c < N && r >= 0 && r < N) out.add(r * N + c);
  }
  return out;
};
const fits = (pieces, cells) => {
  if (!cells) return false;
  const zone = around(cells);
  return !pieces.some((s) => s.some((x) => zone.has(x)));
};
const randomFleet = () => {
  const sizes = [...FLEET, ...Array(MINES).fill(1)];
  for (;;) {
    /** @type {number[][]} */
    const all = [];
    for (const len of sizes) {
      let cells = null;
      for (let tries = 0; tries < 200 && !fits(all, cells); tries++) cells = shipAt(Math.floor(Math.random() * N), Math.floor(Math.random() * N), len, Math.random() < 0.5);
      if (!fits(all, cells)) break; // boxed in: start over
      all.push(/** @type {number[]} */ (cells));
    }
    if (all.length === sizes.length) return { ships: all.slice(0, FLEET.length), mines: all.slice(FLEET.length) };
  }
};
/** An air strike's squares: the aimed one and its row neighbours not yet known on `board`. */
const strikeCells = (board, c) => [c - 1, c, c + 1].filter((x) => x >= 0 && x < N * N && Math.floor(x / N) === Math.floor(c / N) && !board[x]);

/**
 * `mine`: their shots at my sea (0 none, 1 miss, 2 hit, 3 mine set off). `theirs`: what I know of their sea
 * (0 unknown, 1 miss, 2 hit, 3 sunk, 4 ship shown after the game, 5 mine set off, 6 mine shown after).
 * `shot`: my shot waiting for its answer. `echo`: the square of my mine they hit, until their blast comes back.
 * `sunk`: the lengths of their ships I sank.
 * @typedef {{ phase: "place" | "play" | "over"; ships: number[][]; mines: number[][]; mine: number[]; theirs: number[]; ready: boolean; theirReady: boolean; turn: "me" | "them"; shot: null | { c: number; cells: number[]; plane: boolean }; echo: number; planes: number; theirPlanes: number; weapon: "gun" | "plane"; sunk: number[]; won: boolean; games: number; inviter: boolean; sel: number }} Game
 */
/** @returns {Game} */
const newGame = (inviter, games = 0) => ({ phase: "place", ...randomFleet(), mine: Array(N * N).fill(0), theirs: Array(N * N).fill(0), ready: false, theirReady: false, turn: "me", shot: null, echo: -1, planes: PLANES, theirPlanes: PLANES, weapon: "gun", sunk: [], won: false, games, inviter, sel: -1 });
const pieces = (g) => g.ships.concat(g.mines);
const isInt = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
const begin = (g) => {
  if (g.phase === "place" && g.ready && g.theirReady) Object.assign(g, { phase: "play", sel: -1, turn: g.inviter === (g.games % 2 === 0) ? "me" : "them" });
};
/** A shell landing on my sea at c: marks it and returns the answer. */
const blast = (g, c) => {
  if (g.mines.some((m) => m[0] === c)) return (g.mine[c] = 3), { c, hit: false, mine: true };
  const ship = g.ships.find((s) => s.includes(c));
  g.mine[c] = ship ? 2 : 1;
  if (!ship) return { c, hit: false };
  if (!ship.every((x) => g.mine[x] === 2)) return { c, hit: true };
  for (const x of around(ship)) if (!g.mine[x]) g.mine[x] = 1;
  if (g.ships.every((s) => s.every((x) => g.mine[x] === 2))) g.phase = "over";
  return { c, hit: true, sunk: ship };
};
/** Their shot or strike at my sea: the answer to send, or null when it isn't a legal move. */
const takeShot = (g, m) => {
  if (g.phase !== "play" || g.turn !== "them" || !isInt(m.c, 0, N * N - 1) || g.mine[m.c]) return null;
  if (m.t === "strike") {
    if (g.theirPlanes < 1) return null;
    g.theirPlanes--;
    g.turn = "me";
    return { t: "sres", c: m.c, res: strikeCells(g.mine, m.c).map((x) => blast(g, x)) };
  }
  const r = blast(g, m.c);
  if (!r.hit) g.turn = "me";
  return { t: "res", ...r };
};
/** One square of an answer, onto their sea; false when it doesn't add up. */
const mark = (g, r) => {
  const c = r?.c;
  // A strike's later square may already be marked as the surroundings of a ship it sank: a miss there is fine.
  if (!isInt(c, 0, N * N - 1) || typeof r.hit !== "boolean" || (r.mine && r.hit) || (g.theirs[c] && !(g.theirs[c] === 1 && !r.hit && !r.mine))) return false;
  if (r.sunk !== undefined && !(r.hit && Array.isArray(r.sunk) && isInt(r.sunk.length, 1, 4) && r.sunk.includes(c) && r.sunk.every((x) => isInt(x, 0, N * N - 1) && (x === c || g.theirs[x] === 2)))) return false;
  g.theirs[c] = r.mine ? 5 : r.hit ? 2 : 1;
  if (r.sunk) {
    for (const x of around(r.sunk)) if (!g.theirs[x]) g.theirs[x] = 1;
    for (const x of r.sunk) g.theirs[x] = 3;
    if (g.sunk.push(r.sunk.length) === FLEET.length) Object.assign(g, { phase: "over", won: true });
  }
  return true;
};
/** The answer to my shot or strike; false when it isn't one. */
const takeResult = (g, m) => {
  const s = g.shot;
  if (g.phase !== "play" || g.turn !== "me" || !s || m.c !== s.c || (m.t === "sres") !== s.plane) return false;
  const list = s.plane ? m.res : [m];
  if (!Array.isArray(list) || list.length !== s.cells.length || list.some((r, i) => r?.c !== s.cells[i])) return false;
  g.shot = null;
  // shortcut: a bad square halfway through a strike leaves the earlier ones marked; only a broken peer sends one.
  if (!list.every((r) => mark(g, r))) return false;
  if (g.phase === "play" && (s.plane || !m.hit)) g.turn = "them";
  return true;
};

// Self-check of the fleet, a whole game, a mine and a strike.
{
  const ok = (c, what) => c || App.log(`Broadside: ${what} is broken`);
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const pair = () => {
    const a = newGame(true), b = newGame(false);
    a.ready = a.theirReady = b.ready = b.theirReady = true;
    return begin(a), begin(b), [a, b];
  };
  const [a, b] = pair();
  const all = pieces(a);
  ok(a.ships.length === 10 && a.mines.length === MINES && new Set(all.flat()).size === 20 + MINES && a.ships.every((s, i) => s.length === FLEET[i]) && all.every((s) => fits(all.filter((o) => o !== s), s)), "randomFleet");
  ok(shipAt(8, 0, 3, true) === null && String(shipAt(0, 7, 3, false)) === "70,80,90" && around([0]).size === 4 && String(strikeCells(Array(100).fill(0), 10)) === "10,11", "shipAt/around/strikeCells");
  ok(a.turn === "me" && b.turn === "them", "begin");
  let shots = 0;
  for (let c = 0; c < N * N && a.phase === "play"; c++) {
    if (a.theirs[c]) continue;
    Object.assign(a, { turn: "me", shot: { c, cells: [c], plane: false } }), (b.turn = "them"), shots++;
    const res = takeShot(b, { t: "shot", c });
    ok(res && takeResult(a, clone(res)) && (!res.mine || a.turn === "them"), `shot ${c}`);
  }
  ok(a.won && a.sunk.length === 10 && b.phase === "over" && !b.won && a.theirs.every((v, x) => v !== 5 || b.mines.some((m) => m[0] === x)) && shots < 100 && takeShot(b, { t: "shot", c: 99 }) === null, "a whole game");
  const [p, q] = pair(), c = q.mines[0][0];
  q.turn = "them";
  p.shot = { c, cells: strikeCells(p.theirs, c), plane: true };
  const sr = takeShot(q, { t: "strike", c });
  ok(sr && takeResult(p, clone(sr)) && p.theirs[c] === 5 && p.turn === "them" && q.turn === "me" && q.theirPlanes === 0 && q.mine[c] === 3, "a strike");
  q.turn = "them";
  ok(takeShot(q, { t: "strike", c: (c + 50) % 100 }) === null, "one strike each");
}

// ---- network: one match at a time ----

/** @type {null | { name: string; session: string | null; open: boolean; g: Game; note: string }} */
let match = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const send = (msg, tries = 0) => {
  const session = match?.open && match.session;
  if (!session) return;
  try {
    App.p2p.send(session, typeof msg === "string" ? msg : (msg = JSON.stringify(msg)));
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => match?.session === session && send(msg, tries + 1), 500);
    else App.log(`Broadside: not sent: ${e.message}`);
  }
};
const leave = () => {
  if (match?.session) App.p2p.close(match.session);
  match = null;
  fx = [];
};
const invite = (peer) => {
  leave();
  try {
    match = { name: peer.name, session: App.p2p.connect(peer.connection, peer.clientId), open: false, g: newGame(true), note: "" };
  } catch (e) {
    App.ui.notify(`Can't reach ${peer.name}: ${e.message}`, "error");
  }
};
const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  match = { name: req.name, session: req.session, open: false, g: newGame(false), note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};

// The local player's moves.
const ready = () => {
  if (!match || match.g.phase !== "place" || match.g.ready) return;
  match.g.ready = true;
  match.note = "";
  send({ t: "ready" });
  begin(match.g);
  if (match.g.phase === "play") started();
};
const canFire = (m) => m.open && m.g.phase === "play" && m.g.turn === "me" && !m.g.shot && m.g.echo < 0;
const fire = (c) => {
  const g = match?.g;
  if (!match || !g || !canFire(match) || g.theirs[c]) return;
  const plane = g.weapon === "plane" && g.planes > 0;
  g.shot = { c, cells: plane ? strikeCells(g.theirs, c) : [c], plane };
  if (plane) (g.planes--, (g.weapon = "gun"));
  match.note = "";
  sfx("fire", 0.5);
  send({ t: plane ? "strike" : "shot", c });
};
const again = () => {
  if (!match || match.g.phase !== "over") return;
  send({ t: "again" });
  rematch();
};
const rematch = () => {
  if (!match) return;
  match.g = newGame(match.g.inviter, match.g.games + 1);
  match.note = "";
  fx = [];
};
const started = () => match && match.g.turn === "me" && sfx("ping", 0.45);
const finished = (won) => setTimeout(() => sfx(won ? "win" : "lose", 0.6), 700);
const won = (g) => {
  finished(true);
  send({ t: "fleet", cells: g.ships.flat().filter((x) => g.mine[x] !== 2), mines: g.mines.flat().filter((x) => !g.mine[x]) });
};
const what = (r) => (r.sunk ? "sank a ship" : r.hit ? "hit a ship" : r.mine ? "set off a mine" : "missed");

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} challenges you to Broadside`);
  sfx("invite", 0.6);
  App.ui.open("broadside");
});
App.events.on("p2p.open", ({ session }) => {
  if (match?.session === session) match.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  if (match?.session !== session) return;
  // The app answers this way when their side doesn't run Broadside: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? `${match.name} doesn't have Broadside installed and enabled.` : match.open ? `${match.name} left${reason ? ` (${reason})` : ""}.` : `Couldn't connect to ${match.name}${reason ? ` (${reason})` : ""}.`;
  Object.assign(match, { session: null, open: false, note: why });
});
App.events.on("p2p.message", ({ session, data }) => {
  if (!match || match.session !== session) return;
  const g = match.g;
  let m;
  try {
    m = JSON.parse(data);
  } catch {
    return;
  }
  if (m?.t === "ready" && g.phase === "place" && !g.theirReady) {
    g.theirReady = true;
    begin(g);
    if (g.phase === "play") started();
  } else if (m?.t === "shot" || m?.t === "strike") {
    const res = takeShot(g, m);
    if (!res) return;
    send(res);
    boom("mine", res);
    if (res.mine) (g.echo = res.c), (match.note = `${match.name} hit your mine at ${nameOf(res.c)}. Its blast is rolling back onto their own sea.`);
    if (g.phase === "over") finished(false);
    else if (g.turn === "me") setTimeout(started, 600);
  } else if (m?.t === "res" || m?.t === "sres") {
    if (!takeResult(g, m)) return;
    boom("theirs", m);
    if (m.mine && g.phase === "play") {
      // Their mine: the same square of my own sea takes the blast, and they hear how it went.
      const r = g.mine[m.c] ? { c: m.c, hit: false, none: true } : blast(g, m.c);
      send({ t: "echo", ...r });
      if (!r.none) boom("mine", r);
      match.note = r.none ? `Mine at ${nameOf(m.c)}! Its blast fell on water you'd already lost.` : `Mine at ${nameOf(m.c)}! The blast echoed onto your own ${nameOf(m.c)} and ${what(r)}.`;
      if (g.phase === "over") finished(false);
    }
    if (g.won) won(g);
  } else if (m?.t === "echo" && m.c === g.echo) {
    g.echo = -1;
    if (m.none || g.phase !== "play" || !mark(g, m)) return void (match.note = "");
    boom("theirs", m);
    match.note = `Your mine's blast ${what(m)} in ${match.name}'s waters.`;
    if (g.won) won(g);
  } else if (m?.t === "fleet" && g.phase === "over" && !g.won && Array.isArray(m.cells) && m.cells.length <= 20) {
    for (const x of m.cells) if (isInt(x, 0, N * N - 1) && !g.theirs[x]) g.theirs[x] = 4;
    if (Array.isArray(m.mines)) for (const x of m.mines.slice(0, MINES)) if (isInt(x, 0, N * N - 1) && !g.theirs[x]) g.theirs[x] = 6;
  } else if (m?.t === "again" && g.phase === "over") {
    rematch();
    App.ui.notify(`${match.name} wants a rematch`);
  }
});

// ---- view ----

const SEA = "#12344f", SEA_LIT = "#1b4a6e", HULL = "#93a7b8", HULL_SEL = "#e3b23c", INK = "#16242f";
const FIRE = "#e8590c", WRECK = "#7d2020", FOAM = "#7fb2d6", GHOST = "#4a6278";
const MINE = "#0a1c2b", BRASS = "#d9a441", BLAST = "#b8480c";

// Sound effects on your own speakers only (never the mic), synthesized into sounds/ by the author.
// shortcut: mute lasts until the plugin restarts; keep it in App.storage if people ask (a new permission).
let muted = false;
const sfx = (name, volume = 0.5) => {
  if (muted) return;
  try {
    App.audio.play(`sounds/${name}.wav`, { volume, mic: false });
  } catch (e) {
    App.log(`Broadside: no sound: ${e.message}`);
  }
};

// An answer plays out on its squares: a blast, a ripple, a mine going up, a sunk ship flashing along its length.
/** @type {{ board: "mine" | "theirs"; cells: number[]; kind: "hit" | "miss" | "sunk" | "mine"; start: number }[]} */
let fx = [];
const FX_MS = { hit: 600, miss: 550, sunk: 1300, mine: 900 };
const RANK = ["miss", "hit", "mine", "sunk"];
const boom = (board, m) => {
  let loudest = "miss";
  for (const r of m.t === "sres" ? m.res : [m]) {
    const kind = r.mine ? "mine" : r.sunk ? "sunk" : r.hit ? "hit" : "miss";
    fx.push({ board, cells: r.sunk || [r.c], kind, start: Date.now() });
    if (RANK.indexOf(kind) > RANK.indexOf(loudest)) loudest = kind;
  }
  sfx(loudest === "miss" ? "splash" : loudest === "mine" ? "sunk" : loudest, loudest === "miss" || loudest === "hit" ? 0.55 : 0.7);
};
/** The glyph playing on this cell right now, if any. */
const effect = (board, c, now) => {
  const e = fx.find((e) => e.board === board && e.cells.includes(c));
  if (!e) return null;
  const t = (now - e.start) / FX_MS[e.kind];
  if (e.kind === "miss") return { label: "○", color: FOAM, size: Math.round(8 + 20 * t) };
  if (e.kind === "hit") return { label: "✹", color: t < 0.5 ? "#ffd43b" : "#ffffff", size: Math.round(10 + 22 * Math.sin(t * Math.PI)), fill: FIRE };
  if (e.kind === "mine") return { label: "✺", color: t < 0.5 ? "#ffffff" : "#ffd43b", size: Math.round(14 + 18 * Math.sin(t * Math.PI)), fill: Math.floor(t * 6) % 2 ? FIRE : BLAST };
  return { label: Math.floor(t * 8) % 2 ? "✹" : "✕", color: "#ffffff", size: 22, fill: Math.floor(t * 8) % 2 ? FIRE : WRECK };
};

let ticker = 0;
const ticking = (on) => {
  if (on && !ticker) ticker = setInterval(() => {}, 60); // a timer firing redraws the window
  else if (!on && ticker) (clearInterval(ticker), (ticker = 0));
};

const cell = (label, more) => ({ type: "button", variant: "icon", label, size: 16, fill: SEA, ...more });
const coord = (text) => ({ type: "button", variant: "icon", label: text, size: 12, color: "faint" });
/** A ship's cell as part of a hull: pointed at both ends. */
const hull = (ship, c) => {
  if (ship.length === 1) return "◆";
  const across = ship[1] - ship[0] === 1, i = ship.indexOf(c);
  return i === 0 ? (across ? "◀" : "▲") : i === ship.length - 1 ? (across ? "▶" : "▼") : "■";
};

// Placing: click a piece to pick it up, click a ship again to turn it, click the sea to move it there.
const setPiece = (g, i, cells) => (i < g.ships.length ? (g.ships[i] = cells) : (g.mines[i - g.ships.length] = cells));
const pick = (g, si) => {
  if (g.sel !== si) return void (g.sel = si);
  const all = pieces(g), s = all[si], others = all.filter((o) => o !== s);
  if (s.length < 2) return void (g.sel = -1); // a mine or a one-square boat: a second click puts it down
  const turned = shipAt(s[0] % N, Math.floor(s[0] / N), s.length, s[1] - s[0] !== 1);
  if (fits(others, turned)) setPiece(g, si, turned), sfx("place", 0.5), match && (match.note = "");
  else if (match) match.note = "No room to turn it there: pieces can't touch.";
};
const drop = (g, c) => {
  const all = pieces(g), s = all[g.sel];
  if (!s) return;
  const moved = shipAt(c % N, Math.floor(c / N), s.length, s.length < 2 || s[1] - s[0] === 1);
  if (fits(all.filter((o) => o !== s), moved)) setPiece(g, g.sel, moved), sfx("place", 0.5), match && (match.note = "");
  else if (match) match.note = "It doesn't fit there: ships and mines can't touch, not even at the corners.";
};

const myCell = (g, c, now) => {
  const all = pieces(g);
  const si = all.findIndex((s) => s.includes(c));
  const piece = all[si], isMine = si >= g.ships.length;
  const e = effect("mine", c, now);
  if (e) return cell(e.label, e);
  if (g.phase === "place") {
    const free = !g.ready;
    if (!piece) return cell("", { fill: free && g.sel >= 0 ? SEA_LIT : SEA, onClick: free && g.sel >= 0 ? () => drop(g, c) : undefined });
    const sel = si === g.sel;
    const tip = !free ? undefined : sel ? (piece.length > 1 ? "Click again to turn it, or click the sea to move it" : "Click the sea to move it, or here to put it down") : isMine ? "Pick up this mine" : "Pick up this ship";
    return cell(isMine ? "✺" : hull(piece, c), { color: sel ? INK : isMine ? BRASS : INK, fill: sel ? HULL_SEL : isMine ? MINE : HULL, size: isMine ? 18 : 16, tooltip: tip, onClick: free ? () => pick(g, si) : undefined });
  }
  if (isMine) return g.mine[c] ? cell("✺", { color: "#ffffff", fill: BLAST, size: 18, tooltip: "Your mine, set off" }) : cell("✺", { color: BRASS, fill: MINE, size: 18, tooltip: "Your mine, still hidden" });
  if (!piece) return cell(g.mine[c] ? "•" : "", { color: FOAM });
  if (piece.every((x) => g.mine[x] === 2)) return cell("✕", { color: "#ffffff", fill: WRECK });
  return g.mine[c] ? cell("✕", { color: "#ffffff", fill: FIRE }) : cell(hull(piece, c), { color: INK, fill: HULL });
};
const theirCell = (g, c, now, live, blink) => {
  const e = effect("theirs", c, now);
  if (e) return cell(e.label, e);
  const v = g.theirs[c];
  if (g.shot?.cells.includes(c)) return cell(g.shot.plane ? "✈" : "◎", { color: "#ffd43b", size: blink ? 22 : 16, fill: SEA_LIT });
  if (v === 1) return cell("•", { color: FOAM });
  if (v === 2) return cell("✕", { color: "#ffffff", fill: FIRE });
  if (v === 3) return cell("✕", { color: "#ffffff", fill: WRECK });
  if (v === 4) return cell("■", { color: INK, fill: GHOST });
  if (v === 5) return cell("✺", { color: "#ffffff", fill: BLAST, size: 18 });
  if (v === 6) return cell("✺", { color: INK, fill: GHOST, size: 18 });
  if (!live) return cell("");
  if (g.weapon === "plane") {
    const hit = strikeCells(g.theirs, c);
    return cell("", { fill: SEA_LIT, tooltip: `Air strike on ${hit.map(nameOf).join(", ")}`, onClick: () => fire(c) });
  }
  return cell("", { fill: SEA_LIT, tooltip: `Fire at ${nameOf(c)}`, onClick: () => fire(c) });
};

/** Both seas side by side in one block of rows, so they stay level. */
const seasView = (g, now, live) => {
  const blink = Math.floor(now / 250) % 2 === 0;
  const gap = { type: "space", size: 40 };
  const header = [coord(""), ...[...COLS].map(coord), gap, coord(""), ...[...COLS].map(coord)];
  const rows = [{ type: "row", children: header }];
  for (let r = 0; r < N; r++) {
    const row = [coord(String(r + 1))];
    for (let c = 0; c < N; c++) row.push(myCell(g, r * N + c, now));
    row.push(gap, coord(String(r + 1)));
    for (let c = 0; c < N; c++) row.push(theirCell(g, r * N + c, now, live, blink));
    rows.push({ type: "row", children: row });
  }
  return { type: "group", padding: 16, children: [{ type: "column", spacing: 6, children: rows }] };
};

/** A side's tally: ships afloat, then mines and planes in hand. */
const tally = (label, ships, mines, planes, align) => {
  const kit = [ships.map((n) => "■".repeat(n)).join(" ") || "no ships", "✺".repeat(mines) || "–", "✈".repeat(planes) || "–"].join("   ");
  return { type: "column", spacing: 2, children: [{ type: "label", text: align === "right" ? `${label}   ` : `   ${label}`, small: true, strong: true, color: "dim" }, { type: "label", text: align === "right" ? `${kit}   ` : `   ${kit}`, small: true, monospace: true, color: "dim" }] };
};

const weapons = (g, live) =>
  g.phase === "play" && g.turn === "me"
    ? [
        { type: "button", variant: "pill", label: "◎ Cannon", selected: g.weapon === "gun", enabled: live, tooltip: "One square. A hit fires again.", onClick: () => (g.weapon = "gun") },
        { type: "button", variant: "pill", label: `✈ Air strike ×${g.planes}`, selected: g.weapon === "plane", enabled: live && g.planes > 0, tooltip: "Bombs up to three unknown squares in a row, then your turn ends. Once per game.", onClick: () => (g.weapon = g.weapon === "plane" ? "gun" : "plane") },
        { type: "space", size: 10 },
      ]
    : [];

const playView = (m) => {
  const g = m.g, now = Date.now();
  fx = fx.filter((e) => now < e.start + FX_MS[e.kind]);
  const live = canFire(m);
  ticking(fx.length > 0 || !!g.shot);
  const [title, tint, detail] =
    g.phase === "over" ? (g.won ? ["Victory!", "green", `You sank ${m.name}'s whole fleet.`] : ["Defeat", "red", `${m.name} sank your fleet. What they had left is shown in grey.`])
    : !m.session ? ["Game ended", "dim", m.note]
    : g.phase === "place" ? (g.ready ? ["Fleet ready", "accent", g.theirReady ? "Starting..." : `Waiting for ${m.name} to place their fleet...`] : ["Place your fleet", "accent", `Click a ship or mine to pick it up, a ship again to turn it, then the sea to move it. Nothing may touch.`])
    : g.turn === "me" ? (g.echo >= 0 ? ["Your shot", "green", "Waiting for your mine's blast to land..."] : g.shot ? ["Your shot", "green", g.shot.plane ? `Air strike inbound on ${g.shot.cells.map(nameOf).join(", ")}...` : `Firing at ${nameOf(g.shot.c)}...`] : ["Your shot", "green", g.weapon === "plane" ? "Pick the middle of three squares to bomb." : "Pick a square in their waters. A hit fires again."])
    : [`${m.name} is aiming`, "orange", "Brace for impact."];
  const mineShips = g.ships.filter((s) => !s.every((x) => g.mine[x] === 2)).map((s) => s.length);
  const theirShips = [...FLEET];
  for (const len of g.sunk) theirShips.splice(theirShips.indexOf(len), 1);
  const placing = g.phase === "place" && !g.ready && m.session;
  return [
    {
      type: "bar",
      left: [{ type: "space", size: 4 }, { type: "button", variant: "icon", label: g.phase === "play" ? (g.turn === "me" ? "▶" : "◀") : "⚓", size: 30, color: tint }, { type: "space", size: 6 }, { type: "column", spacing: 2, children: [{ type: "label", text: title, color: tint, strong: true }, { type: "label", text: detail, color: "dim", small: true }] }],
      right: [
        { type: "button", variant: "icon", label: muted ? "🔇" : "🔊", size: 18, tooltip: muted ? "Turn sounds on" : "Mute sounds", onClick: () => (muted = !muted) },
        { type: "button", label: g.phase === "over" || !m.session ? "Close game" : "Leave", onClick: leave },
        placing && { type: "button", label: "Shuffle", tooltip: "Scatter the fleet and mines at random", onClick: () => (Object.assign(g, randomFleet(), { sel: -1 }), (m.note = ""), sfx("place", 0.5)) },
        placing && { type: "button", label: "Battle!", variant: "filled", onClick: ready },
        g.phase === "over" && m.session && { type: "button", label: "Rematch", variant: "filled", onClick: again },
      ],
    },
    { type: "space", size: 6 },
    { type: "bar", left: { type: "label", text: "   Your waters", strong: true }, right: [...weapons(g, live), { type: "label", text: `${m.name}'s waters   `, strong: true }] },
    seasView(g, now, live),
    { type: "bar", left: tally("Your fleet", mineShips, g.mines.filter((x) => !g.mine[x[0]]).length, g.planes), right: tally("Still hiding", theirShips, MINES - g.theirs.filter((v) => v === 5).length, g.theirPlanes, "right") },
    m.session && m.note && { type: "label", text: `   ${m.note}`, small: true, color: "orange" },
  ];
};

const requestView = (req) => ({
  type: "group",
  children: [
    { type: "label", text: `${req.name} challenges you to Broadside`, strong: true },
    { type: "label", text: `Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", onClick: () => accept(req) }, { type: "button", label: "Decline", onClick: () => decline(req) }] },
  ],
});
const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });
const rule = (glyph, text) => ({ type: "row", children: [{ type: "label", text: glyph, monospace: true, color: "accent" }, { type: "label", text, small: true, color: "dim" }] });

const render = () => {
  const reqs = [...requests.values()].map(requestView);
  const m = match;
  if (!m || (m.session && !m.open)) ticking(false);
  if (!m) {
    const peers = App.p2p.peers();
    return [
      ...reqs,
      { type: "heading", text: "Broadside" },
      { type: "label", text: "Hide your fleet, then trade shots until one side has nothing left afloat. Challenge someone from your servers; they need Broadside installed too.", color: "dim" },
      { type: "space", size: 4 },
      {
        type: "group",
        title: "Your arsenal",
        children: [
          rule("■", "Ten ships: one of four squares, two of three, three of two, four of one. Nothing may touch, not even at the corners."),
          rule("◎", "Cannon: one square at a time. A hit fires again."),
          rule("✺", `${MINES} mines hidden among your ships. Whoever shoots one loses the turn, and the blast lands on the same square of their own sea.`),
          rule("✈", "One air strike per game: bombs up to three squares in a row, then your turn ends."),
        ],
      },
      { type: "space", size: 4 },
      { type: "label", text: "People you can challenge", strong: true },
      {
        type: "scroll",
        spacing: 2,
        children: peers.length
          ? peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: { type: "button", label: "Challenge", onClick: () => invite(p) } }))
          : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }],
      },
    ];
  }
  if (m.session && !m.open) {
    const pending = App.p2p.sessions().find((x) => x.id === m.session)?.status === "waiting";
    return [...reqs, waiting(pending ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`), { type: "button", label: "Cancel", onClick: leave }];
  }
  return [...reqs, ...playView(m)];
};

App.ui.registerWindow({ id: "broadside", title: "Broadside", width: 1040, height: 660, render });
const menuButton = () => App.ui.registerMenu({ id: "broadside", label: "Broadside", icon: "⚓", active: App.ui.isOpen("broadside"), onClick: () => App.ui.toggle("broadside") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", (w) => (menuButton(), w?.id === "broadside" && ticking(false)));
menuButton();
App.onUnload(leave);
