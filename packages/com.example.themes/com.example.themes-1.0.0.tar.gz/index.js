const themes = {
  Neon: { bg: "#0d0221", text: "#f0e6ff", accent: "#ff2a6d", talking: "#05d9e8", link: "#05d9e8", icons: { mic: "🎙", settings: "🛠" } },
  Solarized: { bg: "#002b36", text: "#eee8d5", accent: "#b58900" },
  Paper: { bg: "#fbf8f1", text: "#2b2b2b", accent: "#c0392b" },
};
for (const [name, colors] of Object.entries(themes)) App.theme.register(name, colors);

const names = Object.keys(themes);
let next = App.storage.get("next", 0) % names.length;

App.ui.registerMenu({
  id: "cycle",
  label: "Next theme",
  icon: "🎨",
  onClick: () => {
    App.theme.apply(names[next]);
    App.ui.notify(`Theme: ${names[next]}`);
    next = (next + 1) % names.length;
    App.storage.set("next", next);
  },
});
