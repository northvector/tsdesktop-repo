// @ts-check
/// <reference path="../../app.d.ts" />
// Ludo for 2-4 players over App.p2p. The host invites the others (one session each) and keeps the game:
// guests send {t:"roll"} and {t:"move", piece: 0-3}, the host checks them against the rules and sends
// everyone {t:"state", s, you}. Nobody plays until every invited player's session is open. Spectators are members
// without a seat (`you` -1); a player who left can be invited back to their seat, their pieces as they were.
// shortcut: the host rolls every die, so guests trust the host's dice; fine among friends, add commit-reveal rolls for strangers.

const COLORS = ["#e5534b", "#4c8eda", "#2ea043", "#d4a72c"];
const LIGHT = ["#f2b1ad", "#b3cdef", "#a6dcb2", "#efd98f"];
const COLOR_NAMES = ["Red", "Blue", "Green", "Yellow"];
/** Seats by player count: two players sit opposite. */
const SEATS = { 2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3] };

// ---- board: 11×11 cells; Red's quarter, turned 90° clockwise around the middle for each next seat ----

/** @returns {[number, number]} */
const rot = ([c, r], k) => {
  for (let i = 0; i < k; i++) [c, r] = [10 - r, c];
  return [c, r];
};
const QUARTER = [[0, 4], [1, 4], [2, 4], [3, 4], [4, 4], [4, 3], [4, 2], [4, 1], [4, 0], [5, 0]];
const SEAT4 = [0, 1, 2, 3];
/** 40 cells clockwise; seat k starts on TRACK[k * 10]. */
const TRACK = SEAT4.flatMap((k) => QUARTER.map((p) => rot(p, k)));
const HOME = SEAT4.map((k) => [1, 2, 3, 4].map((c) => rot([c, 5], k)));
const YARD = SEAT4.map((k) => [[0, 0], [1, 0], [0, 1], [1, 1]].map((p) => rot(p, k)));

// ---- rules. A piece is -1 in the yard, 0-39 steps along the track from its start, 40-43 home ----

/**
 * @typedef {{ name: string; seat: number; gone?: boolean }} Player
 * @typedef {{ phase: "lobby" | "play" | "over"; players: Player[]; pieces: number[][]; turn: number; dice: number; last: number; tries: number; winner: number; log: string; n: number; rolls?: number }} State
 */
const cellOf = (seat, p) => (seat * 10 + p) % 40;
/** Where piece k of player pi lands with d, or null when it can't move. */
const target = (s, pi, k, d) => {
  const p = s.pieces[pi][k];
  const np = p < 0 ? (d === 6 ? 0 : null) : p + d;
  if (np === null || np > 43) return null;
  if (s.pieces[pi].some((q, j) => j !== k && q === np)) return null; // your own piece is there
  return np;
};
const movable = (s) => (s.dice ? [0, 1, 2, 3].filter((k) => target(s, s.turn, k, s.dice) !== null) : []);

const nextTurn = (s) => {
  Object.assign(s, { dice: 0, tries: 0 });
  for (let i = 1; i <= s.players.length; i++) {
    const t = (s.turn + i) % s.players.length;
    if (!s.players[t].gone) return void (s.turn = t);
  }
};
const roll = (s, pi) => {
  if (s.phase !== "play" || s.turn !== pi || s.dice) return;
  const d = 1 + Math.floor(Math.random() * 6);
  const who = s.players[pi].name;
  Object.assign(s, { dice: d, last: d, rolls: (s.rolls || 0) + 1 });
  if (movable(s).length) return void (s.log = `${who} rolled ${d}`);
  s.dice = 0;
  // Nothing on the track: three tries to roll a 6.
  if (s.pieces[pi].every((p) => p < 0 || p >= 40) && s.tries < 2) return void (s.tries++, (s.log = `${who} rolled ${d}, tries again`));
  s.log = `${who} rolled ${d}, no move`;
  nextTurn(s);
};
const move = (s, pi, k) => {
  if (s.phase !== "play" || s.turn !== pi || !s.dice || !Number.isInteger(k) || k < 0 || k > 3) return;
  const np = target(s, pi, k, s.dice);
  if (np === null) return;
  const me = s.players[pi];
  s.pieces[pi][k] = np;
  s.log = `${me.name} moved`;
  if (np < 40)
    s.players.forEach((o, oi) =>
      s.pieces[oi].forEach((q, j) => {
        if (oi !== pi && q >= 0 && q < 40 && cellOf(o.seat, q) === cellOf(me.seat, np)) (s.pieces[oi][j] = -1), (s.log = `${me.name} sent ${o.name} home`);
      }),
    );
  if (s.pieces[pi].every((p) => p >= 40)) return void Object.assign(s, { phase: "over", winner: pi, dice: 0, log: `${me.name} won!` });
  if (s.dice === 6) Object.assign(s, { dice: 0, tries: 0, log: `${s.log}, rolls again` });
  else nextTurn(s);
};

/** @returns {State} */
const newGame = (names) => {
  const seats = SEATS[names.length];
  return { phase: "play", players: names.map((name, i) => ({ name, seat: seats[i] })), pieces: names.map(() => [-1, -1, -1, -1]), turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: `${names[0]} starts`, n: 0 };
};

// Self-check of the board and the rules.
{
  const ok = (c, what) => c || App.log(`Ludo: ${what} is broken`);
  ok(TRACK.length === 40 && new Set(TRACK.map(String)).size === 40 && String(TRACK[10]) === "6,0" && String(TRACK[30]) === "4,10", "TRACK");
  ok(String(HOME[2][0]) === "9,5" && String(YARD[3][0]) === "0,10", "HOME/YARD");
  const s = newGame(["a", "b"]);
  s.pieces[1][0] = 18; // Green (seat 2) 18 steps out: cell 38
  s.pieces[0][0] = 36; // Red 36 steps out: cell 36, two short of Green
  s.dice = 2;
  move(s, 0, 0);
  ok(s.pieces[0][0] === 38 && s.pieces[1][0] === -1 && s.turn === 1, "capture");
  s.dice = 5;
  ok(movable(s).length === 0 && target(s, 1, 0, 6) === 0, "leaving the yard");
}

// ---- network ----

/**
 * The host's room holds members (one session each); a guest's holds the host's session.
 * `watch`: a spectator. `session` is "" once a seated player left (the host may invite them back).
 * @typedef {{ key: string; name: string; connection: number; clientId: number; session: string; open: boolean; watch: boolean }} Member
 * @type {null | { host: true; members: Map<string, Member>; keys: string[]; s: State; note: string } | { host: false; name: string; session: string | null; open: boolean; s: State | null; you: number; note: string }}
 */
let room = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const myName = () => {
  const st = App.app.state();
  const c = st.connections.find((c) => c.id === st.active) || st.connections[0];
  return c?.clients.find((x) => x.id === c.ownClientId)?.name || "Host";
};

const sendRaw = (session, msg, tries = 0) => {
  try {
    App.p2p.send(session, msg);
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => sendRaw(session, msg, tries + 1), 500);
    else App.log(`Ludo: not sent: ${e.message}`);
  }
};
const seated = (r) => [...r.members.values()].filter((m) => !m.watch);
const watchers = (r) => [...r.members.values()].filter((m) => m.watch);
const MAX_WATCHERS = 6;
/** The host's state to every open member; `n` lets guests drop a late copy of an older one. */
const broadcast = () => {
  if (!room?.host) return;
  const r = room;
  if (r.s.phase === "lobby") r.s.players = [myName(), ...seated(r).map((m) => m.name)].map((name) => ({ name, seat: 0 }));
  r.s.n++;
  const s = { ...r.s, watchers: watchers(r).filter((m) => m.open).map((m) => m.name) };
  for (const m of r.members.values()) if (m.open) sendRaw(m.session, JSON.stringify({ t: "state", s, you: r.keys.indexOf(m.key) }));
};
const lobby = () => ({ host: /** @type {true} */ (true), members: new Map(), keys: [""], note: "", s: /** @type {State} */ ({ phase: "lobby", players: [], pieces: [], turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: "", n: 0 }) });
const keyOf = (peer) => `${peer.connection}:${peer.clientId}`;
/** A seated player who left a game still going, and isn't being asked back yet. */
const leftSeat = (r, m) => !m.watch && !m.session && r.s.phase === "play" && !!r.s.players[r.keys.indexOf(m.key)]?.gone;

/** Asks a peer to a seat (in the lobby), back to the seat they left, or to watch. */
const invite = (peer, watch = false) => {
  if (room && !room.host) leave();
  if (!room) room = lobby();
  const r = room;
  const key = keyOf(peer);
  const old = r.members.get(key);
  const back = !!old && leftSeat(r, old);
  if (old && !back) return;
  if (!back && (watch ? watchers(r).length >= MAX_WATCHERS : r.s.phase !== "lobby" || seated(r).length >= 3)) return;
  try {
    r.members.set(key, { key, name: peer.name, connection: peer.connection, clientId: peer.clientId, session: App.p2p.connect(peer.connection, peer.clientId), open: false, watch: watch && !back });
    r.note = "";
  } catch (e) {
    r.note = `Can't reach ${peer.name}: ${e.message}`;
  }
  broadcast();
};
const removeMember = (m) => {
  if (!room?.host) return;
  if (m.session) App.p2p.close(m.session);
  room.members.delete(m.key);
  broadcast();
};
const start = () => {
  if (!room?.host) return;
  const ms = seated(room);
  if (!ms.length || ms.some((m) => !m.open)) return; // hold everyone until all sessions are open
  room.keys = ["", ...ms.map((m) => m.key)];
  room.s = { ...newGame([myName(), ...ms.map((m) => m.name)]), n: room.s.n };
  broadcast();
};
const leave = () => {
  if (room?.host) for (const m of room.members.values()) m.session && App.p2p.close(m.session);
  else if (room?.session) App.p2p.close(room.session);
  room = null;
  confirming = false;
  inviting = false;
};
/** The local player's action: applied by the host, sent to the host by a guest. */
const act = (cmd) => {
  if (!room) return;
  if (room.host) {
    if (cmd.t === "roll") roll(room.s, 0);
    else move(room.s, 0, cmd.piece);
    broadcast();
  } else if (room.session && room.open) sendRaw(room.session, JSON.stringify(cmd));
};

const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  room = { host: false, name: req.name, session: req.session, open: false, s: null, you: -1, note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};
const memberBy = (session) => (room?.host ? [...room.members.values()].find((m) => m.session === session) : undefined);

/** The host's state is another person's data: check its shape before drawing it. */
const validState = (s) => {
  const int = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  if (!s || !["lobby", "play", "over"].includes(s.phase) || !Array.isArray(s.players) || !int(s.players.length, 1, 4) || !int(s.n, 0, 1e9)) return false;
  if (!s.players.every((p) => p && typeof p.name === "string" && int(p.seat, 0, 3))) return false;
  if (s.watchers !== undefined && !(Array.isArray(s.watchers) && s.watchers.length <= 8 && s.watchers.every((w) => typeof w === "string"))) return false;
  if (s.phase === "lobby") return true;
  return (
    new Set(s.players.map((p) => p.seat)).size === s.players.length &&
    Array.isArray(s.pieces) && s.pieces.length === s.players.length && s.pieces.every((a) => Array.isArray(a) && a.length === 4 && a.every((q) => int(q, -1, 43))) &&
    int(s.turn, 0, s.players.length - 1) && int(s.dice, 0, 6) && int(s.last, 0, 6) && int(s.winner, -1, s.players.length - 1) && typeof s.log === "string"
  );
};

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} invites you to Ludo`);
  sfx("invite", 0.6);
  App.ui.open("ludo");
});
App.events.on("p2p.open", ({ session }) => {
  const m = memberBy(session);
  if (m && room?.host) {
    const s = room.s;
    const pi = room.keys.indexOf(m.key);
    if (!m.open && pi > 0 && s.phase === "play" && s.players[pi].gone) (s.players[pi].gone = false), (s.log = `${m.name} is back`);
    return void ((m.open = true), broadcast());
  }
  if (room && !room.host && room.session === session) room.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  // The app answers this way when their side doesn't run Ludo: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? " doesn't have Ludo installed and enabled" : ` left${reason ? ` (${reason})` : ""}`;
  const m = memberBy(session);
  if (m && room?.host) {
    const r = room;
    const pi = r.keys.indexOf(m.key);
    const seatedInPlay = pi > 0 && r.s.phase === "play";
    r.note = m.watch && m.open ? `${m.name} stopped watching.` : `${m.name}${why}.`;
    if (seatedInPlay && m.open) {
      r.s.players[pi].gone = true;
      r.s.log = `${m.name} left`;
      if (r.s.players.filter((p) => !p.gone).length < 2) Object.assign(r.s, { phase: "over", winner: -1, dice: 0, log: "Everyone else left" });
      else {
        r.note = `${m.name} left. You can invite them back to their seat.`;
        if (r.s.turn === pi) nextTurn(r.s);
      }
    }
    if (seatedInPlay) Object.assign(m, { open: false, session: "" }); // kept, to invite back
    else r.members.delete(m.key);
    return void broadcast();
  }
  if (room && !room.host && room.session === session) Object.assign(room, { session: null, open: false, note: room.s ? `${room.name} (the host)${why}. The game is closed.` : `Couldn't connect to ${room.name}${reason ? ` (${reason})` : ""}.` });
});
App.events.on("p2p.message", ({ session, data }) => {
  let msg;
  try {
    msg = JSON.parse(data);
  } catch {
    return;
  }
  const m = memberBy(session);
  if (m && room?.host) {
    const pi = room.keys.indexOf(m.key);
    if (pi < 1) return;
    if (msg?.t === "roll") roll(room.s, pi);
    else if (msg?.t === "move") move(room.s, pi, msg.piece);
    else return;
    return void broadcast();
  }
  if (!room || room.host || room.session !== session || msg?.t !== "state" || !validState(msg.s)) return;
  if (room.s && msg.s.n <= room.s.n) return;
  if (msg.s.phase === "play" && room.s?.phase !== "play") App.ui.notify(`Ludo with ${room.name} started`);
  room.s = msg.s;
  room.you = Number.isInteger(msg.you) && msg.you < msg.s.players.length ? msg.you : -1;
});

// ---- view ----

const CELL = 34; // an icon button's size; the board's columns and rows both sit 8 points apart
const TILE = "#2b2f3a"; // a plain track square
const ARROWS = ["→", "↓", "←", "↑"]; // each seat's way into the track
const FACES = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];
const ROUND = CELL / 2;

// Sound effects on your own speakers only (never the mic), synthesized into sounds/ by the author.
// shortcut: mute lasts until the plugin restarts; keep it in App.storage if people ask (a new permission).
let muted = false;
const sfx = (name, volume = 0.5) => {
  if (muted) return;
  try {
    App.audio.play(`sounds/${name}.wav`, { volume, mic: false });
  } catch (e) {
    App.log(`Ludo: no sound: ${e.message}`);
  }
};
let wasMyTurn = /** @type {boolean | null} */ (null);

// A roll tumbles for a moment on every screen; movable pieces blink. One timer re-renders while either shows.
let anim = { rolls: -1, until: 0 };
let ticker = 0;
const ticking = (on) => {
  if (on && !ticker) ticker = setInterval(() => {}, 90);
  else if (!on && ticker) (clearInterval(ticker), (ticker = 0));
};
const rolling = (s, now) => {
  const r = s.rolls || 0;
  if (anim.rolls !== r) {
    anim = { rolls: r, until: anim.rolls < 0 ? 0 : now + 650 }; // not on the first look at a game
    if (anim.until) sfx("roll");
  }
  return now < anim.until;
};

// Pieces walk square by square to where they moved; a piece sent home pops back into its yard once the
// capturer lands; the winner's pieces dance for a few seconds.
const STEP = 120;
/** `at`: the last square a hop sounded for; `done`: its landing (or capture) sounded. */
/** @type {{ pieces: number[][] | null; walks: { pi: number; k: number; from: number; to: number; start: number; end: number; at?: number; done?: boolean }[]; overAt: number }} */
let motion = { pieces: null, walks: [], overAt: 0 };
const watchMoves = (s, now) => {
  const was = motion.pieces;
  motion.pieces = s.pieces.map((a) => [...a]); // a copy: the host changes its state in place
  if (s.phase === "over" && !motion.overAt && was && s.winner >= 0) sfx("win", 0.6);
  motion.overAt = s.phase === "over" ? motion.overAt || now : 0;
  if (!was || was.length !== s.pieces.length) return;
  const changed = s.pieces.flatMap((a, pi) => a.flatMap((to, k) => (was[pi][k] === to ? [] : [{ pi, k, from: was[pi][k], to }])));
  if (!changed.length) return;
  const land = now + Math.max(0, ...changed.map((c) => c.to - c.from)) * STEP;
  motion.walks = changed.map((c) => (c.to > c.from ? { ...c, start: now, end: now + (c.to - c.from) * STEP } : { ...c, start: land, end: land + 400 }));
};
const moving = (s, now) => motion.walks.some((w) => now < w.end) || (s.phase === "over" && s.winner >= 0 && now < motion.overAt + 3000);
/** Where piece k of player pi shows right now, and a glyph size while it moves. */
const shown = (s, pi, k, q, now) => {
  if (s.phase === "over" && pi === s.winner && now < motion.overAt + 3000) return { q, size: Math.floor(now / 180) % 2 ? 20 : 9 };
  const w = motion.walks.find((w) => w.pi === pi && w.k === k);
  if (w && now > w.end + 500) w.done = true; // long over (the window was closed): no late sound
  if (!w || (w.done && now >= w.end)) return { q };
  if (w.to > w.from) {
    if (now >= w.end) return (w.done = true), sfx("hop", 0.55), { q }; // lands
    const at = w.from + Math.floor((now - w.start) / STEP);
    if (at !== w.at && at !== w.from) sfx("hop", 0.35);
    w.at = at;
    return { q: at, size: 18 }; // lifted while it walks
  }
  if (now < w.start) return { q: w.from };
  if (!w.done) (w.done = true), sfx("capture", 0.7), setTimeout(() => sfx("pop", 0.45), 160);
  return now < w.end ? { q, size: Math.round(4 + (9 * (now - w.start)) / 400) } : { q };
};


const cell = (glyph, color, size, fill, more) => ({ type: "button", variant: "icon", label: glyph, color, size, fill, radius: 9, ...more });
const posOf = (seat, k, q) => (q < 0 ? YARD[seat][k] : q >= 40 ? HOME[seat][q - 40] : TRACK[cellOf(seat, q)]);

/** The movable piece the pointer is over (SDK 1.6 `onHover`): its path and landing square show before you click. */
let hover = /** @type {{ pi: number; k: number } | null} */ (null);
/** Where piece k of player pi would go with the die: the squares it passes, where it lands and whom it sends home. */
const preview = (s, pi, k) => {
  const seat = s.players[pi].seat;
  const from = s.pieces[pi][k];
  const to = target(s, pi, k, s.dice);
  if (to === null) return null;
  const path = [];
  for (let q = Math.max(0, from + 1); q < to; q++) path.push(posOf(seat, k, q));
  const victims = to < 40 ? s.players.flatMap((o, oi) => (oi === pi ? [] : s.pieces[oi].flatMap((q, j) => (q >= 0 && q < 40 && cellOf(o.seat, q) === cellOf(seat, to) ? [`${oi}:${j}`] : [])))) : [];
  return { seat, to, land: posOf(seat, k, to), path, victims };
};

const boardView = (s, me, tumbling, blink, now) => {
  /** @type {Record<string, any>} */
  const cells = {};
  const put = ([c, r], v) => (cells[`${c},${r}`] = v);
  TRACK.forEach((p) => put(p, cell("", undefined, 12, TILE)));
  for (const k of SEAT4) {
    put(TRACK[k * 10], cell(ARROWS[k], "#ffffff", 18, COLORS[k], { tooltip: `${COLOR_NAMES[k]} starts here` }));
    HOME[k].forEach((p, i) => put(p, cell(i === 3 ? "★" : "", COLORS[k], 16, LIGHT[k], { tooltip: `${COLOR_NAMES[k]}'s way home` })));
    YARD[k].forEach((p) => put(p, cell("", undefined, 14, LIGHT[k], { radius: ROUND, tooltip: `${COLOR_NAMES[k]}'s yard` })));
  }
  const can = s.phase === "play" && s.turn === me && !tumbling ? movable(s) : [];
  if (hover && (hover.pi !== me || !can.includes(hover.k))) hover = null;
  const pv = hover && preview(s, hover.pi, hover.k);
  if (pv) {
    pv.path.forEach((p) => put(p, cell("•", COLORS[pv.seat], 22, TILE)));
    put(pv.land, cell("◎", COLORS[pv.seat], 24, LIGHT[pv.seat], { radius: ROUND, tooltip: pv.to >= 40 ? "Lands in its home lane" : "Lands here" }));
  }
  s.players.forEach((pl, pi) =>
    s.pieces[pi].forEach((real, k) => {
      const mine = pi === me && can.includes(k);
      const hovered = mine && hover?.k === k;
      const doomed = !!pv?.victims.includes(`${pi}:${k}`);
      const { q, size } = shown(s, pi, k, real, now);
      put(posOf(pl.seat, k, q), cell(doomed ? "✕" : "●", "#ffffff", size || (hovered ? 22 : doomed ? 18 : mine && blink ? 20 : 12), COLORS[pl.seat], {
        radius: ROUND,
        tooltip: doomed ? `${pl.name}'s piece goes home` : mine ? `Move this piece ${s.dice}` : `${pl.name}${pl.gone ? " (left)" : ""}`,
        onClick: mine ? () => ((hover = null), act({ t: "move", piece: k })) : undefined,
        onHover: mine ? (on) => void (on ? (hover = { pi, k }) : hover?.k === k && (hover = null)) : undefined,
      }));
    }),
  );
  const rows = [];
  for (let r = 0; r < 11; r++) {
    const row = [];
    for (let c = 0; c < 11; c++) row.push(cells[`${c},${r}`] || { type: "space", size: CELL });
    rows.push({ type: "row", children: row });
  }
  return { type: "group", padding: 14, children: [{ type: "column", spacing: 8, children: rows }] };
};

/** The line under the title while you point at a piece. */
const hoverHint = (s, me) => {
  const pv = hover && hover.pi === me && preview(s, me, hover.k);
  if (!pv) return "";
  const names = [...new Set(pv.victims.map((v) => s.players[Number(v.split(":")[0])].name))];
  return pv.to === 43 ? "This piece reaches the finish" : pv.to >= 40 ? "Into your home lane" : names.length ? `Sends ${names.join(" and ")} home` : `Moves ${s.dice} squares`;
};

const playView = (s, me, note) => {
  const now = Date.now();
  const tumbling = rolling(s, now);
  const myTurn = s.phase === "play" && s.turn === me;
  const canRoll = myTurn && !s.dice && !tumbling;
  const canMove = myTurn && !!s.dice && !tumbling;
  watchMoves(s, now);
  const yourGo = myTurn && !s.dice;
  if (yourGo && wasMyTurn === false) sfx("turn", 0.45);
  wasMyTurn = yourGo || (myTurn && !!wasMyTurn); // a 6 rolling again is the same turn
  const landing = !tumbling && now < anim.until + 220; // the die drops in a little big when it stops
  ticking(tumbling || landing || canMove || moving(s, now));
  const turner = s.players[s.turn];
  const tint = COLORS[(s.phase === "over" && s.winner >= 0 ? s.players[s.winner] : turner).seat];
  // While tumbling a face per 90 ms, picked by the clock so every frame in that slice agrees.
  const face = tumbling ? FACES[(Math.floor(now / 90) * 7 + 3) % 6] : s.last ? FACES[s.last - 1] : FACES[5];
  const title =
    s.phase === "over" ? (s.winner >= 0 ? (s.winner === me ? "You won!" : `${s.players[s.winner].name} won`) : "Game over")
    : tumbling ? "Rolling..."
    : myTurn ? (s.dice ? `You rolled ${s.dice}` : "Your turn")
    : `${turner.name}'s turn`;
  const detail =
    s.phase === "over" ? s.log
    : tumbling ? `${turner.name} is rolling`
    : canMove ? hoverHint(s, me) || "Point at a blinking piece to see where it lands"
    : canRoll ? (s.tries ? `Roll again: ${3 - s.tries} more tries for a 6` : "Roll the die")
    : s.log;
  const die = { type: "button", variant: "icon", label: face, size: tumbling ? (Math.floor(now / 90) % 2 ? 40 : 48) : landing ? 54 : 46, color: s.last || tumbling ? tint : "faint", tooltip: canRoll ? "Roll" : undefined, onClick: canRoll ? () => act({ t: "roll" }) : undefined };
  return [
    {
      type: "bar",
      left: [{ type: "space", size: 4 }, die, { type: "space", size: 6 }, { type: "column", spacing: 2, children: [{ type: "label", text: title, color: tint, strong: true }, { type: "label", text: detail, color: "dim", small: true }] }],
      right: [
        { type: "button", variant: "icon", label: muted ? "🔇" : "🔊", size: 18, tooltip: muted ? "Turn sounds on" : "Mute sounds", onClick: () => (muted = !muted) },
        canRoll && { type: "button", label: "🎲  Roll", variant: "filled", radius: 16, height: 32, onClick: () => act({ t: "roll" }) },
      ],
    },
    { type: "space", size: 4 },
    boardView(s, me, tumbling, Math.floor(now / 450) % 2 === 0, now),
    {
      type: "grid",
      columns: 2,
      fill: true,
      minWidth: 200,
      // A chip per player, filled in its color while it's their go.
      children: s.players.map((p, i) => {
        const up = s.phase === "play" && s.turn === i;
        const home = s.pieces[i].filter((q) => q >= 40).length;
        return {
          type: "button",
          width: "fill",
          height: 34,
          radius: 17,
          color: up ? COLORS[p.seat] : undefined,
          enabled: !p.gone,
          label: `${up ? "▶ " : "● "}${p.name}${i === me ? " (you)" : ""}${p.gone ? " (left)" : ""}  ·  ${home}/4 home`,
          tooltip: `${COLOR_NAMES[p.seat]}${up ? ", to play" : ""}`,
        };
      }),
    },
    { type: "label", text: "Roll a 6 to bring a piece out of its yard. Pieces enter at their arrow and finish at the ★. Land on a piece to send it home; a 6 rolls again.", small: true, color: "faint" },
    note && { type: "label", text: note, small: true, color: "dim" },
    (me < 0 || s.watchers?.length) && { type: "label", text: `${me < 0 ? "You're watching  ·  " : ""}👁 ${s.watchers?.length || 0} watching${s.watchers?.length ? `: ${s.watchers.join(", ")}` : ""}`, small: true, color: "dim" },
    { type: "row", children: leaveButtons(s, me) },
    room?.host && inviting && hostTools(room),
  ];
};

// Leaving a game in progress asks first: the host's leaving closes the game for everyone.
let confirming = false;
/** The host's panel for asking people back to their seat or to watch. */
let inviting = false;
const leaveButtons = (s, me) => {
  const warn = s.phase !== "play" || me < 0 ? "" : room?.host ? "This closes the game for everyone." : "You can come back if the host invites you.";
  if (confirming && warn) return [{ type: "button", label: "Stay", radius: 14, onClick: () => (confirming = false) }, { type: "button", label: "Leave", variant: "filled", radius: 14, onClick: leave }, { type: "label", text: warn, small: true, color: "dim" }];
  return [
    { type: "button", label: s.phase === "over" || me < 0 ? "Close game" : "Leave game", radius: 14, onClick: () => (warn ? (confirming = true) : leave()) },
    room?.host && s.phase === "play" && { type: "button", label: "👁 Invite", radius: 14, selected: inviting, tooltip: "Invite someone to watch, or back to their seat", onClick: () => (inviting = !inviting) },
  ];
};
/** Players who left, to invite back to their seat, and people to invite to watch. */
const hostTools = (r) => {
  const peers = App.p2p.peers();
  const away = seated(r).filter((m) => r.s.players[r.keys.indexOf(m.key)]?.gone);
  const others = peers.filter((p) => !r.members.has(keyOf(p)));
  const full = watchers(r).length >= MAX_WATCHERS;
  return {
    type: "group",
    children: [
      { type: "label", text: "Invite back, or to watch", color: "dim", small: true },
      ...away.map((m) => {
        const peer = peers.find((p) => keyOf(p) === m.key);
        return { type: "bar", left: { type: "label", text: `${m.name} left their seat` }, right: m.session ? waiting(`Asking ${m.name}...`) : peer ? { type: "button", label: "Invite back", radius: 14, onClick: () => invite(peer) } : { type: "label", text: "Offline", small: true, color: "faint" } };
      }),
      ...watchers(r).map((m) => ({ type: "bar", left: m.open ? { type: "label", text: `👁 ${m.name}` } : waiting(`Asking ${m.name} to watch...`), right: { type: "button", label: "Remove", radius: 14, onClick: () => removeMember(m) } })),
      ...others.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: { type: "button", label: "Invite to watch", radius: 14, enabled: !full, onClick: () => invite(p, true) } })),
      !away.length && !others.length && !watchers(r).length && { type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" },
    ],
  };
};

const requestView = (req) => ({
  type: "group",
  children: [
    { type: "label", text: `${req.name} invites you to Ludo`, strong: true },
    { type: "label", text: `Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", radius: 14, onClick: () => accept(req) }, { type: "button", label: "Decline", radius: 14, onClick: () => decline(req) }] },
  ],
});

const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });
const seatDot = (seat) => ({ type: "label", text: "●", color: COLORS[seat] });

const hostLobby = (r) => {
  const ms = seated(r);
  const statusOf = (m) => App.p2p.sessions().find((x) => x.id === m.session)?.status;
  const peers = App.p2p.peers().filter((p) => !r.members.has(keyOf(p)));
  const ready = ms.length > 0 && ms.every((m) => m.open);
  const seats = SEATS[ms.length + 1] || [0];
  return [
    { type: "heading", text: "Your Ludo game" },
    {
      type: "group",
      children: [
        { type: "row", children: [seatDot(seats[0]), { type: "label", text: `${myName()} (you)`, strong: true }] },
        ...ms.map((m, i) => ({
          type: "bar",
          left: m.open ? [seatDot(seats[i + 1]), { type: "label", text: m.name }] : waiting(statusOf(m) === "waiting" ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`),
          right: { type: "button", label: "Remove", radius: 14, onClick: () => removeMember(m) },
        })),
      ],
    },
    watchers(r).length > 0 && {
      type: "group",
      children: [{ type: "label", text: "Watching", small: true, color: "dim" }, ...watchers(r).map((m) => ({ type: "bar", left: m.open ? { type: "label", text: `👁 ${m.name}` } : waiting(`Asking ${m.name} to watch...`), right: { type: "button", label: "Remove", radius: 14, onClick: () => removeMember(m) } }))],
    },
    r.note && { type: "label", text: r.note, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Start game", variant: "filled", radius: 14, enabled: ready, onClick: start }, { type: "button", label: "Cancel", radius: 14, onClick: leave }] },
    !ready && { type: "label", text: ms.length ? "Waiting for everyone to connect..." : "Invite 1 to 3 players to start.", small: true, color: "faint" },
    { type: "space", size: 6 },
    peersView(peers, ms.length < 3),
  ];
};

/** `seats`: whether there's a seat left to invite to; anyone can be invited to watch. */
const peersView = (peers, seats = true) => [
  { type: "label", text: "People you can invite", strong: true },
  {
    type: "scroll",
    spacing: 2,
    children: peers.length
      ? peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: [{ type: "button", label: "To watch", radius: 14, tooltip: "Invite them to watch, without a seat", onClick: () => invite(p, true) }, seats && { type: "button", label: "To play", variant: "filled", radius: 14, onClick: () => invite(p) }] }))
      : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }],
  },
];

const render = () => {
  const reqs = [...requests.values()].map(requestView);
  if (!room?.s || room.s.phase === "lobby") ticking(false);
  if (!room) (hover = null), (anim.rolls = -1), (motion = { pieces: null, walks: [], overAt: 0 }), (wasMyTurn = null), (confirming = inviting = false); // the next game starts still
  if (!room) return [...reqs, { type: "heading", text: "Ludo" }, { type: "label", text: "Invite up to three people from your servers. Everyone needs Ludo installed.", color: "dim" }, { type: "space", size: 6 }, peersView(App.p2p.peers())];
  if (room.host) return [...reqs, ...(room.s.phase === "lobby" ? hostLobby(room) : playView({ ...room.s, watchers: watchers(room).filter((m) => m.open).map((m) => m.name) }, 0, room.note))];
  const r = room;
  // The host gone: the game is closed, wherever it was.
  if (!r.session) return [...reqs, { type: "label", text: r.note, color: "dim" }, { type: "button", label: r.s ? "Close" : "Back", radius: 14, onClick: leave }];
  if (!r.open && r.session) return [...reqs, waiting(`Connecting to ${r.name}...`), { type: "button", label: "Cancel", onClick: leave }];
  if (!r.s) return [...reqs, waiting(`Joining ${r.name}'s game...`)];
  if (r.s.phase === "lobby") {
    const seats = SEATS[r.s.players.length] || [0];
    return [
      ...reqs,
      { type: "heading", text: `${r.name}'s Ludo game` },
      { type: "group", children: r.s.players.map((p, i) => ({ type: "row", children: [seatDot(seats[i]), { type: "label", text: p.name }] })) },
      r.s.watchers?.length > 0 && { type: "label", text: `👁 Watching: ${r.s.watchers.join(", ")}`, small: true, color: "dim" },
      waiting(r.you < 0 ? "You'll watch once the host starts..." : "Waiting for the host to start..."),
      { type: "button", label: "Leave", onClick: leave },
    ];
  }
  return [...reqs, ...playView(r.s, r.you, r.note)];
};

// Its own game-table look (SDK 1.6), whatever the app's theme.
App.ui.registerWindow({
  id: "ludo",
  title: "Ludo",
  width: 560,
  height: 780,
  colors: { bg: "#15171d", text: "#eef0f5", accent: "#f2c14e", surface: "#1d2028", surfaceHigh: "#272b35", surfaceHighest: "#323744", outline: "#363b48", textDim: "#a9afbd", textFaint: "#6f7686" },
  background: "pictures/table.png",
  render,
});
const menuButton = () => App.ui.registerMenu({ id: "ludo", label: "Ludo", icon: "🎲", active: App.ui.isOpen("ludo"), onClick: () => App.ui.toggle("ludo") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", (w) => (menuButton(), w?.id === "ludo" && ticking(false)));
menuButton();
App.onUnload(leave);
