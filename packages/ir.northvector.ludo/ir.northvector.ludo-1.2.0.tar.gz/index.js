// @ts-check
/// <reference path="../../app.d.ts" />
// Ludo for 2-4 players over App.p2p. The host invites the others (one session each) and keeps the game:
// guests send {t:"roll"} and {t:"move", piece: 0-3}, the host checks them against the rules and sends
// everyone {t:"state", s, you}. Nobody plays until every invited player's session is open.
// shortcut: the host rolls every die, so guests trust the host's dice; fine among friends, add commit-reveal rolls for strangers.

const COLORS = ["#e5534b", "#4c8eda", "#2ea043", "#d4a72c"];
const LIGHT = ["#f2b1ad", "#b3cdef", "#a6dcb2", "#efd98f"];
const COLOR_NAMES = ["Red", "Blue", "Green", "Yellow"];
/** Seats by player count: two players sit opposite. */
const SEATS = { 2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3] };

// ---- board: 11×11 cells; Red's quarter, turned 90° clockwise around the middle for each next seat ----

/** @returns {[number, number]} */
const rot = ([c, r], k) => {
  for (let i = 0; i < k; i++) [c, r] = [10 - r, c];
  return [c, r];
};
const QUARTER = [[0, 4], [1, 4], [2, 4], [3, 4], [4, 4], [4, 3], [4, 2], [4, 1], [4, 0], [5, 0]];
const SEAT4 = [0, 1, 2, 3];
/** 40 cells clockwise; seat k starts on TRACK[k * 10]. */
const TRACK = SEAT4.flatMap((k) => QUARTER.map((p) => rot(p, k)));
const HOME = SEAT4.map((k) => [1, 2, 3, 4].map((c) => rot([c, 5], k)));
const YARD = SEAT4.map((k) => [[0, 0], [1, 0], [0, 1], [1, 1]].map((p) => rot(p, k)));

// ---- rules. A piece is -1 in the yard, 0-39 steps along the track from its start, 40-43 home ----

/**
 * @typedef {{ name: string; seat: number; gone?: boolean }} Player
 * @typedef {{ phase: "lobby" | "play" | "over"; players: Player[]; pieces: number[][]; turn: number; dice: number; last: number; tries: number; winner: number; log: string; n: number; rolls?: number }} State
 */
const cellOf = (seat, p) => (seat * 10 + p) % 40;
/** Where piece k of player pi lands with d, or null when it can't move. */
const target = (s, pi, k, d) => {
  const p = s.pieces[pi][k];
  const np = p < 0 ? (d === 6 ? 0 : null) : p + d;
  if (np === null || np > 43) return null;
  if (s.pieces[pi].some((q, j) => j !== k && q === np)) return null; // your own piece is there
  return np;
};
const movable = (s) => (s.dice ? [0, 1, 2, 3].filter((k) => target(s, s.turn, k, s.dice) !== null) : []);

const nextTurn = (s) => {
  Object.assign(s, { dice: 0, tries: 0 });
  for (let i = 1; i <= s.players.length; i++) {
    const t = (s.turn + i) % s.players.length;
    if (!s.players[t].gone) return void (s.turn = t);
  }
};
const roll = (s, pi) => {
  if (s.phase !== "play" || s.turn !== pi || s.dice) return;
  const d = 1 + Math.floor(Math.random() * 6);
  const who = s.players[pi].name;
  Object.assign(s, { dice: d, last: d, rolls: (s.rolls || 0) + 1 });
  if (movable(s).length) return void (s.log = `${who} rolled ${d}`);
  s.dice = 0;
  // Nothing on the track: three tries to roll a 6.
  if (s.pieces[pi].every((p) => p < 0 || p >= 40) && s.tries < 2) return void (s.tries++, (s.log = `${who} rolled ${d}, tries again`));
  s.log = `${who} rolled ${d}, no move`;
  nextTurn(s);
};
const move = (s, pi, k) => {
  if (s.phase !== "play" || s.turn !== pi || !s.dice || !Number.isInteger(k) || k < 0 || k > 3) return;
  const np = target(s, pi, k, s.dice);
  if (np === null) return;
  const me = s.players[pi];
  s.pieces[pi][k] = np;
  s.log = `${me.name} moved`;
  if (np < 40)
    s.players.forEach((o, oi) =>
      s.pieces[oi].forEach((q, j) => {
        if (oi !== pi && q >= 0 && q < 40 && cellOf(o.seat, q) === cellOf(me.seat, np)) (s.pieces[oi][j] = -1), (s.log = `${me.name} sent ${o.name} home`);
      }),
    );
  if (s.pieces[pi].every((p) => p >= 40)) return void Object.assign(s, { phase: "over", winner: pi, dice: 0, log: `${me.name} won!` });
  if (s.dice === 6) Object.assign(s, { dice: 0, tries: 0, log: `${s.log}, rolls again` });
  else nextTurn(s);
};

/** @returns {State} */
const newGame = (names) => {
  const seats = SEATS[names.length];
  return { phase: "play", players: names.map((name, i) => ({ name, seat: seats[i] })), pieces: names.map(() => [-1, -1, -1, -1]), turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: `${names[0]} starts`, n: 0 };
};

// Self-check of the board and the rules.
{
  const ok = (c, what) => c || App.log(`Ludo: ${what} is broken`);
  ok(TRACK.length === 40 && new Set(TRACK.map(String)).size === 40 && String(TRACK[10]) === "6,0" && String(TRACK[30]) === "4,10", "TRACK");
  ok(String(HOME[2][0]) === "9,5" && String(YARD[3][0]) === "0,10", "HOME/YARD");
  const s = newGame(["a", "b"]);
  s.pieces[1][0] = 18; // Green (seat 2) 18 steps out: cell 38
  s.pieces[0][0] = 36; // Red 36 steps out: cell 36, two short of Green
  s.dice = 2;
  move(s, 0, 0);
  ok(s.pieces[0][0] === 38 && s.pieces[1][0] === -1 && s.turn === 1, "capture");
  s.dice = 5;
  ok(movable(s).length === 0 && target(s, 1, 0, 6) === 0, "leaving the yard");
}

// ---- network ----

/**
 * The host's room holds members (one session each); a guest's holds the host's session.
 * @typedef {{ key: string; name: string; connection: number; clientId: number; session: string; open: boolean }} Member
 * @type {null | { host: true; members: Map<string, Member>; keys: string[]; s: State; note: string } | { host: false; name: string; session: string | null; open: boolean; s: State | null; you: number; note: string }}
 */
let room = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const myName = () => {
  const st = App.app.state();
  const c = st.connections.find((c) => c.id === st.active) || st.connections[0];
  return c?.clients.find((x) => x.id === c.ownClientId)?.name || "Host";
};

const sendRaw = (session, msg, tries = 0) => {
  try {
    App.p2p.send(session, msg);
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => sendRaw(session, msg, tries + 1), 500);
    else App.log(`Ludo: not sent: ${e.message}`);
  }
};
/** The host's state to every open member; `n` lets guests drop a late copy of an older one. */
const broadcast = () => {
  if (!room?.host) return;
  const r = room;
  if (r.s.phase === "lobby") r.s.players = [myName(), ...[...r.members.values()].map((m) => m.name)].map((name) => ({ name, seat: 0 }));
  r.s.n++;
  for (const m of r.members.values()) if (m.open) sendRaw(m.session, JSON.stringify({ t: "state", s: r.s, you: r.keys.indexOf(m.key) }));
};
const lobby = () => ({ host: /** @type {true} */ (true), members: new Map(), keys: [""], note: "", s: /** @type {State} */ ({ phase: "lobby", players: [], pieces: [], turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: "", n: 0 }) });

const invite = (peer) => {
  if (room && !room.host) leave();
  if (!room) room = lobby();
  const r = room;
  const key = `${peer.connection}:${peer.clientId}`;
  if (r.s.phase !== "lobby" || r.members.has(key) || r.members.size >= 3) return;
  try {
    r.members.set(key, { key, name: peer.name, connection: peer.connection, clientId: peer.clientId, session: App.p2p.connect(peer.connection, peer.clientId), open: false });
    r.note = "";
  } catch (e) {
    r.note = `Can't reach ${peer.name}: ${e.message}`;
  }
  broadcast();
};
const removeMember = (m) => {
  if (!room?.host) return;
  App.p2p.close(m.session);
  room.members.delete(m.key);
  broadcast();
};
const start = () => {
  if (!room?.host) return;
  const ms = [...room.members.values()];
  if (!ms.length || ms.some((m) => !m.open)) return; // hold everyone until all sessions are open
  room.keys = ["", ...ms.map((m) => m.key)];
  room.s = { ...newGame([myName(), ...ms.map((m) => m.name)]), n: room.s.n };
  broadcast();
};
const leave = () => {
  if (room?.host) for (const m of room.members.values()) App.p2p.close(m.session);
  else if (room?.session) App.p2p.close(room.session);
  room = null;
};
/** The local player's action: applied by the host, sent to the host by a guest. */
const act = (cmd) => {
  if (!room) return;
  if (room.host) {
    if (cmd.t === "roll") roll(room.s, 0);
    else move(room.s, 0, cmd.piece);
    broadcast();
  } else if (room.session && room.open) sendRaw(room.session, JSON.stringify(cmd));
};

const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  room = { host: false, name: req.name, session: req.session, open: false, s: null, you: -1, note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};
const memberBy = (session) => (room?.host ? [...room.members.values()].find((m) => m.session === session) : undefined);

/** The host's state is another person's data: check its shape before drawing it. */
const validState = (s) => {
  const int = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  if (!s || !["lobby", "play", "over"].includes(s.phase) || !Array.isArray(s.players) || !int(s.players.length, 1, 4) || !int(s.n, 0, 1e9)) return false;
  if (!s.players.every((p) => p && typeof p.name === "string" && int(p.seat, 0, 3))) return false;
  if (s.phase === "lobby") return true;
  return (
    new Set(s.players.map((p) => p.seat)).size === s.players.length &&
    Array.isArray(s.pieces) && s.pieces.length === s.players.length && s.pieces.every((a) => Array.isArray(a) && a.length === 4 && a.every((q) => int(q, -1, 43))) &&
    int(s.turn, 0, s.players.length - 1) && int(s.dice, 0, 6) && int(s.last, 0, 6) && int(s.winner, -1, s.players.length - 1) && typeof s.log === "string"
  );
};

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} invites you to Ludo`);
  App.ui.open("ludo");
});
App.events.on("p2p.open", ({ session }) => {
  const m = memberBy(session);
  if (m) return void ((m.open = true), broadcast());
  if (room && !room.host && room.session === session) room.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  // The app answers this way when their side doesn't run Ludo: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? " doesn't have Ludo installed and enabled" : ` left${reason ? ` (${reason})` : ""}`;
  const m = memberBy(session);
  if (m && room?.host) {
    const r = room;
    r.note = `${m.name}${why}.`;
    if (r.s.phase === "lobby") r.members.delete(m.key);
    else if (r.s.phase === "play") {
      const pi = r.keys.indexOf(m.key);
      r.s.players[pi].gone = true;
      r.s.log = `${m.name} left`;
      if (r.s.players.filter((p) => !p.gone).length < 2) Object.assign(r.s, { phase: "over", winner: -1, dice: 0, log: "Everyone else left" });
      else if (r.s.turn === pi) nextTurn(r.s);
    }
    m.open = false;
    return void broadcast();
  }
  if (room && !room.host && room.session === session) Object.assign(room, { session: null, open: false, note: room.s ? `${room.name} (the host)${why}.` : `Couldn't connect to ${room.name}${reason ? ` (${reason})` : ""}.` });
});
App.events.on("p2p.message", ({ session, data }) => {
  let msg;
  try {
    msg = JSON.parse(data);
  } catch {
    return;
  }
  const m = memberBy(session);
  if (m && room?.host) {
    const pi = room.keys.indexOf(m.key);
    if (pi < 1) return;
    if (msg?.t === "roll") roll(room.s, pi);
    else if (msg?.t === "move") move(room.s, pi, msg.piece);
    else return;
    return void broadcast();
  }
  if (!room || room.host || room.session !== session || msg?.t !== "state" || !validState(msg.s)) return;
  if (room.s && msg.s.n <= room.s.n) return;
  if (msg.s.phase === "play" && room.s?.phase !== "play") App.ui.notify(`Ludo with ${room.name} started`);
  room.s = msg.s;
  room.you = Number.isInteger(msg.you) ? msg.you : -1;
});

// ---- view ----

const CELL = 34; // an icon button's size; the board's columns and rows both sit 8 points apart
const TRACK_DOT = "#c9c2b3";
const ARROWS = ["→", "↓", "←", "↑"]; // each seat's way into the track
const FACES = ["⚀", "⚁", "⚂", "⚃", "⚄", "⚅"];

// A roll tumbles for a moment on every screen; movable pieces blink. One timer re-renders while either shows.
let anim = { rolls: -1, until: 0 };
let ticker = 0;
const ticking = (on) => {
  if (on && !ticker) ticker = setInterval(() => {}, 90);
  else if (!on && ticker) (clearInterval(ticker), (ticker = 0));
};
const rolling = (s, now) => {
  const r = s.rolls || 0;
  if (anim.rolls !== r) anim = { rolls: r, until: anim.rolls < 0 ? 0 : now + 650 }; // not on the first look at a game
  return now < anim.until;
};

// Pieces walk square by square to where they moved; a piece sent home pops back into its yard once the
// capturer lands; the winner's pieces dance for a few seconds.
const STEP = 120;
/** @type {{ pieces: number[][] | null; walks: { pi: number; k: number; from: number; to: number; start: number; end: number }[]; overAt: number }} */
let motion = { pieces: null, walks: [], overAt: 0 };
const watchMoves = (s, now) => {
  const was = motion.pieces;
  motion.pieces = s.pieces.map((a) => [...a]); // a copy: the host changes its state in place
  motion.overAt = s.phase === "over" ? motion.overAt || now : 0;
  if (!was || was.length !== s.pieces.length) return;
  const changed = s.pieces.flatMap((a, pi) => a.flatMap((to, k) => (was[pi][k] === to ? [] : [{ pi, k, from: was[pi][k], to }])));
  if (!changed.length) return;
  const land = now + Math.max(0, ...changed.map((c) => c.to - c.from)) * STEP;
  motion.walks = changed.map((c) => (c.to > c.from ? { ...c, start: now, end: now + (c.to - c.from) * STEP } : { ...c, start: land, end: land + 400 }));
};
const moving = (s, now) => motion.walks.some((w) => now < w.end) || (s.phase === "over" && s.winner >= 0 && now < motion.overAt + 3000);
/** Where piece k of player pi shows right now, and a glyph size while it moves. */
const shown = (s, pi, k, q, now) => {
  if (s.phase === "over" && pi === s.winner && now < motion.overAt + 3000) return { q, size: Math.floor(now / 180) % 2 ? 20 : 9 };
  const w = motion.walks.find((w) => w.pi === pi && w.k === k && now < w.end);
  if (!w) return { q };
  if (w.to > w.from) return { q: w.from + Math.floor((now - w.start) / STEP), size: 18 }; // lifted while it walks
  if (now < w.start) return { q: w.from };
  return { q, size: Math.round(4 + (9 * (now - w.start)) / 400) };
};

const cell = (glyph, color, size, fill, more) => ({ type: "button", variant: "icon", label: glyph, color, size, fill, ...more });

const boardView = (s, me, tumbling, blink, now) => {
  /** @type {Record<string, any>} */
  const cells = {};
  const put = ([c, r], v) => (cells[`${c},${r}`] = v);
  TRACK.forEach((p) => put(p, cell("●", TRACK_DOT, 24)));
  for (const k of SEAT4) {
    put(TRACK[k * 10], cell(ARROWS[k], COLORS[k], 20, LIGHT[k], { tooltip: `${COLOR_NAMES[k]} starts here` }));
    HOME[k].forEach((p) => put(p, cell("●", COLORS[k], 24, undefined, { tooltip: `${COLOR_NAMES[k]}'s way home` })));
    YARD[k].forEach((p) => put(p, cell("", COLORS[k], 14, LIGHT[k], { tooltip: `${COLOR_NAMES[k]}'s yard` })));
  }
  const can = s.phase === "play" && s.turn === me && !tumbling ? movable(s) : [];
  s.players.forEach((pl, pi) =>
    s.pieces[pi].forEach((real, k) => {
      const mine = pi === me && can.includes(k);
      const { q, size } = shown(s, pi, k, real, now);
      put(q < 0 ? YARD[pl.seat][k] : q >= 40 ? HOME[pl.seat][q - 40] : TRACK[cellOf(pl.seat, q)], cell("●", "#ffffff", size || (mine && blink ? 22 : 13), COLORS[pl.seat], {
        tooltip: mine ? `Move this piece ${s.dice}` : `${pl.name}${pl.gone ? " (left)" : ""}`,
        onClick: mine ? () => act({ t: "move", piece: k }) : undefined,
      }));
    }),
  );
  const rows = [];
  for (let r = 0; r < 11; r++) {
    const row = [];
    for (let c = 0; c < 11; c++) row.push(cells[`${c},${r}`] || { type: "space", size: CELL });
    rows.push({ type: "row", children: row });
  }
  return { type: "group", padding: 14, children: [{ type: "column", spacing: 8, children: rows }] };
};

const playView = (s, me, note) => {
  const now = Date.now();
  const tumbling = rolling(s, now);
  const myTurn = s.phase === "play" && s.turn === me;
  const canRoll = myTurn && !s.dice && !tumbling;
  const canMove = myTurn && !!s.dice && !tumbling;
  watchMoves(s, now);
  const landing = !tumbling && now < anim.until + 220; // the die drops in a little big when it stops
  ticking(tumbling || landing || canMove || moving(s, now));
  const turner = s.players[s.turn];
  const tint = COLORS[(s.phase === "over" && s.winner >= 0 ? s.players[s.winner] : turner).seat];
  // While tumbling a face per 90 ms, picked by the clock so every frame in that slice agrees.
  const face = tumbling ? FACES[(Math.floor(now / 90) * 7 + 3) % 6] : s.last ? FACES[s.last - 1] : FACES[5];
  const title =
    s.phase === "over" ? (s.winner >= 0 ? (s.winner === me ? "You won!" : `${s.players[s.winner].name} won`) : "Game over")
    : tumbling ? "Rolling..."
    : myTurn ? (s.dice ? `You rolled ${s.dice}` : "Your turn")
    : `${turner.name}'s turn`;
  const detail =
    s.phase === "over" ? s.log
    : tumbling ? `${turner.name} is rolling`
    : canMove ? "Pick one of your blinking pieces"
    : canRoll ? (s.tries ? `Roll again: ${3 - s.tries} more tries for a 6` : "Roll the die")
    : s.log;
  const die = { type: "button", variant: "icon", label: face, size: tumbling ? (Math.floor(now / 90) % 2 ? 40 : 48) : landing ? 54 : 46, color: s.last || tumbling ? tint : "faint", tooltip: canRoll ? "Roll" : undefined, onClick: canRoll ? () => act({ t: "roll" }) : undefined };
  return [
    {
      type: "bar",
      left: [{ type: "space", size: 4 }, die, { type: "space", size: 6 }, { type: "column", spacing: 2, children: [{ type: "label", text: title, color: tint, strong: true }, { type: "label", text: detail, color: "dim", small: true }] }],
      right: canRoll && { type: "button", label: "Roll", variant: "filled", onClick: () => act({ t: "roll" }) },
    },
    { type: "space", size: 4 },
    boardView(s, me, tumbling, Math.floor(now / 450) % 2 === 0, now),
    {
      type: "grid",
      columns: 2,
      fill: true,
      minWidth: 200,
      children: s.players.map((p, i) => ({
        type: "row",
        children: [
          { type: "label", text: `● ${COLOR_NAMES[p.seat]}`, color: COLORS[p.seat], strong: true },
          { type: "label", text: `${p.name}${i === me ? " (you)" : ""}${p.gone ? " (left)" : ""}`, color: p.gone ? "faint" : undefined, strong: s.phase === "play" && s.turn === i },
          s.phase === "play" && s.turn === i && { type: "label", text: "to play", small: true, color: "dim" },
        ],
      })),
    },
    { type: "label", text: "Each color has a tinted corner (its yard: roll a 6 to bring a piece out), an arrow where it enters the track, and a colored lane that leads to its finish. Land on a piece to send it home. A 6 rolls again.", small: true, color: "faint" },
    note && { type: "label", text: note, small: true, color: "dim" },
    { type: "button", label: s.phase === "over" ? "Close game" : "Leave game", onClick: leave },
  ];
};

const requestView = (req) => ({
  type: "group",
  children: [
    { type: "label", text: `${req.name} invites you to Ludo`, strong: true },
    { type: "label", text: `Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", onClick: () => accept(req) }, { type: "button", label: "Decline", onClick: () => decline(req) }] },
  ],
});

const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });
const seatDot = (seat) => ({ type: "label", text: "●", color: COLORS[seat] });

const hostLobby = (r) => {
  const ms = [...r.members.values()];
  const statusOf = (m) => App.p2p.sessions().find((x) => x.id === m.session)?.status;
  const peers = App.p2p.peers().filter((p) => !r.members.has(`${p.connection}:${p.clientId}`));
  const ready = ms.length > 0 && ms.every((m) => m.open);
  const seats = SEATS[ms.length + 1] || [0];
  return [
    { type: "heading", text: "Your Ludo game" },
    {
      type: "group",
      children: [
        { type: "row", children: [seatDot(seats[0]), { type: "label", text: `${myName()} (you)`, strong: true }] },
        ...ms.map((m, i) => ({
          type: "bar",
          left: m.open ? [seatDot(seats[i + 1]), { type: "label", text: m.name }] : waiting(statusOf(m) === "waiting" ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`),
          right: { type: "button", label: "Remove", onClick: () => removeMember(m) },
        })),
      ],
    },
    r.note && { type: "label", text: r.note, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Start game", variant: "filled", enabled: ready, onClick: start }, { type: "button", label: "Cancel", onClick: leave }] },
    !ready && { type: "label", text: ms.length ? "Waiting for everyone to connect..." : "Invite 1 to 3 players to start.", small: true, color: "faint" },
    ms.length < 3 && { type: "space", size: 6 },
    ms.length < 3 && peersView(peers),
  ];
};

const peersView = (peers) => [
  { type: "label", text: "People you can invite", strong: true },
  {
    type: "scroll",
    spacing: 2,
    children: peers.length
      ? peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: { type: "button", label: "Invite", onClick: () => invite(p) } }))
      : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }],
  },
];

const render = () => {
  const reqs = [...requests.values()].map(requestView);
  if (!room?.s || room.s.phase === "lobby") ticking(false);
  if (!room) (anim.rolls = -1), (motion = { pieces: null, walks: [], overAt: 0 }); // the next game starts still
  if (!room) return [...reqs, { type: "heading", text: "Ludo" }, { type: "label", text: "Invite up to three people from your servers. Everyone needs Ludo installed.", color: "dim" }, { type: "space", size: 6 }, peersView(App.p2p.peers())];
  if (room.host) return [...reqs, ...(room.s.phase === "lobby" ? hostLobby(room) : playView(room.s, 0, room.note))];
  const r = room;
  if (!r.session && (!r.s || r.s.phase === "lobby")) return [...reqs, { type: "label", text: r.note, color: "dim" }, { type: "button", label: "Back", onClick: leave }];
  if (!r.open && r.session) return [...reqs, waiting(`Connecting to ${r.name}...`), { type: "button", label: "Cancel", onClick: leave }];
  if (!r.s) return [...reqs, waiting(`Joining ${r.name}'s game...`)];
  if (r.s.phase === "lobby") {
    const seats = SEATS[r.s.players.length] || [0];
    return [
      ...reqs,
      { type: "heading", text: `${r.name}'s Ludo game` },
      { type: "group", children: r.s.players.map((p, i) => ({ type: "row", children: [seatDot(seats[i]), { type: "label", text: p.name }] })) },
      waiting("Waiting for the host to start..."),
      { type: "button", label: "Leave", onClick: leave },
    ];
  }
  return [...reqs, ...playView(r.s, r.you, r.note)];
};

App.ui.registerWindow({ id: "ludo", title: "Ludo", width: 560, height: 760, render });
const menuButton = () => App.ui.registerMenu({ id: "ludo", label: "Ludo", icon: "🎲", active: App.ui.isOpen("ludo"), onClick: () => App.ui.toggle("ludo") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", (w) => (menuButton(), w?.id === "ludo" && ticking(false)));
menuButton();
App.onUnload(leave);
