// @ts-check
/// <reference path="../../app.d.ts" />
// Ludo for 2-4 players over App.p2p. The host invites the others (one session each) and keeps the game:
// guests send {t:"roll"} and {t:"move", piece: 0-3}, the host checks them against the rules and sends
// everyone {t:"state", s, you}. Nobody plays until every invited player's session is open.
// shortcut: the host rolls every die, so guests trust the host's dice; fine among friends, add commit-reveal rolls for strangers.

const COLORS = ["#e5534b", "#4c8eda", "#2ea043", "#d4a72c"];
const LIGHT = ["#f2b1ad", "#b3cdef", "#a6dcb2", "#efd98f"];
const COLOR_NAMES = ["Red", "Blue", "Green", "Yellow"];
/** Seats by player count: two players sit opposite. */
const SEATS = { 2: [0, 2], 3: [0, 1, 2], 4: [0, 1, 2, 3] };

// ---- board: 11×11 cells; Red's quarter, turned 90° clockwise around the middle for each next seat ----

/** @returns {[number, number]} */
const rot = ([c, r], k) => {
  for (let i = 0; i < k; i++) [c, r] = [10 - r, c];
  return [c, r];
};
const QUARTER = [[0, 4], [1, 4], [2, 4], [3, 4], [4, 4], [4, 3], [4, 2], [4, 1], [4, 0], [5, 0]];
const SEAT4 = [0, 1, 2, 3];
/** 40 cells clockwise; seat k starts on TRACK[k * 10]. */
const TRACK = SEAT4.flatMap((k) => QUARTER.map((p) => rot(p, k)));
const HOME = SEAT4.map((k) => [1, 2, 3, 4].map((c) => rot([c, 5], k)));
const YARD = SEAT4.map((k) => [[0, 0], [1, 0], [0, 1], [1, 1]].map((p) => rot(p, k)));

// ---- rules. A piece is -1 in the yard, 0-39 steps along the track from its start, 40-43 home ----

/**
 * @typedef {{ name: string; seat: number; gone?: boolean }} Player
 * @typedef {{ phase: "lobby" | "play" | "over"; players: Player[]; pieces: number[][]; turn: number; dice: number; last: number; tries: number; winner: number; log: string; n: number }} State
 */
const cellOf = (seat, p) => (seat * 10 + p) % 40;
/** Where piece k of player pi lands with d, or null when it can't move. */
const target = (s, pi, k, d) => {
  const p = s.pieces[pi][k];
  const np = p < 0 ? (d === 6 ? 0 : null) : p + d;
  if (np === null || np > 43) return null;
  if (s.pieces[pi].some((q, j) => j !== k && q === np)) return null; // your own piece is there
  return np;
};
const movable = (s) => (s.dice ? [0, 1, 2, 3].filter((k) => target(s, s.turn, k, s.dice) !== null) : []);

const nextTurn = (s) => {
  Object.assign(s, { dice: 0, tries: 0 });
  for (let i = 1; i <= s.players.length; i++) {
    const t = (s.turn + i) % s.players.length;
    if (!s.players[t].gone) return void (s.turn = t);
  }
};
const roll = (s, pi) => {
  if (s.phase !== "play" || s.turn !== pi || s.dice) return;
  const d = 1 + Math.floor(Math.random() * 6);
  const who = s.players[pi].name;
  Object.assign(s, { dice: d, last: d });
  if (movable(s).length) return void (s.log = `${who} rolled ${d}`);
  s.dice = 0;
  // Nothing on the track: three tries to roll a 6.
  if (s.pieces[pi].every((p) => p < 0 || p >= 40) && s.tries < 2) return void (s.tries++, (s.log = `${who} rolled ${d}, tries again`));
  s.log = `${who} rolled ${d}, no move`;
  nextTurn(s);
};
const move = (s, pi, k) => {
  if (s.phase !== "play" || s.turn !== pi || !s.dice || !Number.isInteger(k) || k < 0 || k > 3) return;
  const np = target(s, pi, k, s.dice);
  if (np === null) return;
  const me = s.players[pi];
  s.pieces[pi][k] = np;
  s.log = `${me.name} moved`;
  if (np < 40)
    s.players.forEach((o, oi) =>
      s.pieces[oi].forEach((q, j) => {
        if (oi !== pi && q >= 0 && q < 40 && cellOf(o.seat, q) === cellOf(me.seat, np)) (s.pieces[oi][j] = -1), (s.log = `${me.name} sent ${o.name} home`);
      }),
    );
  if (s.pieces[pi].every((p) => p >= 40)) return void Object.assign(s, { phase: "over", winner: pi, dice: 0, log: `${me.name} won!` });
  if (s.dice === 6) Object.assign(s, { dice: 0, tries: 0, log: `${s.log}, rolls again` });
  else nextTurn(s);
};

/** @returns {State} */
const newGame = (names) => {
  const seats = SEATS[names.length];
  return { phase: "play", players: names.map((name, i) => ({ name, seat: seats[i] })), pieces: names.map(() => [-1, -1, -1, -1]), turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: `${names[0]} starts`, n: 0 };
};

// Self-check of the board and the rules.
{
  const ok = (c, what) => c || App.log(`Ludo: ${what} is broken`);
  ok(TRACK.length === 40 && new Set(TRACK.map(String)).size === 40 && String(TRACK[10]) === "6,0" && String(TRACK[30]) === "4,10", "TRACK");
  ok(String(HOME[2][0]) === "9,5" && String(YARD[3][0]) === "0,10", "HOME/YARD");
  const s = newGame(["a", "b"]);
  s.pieces[1][0] = 18; // Green (seat 2) 18 steps out: cell 38
  s.pieces[0][0] = 36; // Red 36 steps out: cell 36, two short of Green
  s.dice = 2;
  move(s, 0, 0);
  ok(s.pieces[0][0] === 38 && s.pieces[1][0] === -1 && s.turn === 1, "capture");
  s.dice = 5;
  ok(movable(s).length === 0 && target(s, 1, 0, 6) === 0, "leaving the yard");
}

// ---- network ----

/**
 * The host's room holds members (one session each); a guest's holds the host's session.
 * @typedef {{ key: string; name: string; connection: number; clientId: number; session: string; open: boolean }} Member
 * @type {null | { host: true; members: Map<string, Member>; keys: string[]; s: State; note: string } | { host: false; name: string; session: string | null; open: boolean; s: State | null; you: number; note: string }}
 */
let room = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const myName = () => {
  const st = App.app.state();
  const c = st.connections.find((c) => c.id === st.active) || st.connections[0];
  return c?.clients.find((x) => x.id === c.ownClientId)?.name || "Host";
};

const sendRaw = (session, msg, tries = 0) => {
  try {
    App.p2p.send(session, msg);
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => sendRaw(session, msg, tries + 1), 500);
    else App.log(`Ludo: not sent: ${e.message}`);
  }
};
/** The host's state to every open member; `n` lets guests drop a late copy of an older one. */
const broadcast = () => {
  if (!room?.host) return;
  const r = room;
  if (r.s.phase === "lobby") r.s.players = [myName(), ...[...r.members.values()].map((m) => m.name)].map((name) => ({ name, seat: 0 }));
  r.s.n++;
  for (const m of r.members.values()) if (m.open) sendRaw(m.session, JSON.stringify({ t: "state", s: r.s, you: r.keys.indexOf(m.key) }));
};
const lobby = () => ({ host: /** @type {true} */ (true), members: new Map(), keys: [""], note: "", s: /** @type {State} */ ({ phase: "lobby", players: [], pieces: [], turn: 0, dice: 0, last: 0, tries: 0, winner: -1, log: "", n: 0 }) });

const invite = (peer) => {
  if (room && !room.host) leave();
  if (!room) room = lobby();
  const r = room;
  const key = `${peer.connection}:${peer.clientId}`;
  if (r.s.phase !== "lobby" || r.members.has(key) || r.members.size >= 3) return;
  try {
    r.members.set(key, { key, name: peer.name, connection: peer.connection, clientId: peer.clientId, session: App.p2p.connect(peer.connection, peer.clientId), open: false });
    r.note = "";
  } catch (e) {
    r.note = `Can't reach ${peer.name}: ${e.message}`;
  }
  broadcast();
};
const removeMember = (m) => {
  if (!room?.host) return;
  App.p2p.close(m.session);
  room.members.delete(m.key);
  broadcast();
};
const start = () => {
  if (!room?.host) return;
  const ms = [...room.members.values()];
  if (!ms.length || ms.some((m) => !m.open)) return; // hold everyone until all sessions are open
  room.keys = ["", ...ms.map((m) => m.key)];
  room.s = { ...newGame([myName(), ...ms.map((m) => m.name)]), n: room.s.n };
  broadcast();
};
const leave = () => {
  if (room?.host) for (const m of room.members.values()) App.p2p.close(m.session);
  else if (room?.session) App.p2p.close(room.session);
  room = null;
};
/** The local player's action: applied by the host, sent to the host by a guest. */
const act = (cmd) => {
  if (!room) return;
  if (room.host) {
    if (cmd.t === "roll") roll(room.s, 0);
    else move(room.s, 0, cmd.piece);
    broadcast();
  } else if (room.session && room.open) sendRaw(room.session, JSON.stringify(cmd));
};

const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  room = { host: false, name: req.name, session: req.session, open: false, s: null, you: -1, note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};
const memberBy = (session) => (room?.host ? [...room.members.values()].find((m) => m.session === session) : undefined);

/** The host's state is another person's data: check its shape before drawing it. */
const validState = (s) => {
  const int = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  if (!s || !["lobby", "play", "over"].includes(s.phase) || !Array.isArray(s.players) || !int(s.players.length, 1, 4) || !int(s.n, 0, 1e9)) return false;
  if (!s.players.every((p) => p && typeof p.name === "string" && int(p.seat, 0, 3))) return false;
  if (s.phase === "lobby") return true;
  return (
    new Set(s.players.map((p) => p.seat)).size === s.players.length &&
    Array.isArray(s.pieces) && s.pieces.length === s.players.length && s.pieces.every((a) => Array.isArray(a) && a.length === 4 && a.every((q) => int(q, -1, 43))) &&
    int(s.turn, 0, s.players.length - 1) && int(s.dice, 0, 6) && int(s.last, 0, 6) && int(s.winner, -1, s.players.length - 1) && typeof s.log === "string"
  );
};

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} invites you to Ludo`);
  App.ui.open("ludo");
});
App.events.on("p2p.open", ({ session }) => {
  const m = memberBy(session);
  if (m) return void ((m.open = true), broadcast());
  if (room && !room.host && room.session === session) room.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  // The app answers this way when their side doesn't run Ludo: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? " doesn't have Ludo installed and enabled" : ` left${reason ? ` (${reason})` : ""}`;
  const m = memberBy(session);
  if (m && room?.host) {
    const r = room;
    r.note = `${m.name}${why}.`;
    if (r.s.phase === "lobby") r.members.delete(m.key);
    else if (r.s.phase === "play") {
      const pi = r.keys.indexOf(m.key);
      r.s.players[pi].gone = true;
      r.s.log = `${m.name} left`;
      if (r.s.players.filter((p) => !p.gone).length < 2) Object.assign(r.s, { phase: "over", winner: -1, dice: 0, log: "Everyone else left" });
      else if (r.s.turn === pi) nextTurn(r.s);
    }
    m.open = false;
    return void broadcast();
  }
  if (room && !room.host && room.session === session) Object.assign(room, { session: null, open: false, note: room.s ? `${room.name} (the host)${why}.` : `Couldn't connect to ${room.name}${reason ? ` (${reason})` : ""}.` });
});
App.events.on("p2p.message", ({ session, data }) => {
  let msg;
  try {
    msg = JSON.parse(data);
  } catch {
    return;
  }
  const m = memberBy(session);
  if (m && room?.host) {
    const pi = room.keys.indexOf(m.key);
    if (pi < 1) return;
    if (msg?.t === "roll") roll(room.s, pi);
    else if (msg?.t === "move") move(room.s, pi, msg.piece);
    else return;
    return void broadcast();
  }
  if (!room || room.host || room.session !== session || msg?.t !== "state" || !validState(msg.s)) return;
  if (room.s && msg.s.n <= room.s.n) return;
  if (msg.s.phase === "play" && room.s?.phase !== "play") App.ui.notify(`Ludo with ${room.name} started`);
  room.s = msg.s;
  room.you = Number.isInteger(msg.you) ? msg.you : -1;
});

// ---- view ----

const CELL = 34;
const boardView = (s, me) => {
  /** @type {Record<string, any>} */
  const cells = {};
  const put = ([c, r], v) => (cells[`${c},${r}`] = v);
  TRACK.forEach((p, i) => put(p, { color: i % 10 ? "#eeeeee" : LIGHT[i / 10] }));
  for (const k of SEAT4) [...HOME[k], ...YARD[k]].forEach((p) => put(p, { color: LIGHT[k] }));
  const can = s.phase === "play" && s.turn === me ? movable(s) : [];
  s.players.forEach((pl, pi) =>
    s.pieces[pi].forEach((q, k) => {
      const mine = pi === me && can.includes(k);
      put(q < 0 ? YARD[pl.seat][k] : q >= 40 ? HOME[pl.seat][q - 40] : TRACK[cellOf(pl.seat, q)], {
        color: COLORS[pl.seat],
        label: mine ? `[${k + 1}]` : `${k + 1}`,
        tooltip: mine ? "Move this piece" : pl.name,
        onClick: mine ? () => act({ t: "move", piece: k }) : undefined,
      });
    }),
  );
  const rows = [];
  for (let r = 0; r < 11; r++) {
    const row = [];
    for (let c = 0; c < 11; c++) row.push({ type: "button", label: " ", width: CELL, height: CELL, color: "surface", ...cells[`${c},${r}`] });
    rows.push({ type: "row", children: row });
  }
  return { type: "column", spacing: 4, children: rows };
};

const playView = (s, me, note) => {
  const myTurn = s.phase === "play" && s.turn === me;
  return [
    {
      type: "row",
      children: s.players.map((p, i) => ({
        type: "label",
        text: `${s.phase === "play" && s.turn === i ? "▶ " : ""}${p.name}${i === me ? " (you)" : ""}${p.gone ? " (left)" : ""}`,
        color: COLORS[p.seat],
        strong: s.turn === i,
      })),
    },
    {
      type: "row",
      children: [
        { type: "button", label: myTurn && !s.dice ? "Roll" : `🎲 ${s.last || "-"}`, variant: "filled", enabled: myTurn && !s.dice, onClick: () => act({ t: "roll" }) },
        { type: "label", text: s.phase === "over" ? s.log : myTurn ? (s.dice ? `You rolled ${s.dice}: pick a piece marked [ ]` : "Your turn: roll the die") : s.log, color: "dim" },
      ],
    },
    boardView(s, me),
    note && { type: "label", text: note, small: true, color: "dim" },
    { type: "button", label: s.phase === "over" ? "Close game" : "Leave game", onClick: leave },
  ];
};

const requestView = (req) => ({
  type: "group",
  children: [
    `${req.name} invites you to Ludo. Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`,
    { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", onClick: () => accept(req) }, { type: "button", label: "Decline", onClick: () => decline(req) }] },
  ],
});

const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });

const hostLobby = (r) => {
  const ms = [...r.members.values()];
  const statusOf = (m) => App.p2p.sessions().find((x) => x.id === m.session)?.status;
  const peers = App.p2p.peers().filter((p) => !r.members.has(`${p.connection}:${p.clientId}`));
  const ready = ms.length > 0 && ms.every((m) => m.open);
  return [
    { type: "heading", text: "Your Ludo game" },
    { type: "label", text: `${COLOR_NAMES[0]}: ${myName()} (you)`, color: COLORS[0] },
    ...ms.map((m) => ({
      type: "row",
      children: [
        m.open ? { type: "label", text: `✓ ${m.name}`, color: "green" } : waiting(statusOf(m) === "waiting" ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`),
        { type: "button", label: "Remove", onClick: () => removeMember(m) },
      ],
    })),
    r.note && { type: "label", text: r.note, small: true, color: "dim" },
    { type: "row", children: [{ type: "button", label: "Start", variant: "filled", enabled: ready, onClick: start }, { type: "button", label: "Cancel", onClick: leave }] },
    !ready && { type: "label", text: ms.length ? "Waiting for everyone to connect..." : "Invite 1 to 3 players.", small: true, color: "faint" },
    ms.length < 3 && { type: "separator" },
    ms.length < 3 && peersView(peers),
  ];
};

const peersView = (peers) => ({
  type: "scroll",
  spacing: 4,
  children: peers.length
    ? peers.map((p) => ({ type: "row", children: [{ type: "label", text: p.name }, { type: "button", label: "Invite", onClick: () => invite(p) }] }))
    : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }],
});

const render = () => {
  const reqs = [...requests.values()].map(requestView);
  if (!room) return [...reqs, { type: "heading", text: "Ludo" }, { type: "label", text: "Invite up to three people to play.", color: "dim" }, peersView(App.p2p.peers())];
  if (room.host) return [...reqs, ...(room.s.phase === "lobby" ? hostLobby(room) : playView(room.s, 0, room.note))];
  const r = room;
  if (!r.session && (!r.s || r.s.phase === "lobby")) return [...reqs, { type: "label", text: r.note, color: "dim" }, { type: "button", label: "Back", onClick: leave }];
  if (!r.open && r.session) return [...reqs, waiting(`Connecting to ${r.name}...`), { type: "button", label: "Cancel", onClick: leave }];
  if (!r.s) return [...reqs, waiting(`Joining ${r.name}'s game...`)];
  if (r.s.phase === "lobby")
    return [
      ...reqs,
      { type: "heading", text: `${r.name}'s Ludo game` },
      ...r.s.players.map((p) => ({ type: "label", text: p.name })),
      waiting("Waiting for the host to start..."),
      { type: "button", label: "Leave", onClick: leave },
    ];
  return [...reqs, ...playView(r.s, r.you, r.note)];
};

App.ui.registerWindow({ id: "ludo", title: "Ludo", width: 560, height: 760, render });
const menuButton = () => App.ui.registerMenu({ id: "ludo", label: "Ludo", icon: "🎲", active: App.ui.isOpen("ludo"), onClick: () => App.ui.toggle("ludo") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", menuButton);
menuButton();
App.onUnload(leave);
