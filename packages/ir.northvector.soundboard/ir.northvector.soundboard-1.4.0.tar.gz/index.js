import { toolbar, padGrid, playbar } from "./components/pads.js";

const store = App.storage.create("soundboard");
let nextId = store.get("nextId", 1);
// Migration: 0.x kept only file names, 1.0 had no ids (hotkeys followed the position).
let pads = store.get("pads", []).map((p) => (typeof p === "string" ? { name: p, file: p, volume: 1 } : p));
pads.forEach((p) => (p.id ??= nextId++));
const fileName = (file) => file.split(/[:\\/]/).pop().replace(/\.[^.]+$/, "");
// The title in the sound's tags; null for a file that's gone or has none.
const titleOf = (file) => {
	try {
		return App.audio.title(file);
	} catch {
		return null;
	}
};
// Migration: before 1.4 pads had no date (ids count up, so they still sort by age) and were named after their file.
pads.forEach((p) => {
	p.added ??= p.id;
	if (!p.titled) {
		p.titled = true;
		if (p.name === fileName(p.file)) p.name = titleOf(p.file) || p.name;
	}
});
// What the channel hears and what we hear ourselves (1.1 had one volume for both).
let channelVolume = store.get("masterVolume", 80);
let myVolume = store.get("myVolume", channelVolume);
// Into the microphone so the channel hears it, and also in our own speakers.
let toChannel = store.get("toChannel", true);
let hearIt = store.get("hearIt", true);
// Starting a sound stops the others.
let solo = store.get("solo", false);
let columns = store.get("columns", 4);
// "manual", "name" or "date"; pinned pads come first in any of them.
let sort = store.get("sort", "manual");
let settingsOpen = store.get("settingsOpen", false);
let query = "";
let url = "";
let downloading = false;
// Pad id -> the voice playing it.
const playing = new Map();

const save = () => {
	store.set("pads", pads);
	store.set("nextId", nextId);
};
const padById = (id) => pads.find((p) => p.id === id);

const volumes = (pad) => [(channelVolume / 100) * (pad.volume ?? 1), (myVolume / 100) * (pad.volume ?? 1)];
const updateVolumes = () => playing.forEach((voice, id) => App.audio.setVolume(voice, ...volumes(padById(id))));

function stopAll() {
	App.audio.stopAll();
	playing.clear();
}

// `locally`: only in our own speakers, whatever "Send to channel" says.
function play(id, locally = false) {
	const pad = padById(id);
	if (!pad) return;
	if (playing.has(id)) {
		App.audio.stop(playing.get(id));
		playing.delete(id);
		if (!locally) return;
	}
	if (solo) stopAll();
	const [volume, localVolume] = volumes(pad);
	try {
		playing.set(id, App.audio.play(pad.file, { volume, localVolume, loop: !!pad.loop, mic: toChannel && !locally, local: hearIt || locally }));
	} catch (e) {
		App.ui.notify(`${pad.name}: ${e.message}`, "error");
	}
}

App.events.on("audio.ended", ({ id }) => {
	for (const [p, v] of playing) if (v === id) playing.delete(p);
});

// The first nine pads get Ctrl+Shift+1..9; the user sets others from a pad's right click menu.
const bindPad = (pad, i) => App.hotkeys.register({ id: `pad-${pad.id}`, label: `Play "${pad.name}"`, accelerator: i < 9 ? `Ctrl+Shift+${i + 1}` : "", onPressed: () => play(pad.id) });
function bindHotkeys() {
	pads.forEach(bindPad);
	App.hotkeys.register({ id: "stop-all", label: "Stop all sounds", accelerator: "Ctrl+Shift+0", onPressed: stopAll });
}

function addPad(file) {
	const pad = { id: nextId++, name: titleOf(file) || fileName(file), file, volume: 1, loop: false, added: Date.now(), titled: true };
	pads.push(pad);
	bindPad(pad, pads.length - 1);
	return pad;
}

function addSounds() {
	const files = App.audio.import({ multiple: true }) || [];
	files.forEach(addPad);
	save();
}

// Downloads the sound once, keeps it as a pad and plays it.
async function playUrl() {
	const address = url.trim();
	if (!address || downloading) return;
	const known = pads.find((p) => p.url === address);
	if (known) return play(known.id);
	downloading = true;
	try {
		const pad = addPad(await App.audio.importUrl(address));
		pad.url = address;
		save();
		url = "";
		play(pad.id);
	} catch (e) {
		App.ui.notify(e.message, "error");
	} finally {
		downloading = false;
	}
}

function remove(id) {
	const i = pads.findIndex((p) => p.id === id);
	if (i < 0) return;
	if (playing.has(id)) App.audio.stop(playing.get(id));
	playing.delete(id);
	// Another pad may use the same imported file.
	if (!pads.some((p) => p.id !== id && p.file === pads[i].file)) App.audio.removeImported(pads[i].file);
	pads.splice(i, 1);
	App.hotkeys.unregister(`pad-${id}`);
	save();
}

function move(id, by) {
	const i = pads.findIndex((p) => p.id === id);
	const j = i + by;
	if (i < 0 || j < 0 || j >= pads.length) return;
	[pads[i], pads[j]] = [pads[j], pads[i]];
	save();
	bindHotkeys();
}

const COLORS = ["#e74c3c", "#e67e22", "#f1c40f", "#2ecc71", "#1abc9c", "#3498db", "#9b59b6", "#e91e63"];
const setColor = (pad, color) => {
	pad.color = color;
	save();
};

// A pad's right click menu.
const menu = (pad, keys) => {
	const i = pads.indexOf(pad);
	const hotkey = `pad-${pad.id}`;
	return [
		{ type: "button", label: "🔈 Play locally (speakers)", tooltip: "Only you hear it", onClick: () => play(pad.id, true) },
		{ type: "separator" },
		{
			type: "input",
			value: pad.name,
			hint: "Name",
			width: 220,
			onChange: (v) => {
				pad.name = v;
				save();
				bindPad(pad, i);
			},
		},
		{
			type: "row",
			children: [
				{ type: "label", text: `Hotkey: ${keys}` },
				{ type: "button", label: "⌨ Set…", onClick: () => App.hotkeys.record(hotkey) },
			],
		},
		{
			type: "slider",
			label: "Volume",
			value: Math.round((pad.volume ?? 1) * 100),
			min: 0,
			max: 200,
			step: 1,
			suffix: "%",
			onChange: (v) => {
				pad.volume = v / 100;
				save();
				updateVolumes();
			},
		},
		{
			type: "checkbox",
			label: "Loop until stopped",
			checked: !!pad.loop,
			onChange: (v) => {
				pad.loop = v;
				save();
			},
		},
		{
			type: "checkbox",
			label: "Pin to the top",
			checked: !!pad.pinned,
			onChange: (v) => {
				pad.pinned = v;
				save();
			},
		},
		{
			type: "row",
			children: [
				...COLORS.map((c) => ({ type: "button", label: "  ", color: c, tooltip: c, onClick: () => setColor(pad, c) })),
				{ type: "button", label: "✕", tooltip: "No color", enabled: !!pad.color, onClick: () => setColor(pad, undefined) },
			],
		},
		{ type: "input", value: pad.color ?? "", hint: "Color: #rrggbb", width: 120, onChange: (v) => /^#[0-9a-f]{6}$/i.test(v) && setColor(pad, v) },
		{ type: "separator" },
		{
			type: "row",
			children: [
				{ type: "button", label: "◀ Move", tooltip: sort === "manual" ? undefined : "Moves it in “My order”", enabled: i > 0, onClick: () => move(pad.id, -1) },
				{ type: "button", label: "Move ▶", tooltip: sort === "manual" ? undefined : "Moves it in “My order”", enabled: i < pads.length - 1, onClick: () => move(pad.id, 1) },
				{ type: "button", label: "🗑 Remove", onClick: () => remove(pad.id) },
			],
		},
	];
};

const board = () => {
	const q = query.trim().toLowerCase();
	const found = q ? pads.filter((p) => p.name.toLowerCase().includes(q)) : pads;
	const order = {
		manual: () => 0,
		name: (a, b) => a.name.localeCompare(b.name),
		date: (a, b) => b.added - a.added,
	}[sort];
	// Sorting is stable, so pinned pads keep their order among themselves.
	const shown = [...found].sort((a, b) => !!b.pinned - !!a.pinned || order(a, b));
	// Pad id -> its voice's position, newest last (a restarted pad goes to the end of `playing`).
	const now = new Map(App.audio.playing().map((x) => [x.id, x]));
	const voices = new Map([...playing].filter(([, voice]) => now.has(voice)).map(([pad, voice]) => [pad, now.get(voice)]));
	const [newest, v] = [...voices].pop() ?? [];
	return [
		toolbar(
			query,
			(t) => (query = t),
			sort,
			(v) => {
				sort = v;
				store.set("sort", v);
			},
			addSounds,
		),
		{ type: "space", size: 4 },
		// The pads scroll; the play bar and the settings below stay in view.
		{ type: "scroll", reserve: settingsOpen ? 170 : 70, children: [padGrid(shown, columns, voices, play, menu, !!q, addSounds)] },
		{ type: "separator" },
		playbar(
			padById(newest)?.name ?? "",
			v,
			voices.size - 1,
			stopAll,
			() => (v.paused ? App.audio.resume(v.id) : App.audio.pause(v.id)),
			(s) => App.audio.seek(v.id, s),
		),
		{
			type: "link",
			text: `${settingsOpen ? "▾" : "▸"} Settings`,
			onClick: () => {
				settingsOpen = !settingsOpen;
				store.set("settingsOpen", settingsOpen);
			},
		},
		settingsOpen && {
			type: "row",
			children: [
				{
					type: "column",
					children: [
						{
							type: "slider",
							label: "Channel hears",
							value: channelVolume,
							min: 0,
							max: 100,
							step: 1,
							suffix: "%",
							enabled: toChannel,
							onChange: (x) => {
								channelVolume = Math.round(x);
								store.set("masterVolume", channelVolume);
								updateVolumes();
							},
						},
						{
							type: "slider",
							label: "I hear",
							value: myVolume,
							min: 0,
							max: 100,
							step: 1,
							suffix: "%",
							enabled: hearIt || !toChannel,
							onChange: (x) => {
								myVolume = Math.round(x);
								store.set("myVolume", myVolume);
								updateVolumes();
							},
						},
						{
							type: "row",
							children: [
								{ type: "input", value: url, hint: "https://…/sound.mp3", width: 200, enabled: !downloading, onChange: (x) => (url = x), onSubmit: playUrl },
								{ type: "button", label: downloading ? "Downloading…" : "▶ Play URL", enabled: !downloading && !!url.trim(), onClick: playUrl },
							],
						},
					],
				},
				{
					type: "column",
					children: [
						{
							type: "checkbox",
							label: "Send to channel",
							checked: toChannel,
							onChange: (x) => {
								toChannel = x;
								store.set("toChannel", x);
							},
						},
						{
							type: "checkbox",
							label: "Hear it myself",
							checked: hearIt,
							enabled: toChannel,
							onChange: (x) => {
								hearIt = x;
								store.set("hearIt", x);
							},
						},
						{
							type: "slider",
							label: "Columns",
							value: columns,
							min: 1,
							max: 10,
							step: 1,
							onChange: (x) => {
								columns = Math.round(x);
								store.set("columns", columns);
							},
						},
					],
				},
			],
		},
	];
};

App.ui.registerWindow({ id: "window", title: "Soundboard", width: 780, height: 520, render: board });

// The top bar button opens the soundboard's window and shows whether it is open.
const menuButton = () => App.ui.registerMenu({ id: "board", label: "Soundboard", icon: "🔊", active: App.ui.isOpen("window"), onClick: () => App.ui.toggle("window") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", menuButton);
menuButton();

App.ui.registerSettings(() => [
	{ type: "label", text: "WAV, MP3, OGG, FLAC and M4A files, shown by the title in their tags or else their file name. Right click a pad to play it only for yourself, set its hotkey, volume, color or name, pin, move or remove it.", color: "dim" },
	{
		type: "checkbox",
		label: "Starting a sound stops the others",
		checked: solo,
		onChange: (v) => {
			solo = v;
			store.set("solo", v);
		},
	},
]);

save();
bindHotkeys();
