// Above the pads: the search, the order, adding sounds and the settings toggle.
export const toolbar = (query, search, sort, setSort, addSounds, settingsOpen, toggleSettings) => ({
	type: "row",
	children: [
		{ type: "input", value: query, hint: "🔍 Search sounds", width: 220, padding: 6, onChange: search },
		{
			type: "select",
			value: sort,
			options: [
				{ value: "manual", label: "My order" },
				{ value: "name", label: "Sort by name" },
				{ value: "date", label: "Sort by date" },
			],
			onChange: setSort,
		},
		{ type: "button", label: "➕ Add sounds…", onClick: addSounds },
		{ type: "button", variant: "icon", label: "⚙", tooltip: settingsOpen ? "Hide settings" : "Settings", selected: settingsOpen, onClick: toggleSettings },
	],
});

// One button per sound with its hotkey under the name, filling the window's width: click plays it
// (again: stops it), right click opens its menu (`menu(pad, keys)`). A playing pad fills with its progress.
export const padGrid = (pads, columns, voices, play, menu, searching, addSounds) =>
	pads.length === 0 ?
		searching ? { type: "label", text: "No sound matches.", color: "dim" }
		:	{
				type: "column",
				children: [
					{ type: "label", text: "No sounds yet. Add WAV, MP3, OGG, FLAC or M4A files, or play one from a web address (⚙ Settings).", color: "dim" },
					{ type: "space", size: 6 },
					{ type: "button", label: "➕ Add sounds…", variant: "filled", onClick: addSounds },
				],
			}
	:	{
			type: "grid",
			columns,
			fill: true,
			minWidth: 120,
			children: pads.map((pad) => {
				const keys = App.hotkeys.describe(`pad-${pad.id}`);
				const v = voices.get(pad.id);
				return {
					type: "button",
					label: `${pad.pinned ? "📌 " : ""}${pad.loop ? "🔁 " : ""}${pad.name}${keys === "Not set" ? "" : `\n${keys}`}`,
					color: pad.color,
					selected: !!v,
					progress: v && v.duration > 0 ? v.position / v.duration : undefined,
					tooltip: `${pad.name} · right click: play locally, hotkey, volume, color, pin, rename, move, remove`,
					width: "fill",
					height: 48,
					onClick: () => play(pad.id),
					contextMenu: menu(pad, keys),
				};
			}),
		};

// Always shown under the pads: the newest sound's name, then stop all, pause or resume it and seek in it
// with a bar to the window's edge.
export const playbar = (name, v, others, stopAll, pause, seek) => ({
	type: "column",
	children: [
		{ type: "label", text: v ? (others ? `${name} +${others}` : name) : "Nothing playing", color: v ? undefined : "dim" },
		{
			type: "row",
			children: [
				{ type: "button", label: "⏹", tooltip: "Stop all", enabled: !!v, onClick: stopAll },
				{ type: "button", label: v && !v.paused ? "⏸" : "▶", tooltip: v && !v.paused ? "Pause" : "Resume", enabled: !!v, onClick: pause },
				v ? { type: "slider", value: v.position, min: 0, max: Math.max(v.duration, 0.1), step: 0.1, suffix: " s", live: false, width: "fill", onChange: seek } : { type: "slider", value: 0, min: 0, max: 1, suffix: " s", width: "fill", enabled: false },
			],
		},
	],
});
