// The bundled wallpaper can be replaced with pictures imported from the plugin settings.
const name = "GTA VI";
const colors = {
	bg: "#171126",
	surface: "#241a32",
	surfaceHigh: "#322239",
	surfaceHighest: "#442d44",
	outline: "#765069",
	text: "#fff0e6",
	textDim: "#dcc5c8",
	textFaint: "#ae91a5",
	accent: "#ff8b90",
	link: "#7be1d6",
	talking: "#80ead4",
	idle: "#927889",
	select: "#75405d",
	selectEdge: "#ffad89",
	hover: "#47314b",
	title: "#ffc69f",
	rule: "#88516e",
	layout: { radius: 16, widgetRadius: 10, borders: false, glass: 0.1, glassBlur: 16 },
};

const store = App.storage;
const bundled = "wallpaper.jpg";
const pluginId = App.plugin.id;
// Only the picker can add user: paths. Keep old choices after plugin updates.
let backgrounds = store.get("backgrounds", []);
if (!Array.isArray(backgrounds)) backgrounds = [];
backgrounds = backgrounds.filter((file) => typeof file === "string" && /^user:[a-zA-Z0-9_-][a-zA-Z0-9._-]*\.(png|jpe?g|webp)$/.test(file));
let selected = store.get("selected", bundled);
if (selected !== bundled && !backgrounds.includes(selected)) selected = bundled;
let slideshow = store.get("slideshow", false) === true;
let seconds = store.get("seconds", 60);
if (!Number.isFinite(seconds) || seconds < 10 || seconds > 600) seconds = 60;
let next = Date.now() + seconds * 1000;

const choices = () => [bundled, ...backgrounds];
const active = () => {
	const current = App.theme.current();
	const file = (current.background || "").replaceAll("\\", "/");
	return current.bg.toLowerCase() === colors.bg && current.accent.toLowerCase() === colors.accent && (file.endsWith(`/gta-vi/${bundled}`) || file.includes(`/${pluginId}/`));
};
const register = (apply = false) => {
	App.theme.register(name, { ...colors, images: { "app.background": selected } });
	// Registering updates the Appearance choice; applying refreshes the wallpaper immediately.
	if (apply && active()) App.theme.apply(name);
};
const choose = (file) => {
	selected = file;
	store.set("selected", selected);
	next = Date.now() + seconds * 1000;
	register(true);
};

register();
App.ui.registerSettings(() => [
	{ type: "heading", text: "GTA VI backgrounds" },
	{ type: "label", text: "Choose a picture or rotate through several. Backgrounds are private to this device.", small: true, color: "dim" },
	...choices().map((file) => ({
		type: "button",
		variant: "pill",
		selected: selected === file,
		label: file === bundled ? "Bundled wallpaper" : file.slice(5),
		onClick: () => choose(file),
	})),
	{
		type: "button",
		label: "Add backgrounds…",
		onClick: () => {
			try {
				const added = App.theme.importBackground({ multiple: true });
				if (!added.length) return;
				backgrounds.push(...added);
				store.set("backgrounds", backgrounds);
				choose(added[0]);
			} catch (e) {
				App.ui.notify(String(e), "error");
			}
		},
	},
	{
		type: "checkbox",
		label: "Rotate backgrounds",
		checked: slideshow,
		enabled: choices().length > 1,
		onChange: (value) => {
			slideshow = value;
			store.set("slideshow", value);
			next = Date.now() + seconds * 1000;
		},
	},
	slideshow && {
		type: "slider",
		label: "Change every",
		value: seconds,
		min: 10,
		max: 600,
		step: 10,
		suffix: " sec",
		onChange: (value) => {
			seconds = value;
			store.set("seconds", value);
			next = Date.now() + seconds * 1000;
		},
	},
	selected !== bundled && {
		type: "button",
		label: "Remove selected background",
		onClick: () => {
			backgrounds = backgrounds.filter((file) => file !== selected);
			store.set("backgrounds", backgrounds);
			choose(bundled);
		},
	},
]);

setInterval(() => {
	if (!slideshow || !active() || Date.now() < next || choices().length < 2) return;
	const files = choices();
	choose(files[(files.indexOf(selected) + 1) % files.length]);
}, 1000);
