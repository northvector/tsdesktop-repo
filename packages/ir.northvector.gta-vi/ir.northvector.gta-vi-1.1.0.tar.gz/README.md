# GTA VI Inspired

A sunset-purple, coral and turquoise theme for TeamSpeak Desktop, with translucent
panels and a blurred wallpaper behind them. The theme includes a default wallpaper.

## Choose backgrounds

1. Enable the plugin under **Settings > Plugins** and approve `ui.themes`, `ui.panels`
   and `storage`.
2. Select **GTA VI** under **Settings > Appearance**.
3. Open the plugin's details under **Settings > Plugins**. Under **GTA VI backgrounds**,
   click **Add backgrounds…** to import one or several PNG, JPEG or WebP pictures.
4. Click any background to select it. Enable **Rotate backgrounds** to cycle through
   the bundled picture and every imported picture; choose the interval with the slider.

Imported pictures are copied to this plugin's private data folder, persist across
restarts and plugin updates, and are not included when sharing the plugin. Removing
a picture from the list does not delete its saved file. Rotation runs only while this
theme is in use. `layout.glassBlur` in `index.js` controls panel blur (0–32 pixels).

To develop from this folder, choose **Add development folder…** and select its
`manifest.json`. To install a copy instead, zip the folder and choose **Install…**.

Grand Theft Auto VI is a trademark of Rockstar Games. This is an unofficial fan
theme, not affiliated with Rockstar Games.
