// @ts-check
/// <reference path="../../app.d.ts" />
// Highlights: chat messages naming you or a watched word, and pokes, kept in one list with a notification;
// plus how long each person talked since the app started. Only the watched words are saved.

const MAX = 200;
/** @type {{ time: number; kind: "mention" | "poke"; from: string; text: string }[]} */
const hits = [];
let draft = App.storage.get("words", "");
let notifyOn = App.storage.get("notify", true);

// By `connection:clientId`: name, talk time so far (ms), when the current talk started.
/** @type {Map<string, { name: string; ms: number; since: number | null }>} */
const talk = new Map();

const words = () => String(App.storage.get("words", "")).split(",").map((w) => w.trim().toLowerCase()).filter(Boolean);
const myName = (connection) => {
  const c = App.app.state().connections.find((c) => c.id === connection);
  return c?.clients.find((x) => x.id === c.ownClientId)?.name ?? null;
};
const hhmm = (t) => new Date(t).toTimeString().slice(0, 5);
const dur = (ms) => {
  const s = Math.floor(ms / 1000);
  return s >= 3600 ? `${Math.floor(s / 3600)}h ${Math.floor((s % 3600) / 60)}m` : `${Math.floor(s / 60)}m ${s % 60}s`;
};

const add = (kind, from, text) => {
  hits.unshift({ time: Date.now(), kind, from, text });
  hits.length = Math.min(hits.length, MAX);
  if (notifyOn) App.ui.notify(kind === "poke" ? `${from} poked you: ${text}` : `${from} mentioned you: ${text}`);
};

App.events.on("chat.message", (m) => {
  if (m.own || m.target === "private") return; // private messages are already for you
  const text = m.text.toLowerCase();
  const me = myName(m.connection)?.toLowerCase();
  if ((me && text.includes(me)) || words().some((w) => text.includes(w))) add("mention", m.fromName, m.text);
});
App.events.on("poke", (p) => add("poke", p.fromName, p.text));

App.events.on("talk", (t) => {
  const k = `${t.connection}:${t.clientId}`;
  const e = talk.get(k) ?? { name: t.name, ms: 0, since: null };
  e.name = t.name || e.name;
  if (t.talking && e.since === null) e.since = Date.now();
  if (!t.talking && e.since !== null) {
    e.ms += Date.now() - e.since;
    e.since = null;
  }
  talk.set(k, e);
});
// Someone talking when the server goes away stops counting.
App.events.on("connection.status", (s) => {
  if (s.status === "Connected") return;
  for (const [k, e] of talk) if (k.startsWith(`${s.connection}:`) && e.since !== null) (e.ms += Date.now() - e.since), (e.since = null);
});

const talkers = () => {
  const now = Date.now();
  const rows = [...talk.values()].map((e) => ({ ...e, total: e.ms + (e.since === null ? 0 : now - e.since) })).sort((a, b) => b.total - a.total);
  if (!rows.length) return { type: "label", text: "Nobody has talked yet.", color: "faint" };
  return rows.map((r) => ({ type: "item", text: r.name, detail: dur(r.total), icon: r.since === null ? "🔈" : "🔊", strong: r.since !== null }));
};

const list = () =>
  hits.length
    ? hits.map((h) => ({
        type: "column",
        children: [
          { type: "label", text: `${hhmm(h.time)}  ${h.kind === "poke" ? "👉 poke from" : "💬"} ${h.from}`, small: true, color: h.kind === "poke" ? "orange" : "accent" },
          { type: "markdown", text: h.text },
        ],
      }))
    : [{ type: "label", text: "Nothing yet. Messages naming you or a watched word show up here.", color: "faint" }];

App.ui.registerPanel({
  id: "main",
  title: "Highlights",
  width: 460,
  height: 520,
  render: () => {
    return [
      { type: "collapsing", title: "Talk time", children: [talkers(), talk.size ? { type: "button", label: "Reset", onClick: () => talk.clear() } : null] },
      { type: "row", children: [{ type: "heading", text: "Mentions & pokes" }, hits.length ? { type: "button", label: "Clear", onClick: () => (hits.length = 0) } : null] },
      { type: "scroll", spacing: 8, children: list() },
    ];
  },
});

const save = () => App.storage.set("words", draft);
App.ui.registerSettings(() => [
  { type: "label", text: "Also alert on these words (comma separated). Your own nickname always counts." },
  { type: "row", children: [{ type: "input", value: draft, hint: "raid, help, dinner", width: 300, onChange: (v) => (draft = v), onSubmit: save }, { type: "button", label: "Save", onClick: save }] },
  { type: "checkbox", label: "Show a notification", checked: notifyOn, onChange: (v) => App.storage.set("notify", (notifyOn = v)) },
]);

App.ui.registerMenu({ id: "main", label: "Highlights", icon: "🔔", onClick: () => App.ui.toggle("main") });
