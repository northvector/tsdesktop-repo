// @ts-check
/// <reference path="../../app.d.ts" />
// Discord inside TeamSpeak Desktop, without the Discord app (App.discord), laid out as Discord is: a strip of
// server icons, the chosen server's channels and then the chat docked at the left (beside the bookmarks), and the
// members at the right. Voice channels have a chat too (a click on the one you are in, or its right click menu).
// Voice channels show who is in them and join on a click; the status bar then switches the mic between TeamSpeak
// and Discord. Cameras and Go Live streams show in the call window; DMs can be called and calls answered. Unread
// channels stand out and mentions are counted; a click on anyone shows their profile, a right click on anyone,
// any channel or server offers what Discord does there; Discord links (channels, messages, people, invites) open
// here rather than in the browser. Threads and forum posts, pins, search, spoilers, GIFs, bot DMs, slash commands
// and sending files work as in Discord. Where Discord is blocked or slow, its traffic (only Discord's) can go
// through a proxy. You log in with a QR code, a password (2FA and captcha included) or a token from the website; the app keeps the login encrypted
// on this PC and talks to nobody but Discord (and the proxy you set).

const store = App.storage;
const DMS = "@dms";
const TEXT = new Set([0, 1, 3, 5]);
const VOICE = new Set([2, 13]);
const FORUM = new Set([15, 16]);
const QUICK = ["👍", "❤️", "😂", "😮", "😢", "🎉"];
const STATUS = { online: ["Online", "green"], idle: ["Idle", "yellow"], dnd: ["Do Not Disturb", "red"], invisible: ["Invisible", "faint"], offline: ["Offline", "faint"] };
const dot = (status) => (status && STATUS[status] ? STATUS[status][1] : undefined);

let picked = store.get("guild", null);
const collapsed = new Set(store.get("collapsed", []));
// The chat panel: channel, its server (null for DMs), name, messages, what is typed, and what the input does
// (`replyTo`, `editing`, `files` to send), a message waiting to be confirmed deleted, and who is typing (user id ->
// name, until). `view` is what the panel shows: the messages, the pins, a search, or the threads (a forum's posts).
let chat = null;
let slash = null;
// The profile and invite shown in their windows.
let profile = null;
let invite = null;
// Spoiler pictures clicked open; DM calls already announced; how far down each server's member list is followed.
const revealed = new Set();
const announced = new Set();
const membersUpto = new Map();
// A question waiting in its window (leaving a server): its text, the button's label and what it does.
let confirm = null;

if (store.get("auto", false)) App.discord.connect();

// Not logged in, the login shows in a dialog over the app and no panel takes room; the server strip only shows
// once connected (the channel list opens it).
const PANELS = ["rail", "channels"];
// Offline with a stored login is not logged out: only a missing or rejected login asks for the QR code.
const loggedOut = (s) => s.status === "login" || (s.status === "idle" && !s.hasLogin);
const show = (open) => {
	if (open && loggedOut(App.discord.state())) {
		App.ui.open("login");
		for (const id of PANELS) App.ui.close(id);
	} else {
		if (open) {
			if (App.discord.state().status === "idle") App.discord.connect();
			App.ui.open("channels");
		} else for (const id of [...PANELS, "chat", "members", "login"]) App.ui.close(id);
	}
	store.set("open", open);
};
// The menu button connects (from offline too) and shows Discord, or hides it again.
App.ui.registerMenu({
	id: "discord",
	label: "Discord",
	icon: "🎧",
	onClick: () => {
		if (App.ui.isOpen("channels") || App.ui.isOpen("login")) return show(false);
		App.discord.connect();
		show(true);
	},
});
App.events.on("window.closed", ({ id }) => {
	// Closing Discord's own window closes the members too; only their own close button turns them off.
	if (id === "members" && App.ui.isOpen("channels")) store.set("members", false);
	if (id === "login" && loggedOut(App.discord.state())) {
		App.discord.cancelLogin();
		store.set("open", false);
	}
});

/** Disconnects from Discord altogether (you show as offline) until the menu button connects again; the login stays. */
function goOffline() {
	store.set("auto", false);
	show(false);
	chat = null;
	sentFocus = undefined;
	App.discord.disconnect();
}

// The server whose channels Discord's state carries in full (the others: only their unread marks).
let sentFocus;
function focusOn(id) {
	if (sentFocus !== id) {
		sentFocus = id;
		App.discord.focus(id === DMS ? null : id);
	}
	return App.discord.state();
}

const label = (text, extra = {}) => ({ type: "label", text, ...extra });
const heading = (text) => label(text, { small: true, strong: true, color: "dim" });
const button = (text, onClick, extra = {}) => ({ type: "button", label: text, onClick, ...extra });
const icon = (glyph, tooltip, onClick, selected = false, extra = {}) => ({ type: "button", variant: "icon", label: glyph, size: 16, tooltip, onClick, selected, ...extra });
const separator = { type: "separator" };
const by = (a, b) => (a.position ?? 0) - (b.position ?? 0);
const fail = (e) => App.ui.notify(e.message, "error");
const initials = (name) =>
	name
		.split(/\s+/)
		.filter(Boolean)
		.slice(0, 3)
		.map((w) => [...w][0])
		.join("") || "?";
const pick = (id) => {
	picked = id;
	store.set("guild", id);
	focusOn(id);
};
/** A server with all its channels, even one the state only summed up (not the one shown). */
const fullGuild = (id) => focusOn(id).guilds.find((x) => x.id === id);
const size = (n) => (n >= 1 << 20 ? `${(n / (1 << 20)).toFixed(1)} MB` : `${Math.ceil(n / 1024)} KB`);
// Unread rows in full text color, as Discord does; the rest stay dim.
const bright = () => App.theme.current().text;
const plural = (n, one) => `${n} ${one}${n === 1 ? "" : "s"}`;
/** Someone's custom status (with its emoji), else what they are doing: the line Discord shows under a name. */
const extraLine = (x) =>
	!x ? ""
	: x.custom ? `${x.customEmoji ? `${x.customEmoji} ` : ""}${x.custom}`
	: x.customEmoji || x.activity || "";
const voiceOf = (s, userId) => (s.voiceStates || []).find((v) => v.userId === userId);
/** A DM call's name, or a voice channel's with its server. */
function callName(s, v) {
	if (!v.guildId) {
		const d = s.dms.find((x) => x.id === v.channelId);
		return d ? d.name : "Call";
	}
	const g = s.guilds.find((x) => x.id === v.guildId);
	const ch = g && g.channels.find((c) => c.id === v.channelId);
	return `${ch ? ch.name : "Voice"}${g ? ` / ${g.name}` : ""}`;
}

// ---- Discord links, opened here ----

const HOST = String.raw`https?://(?:(?:www|canary|ptb)\.)?discord(?:app)?\.com`;
const CHANNEL_LINK = new RegExp(`^${HOST}/channels/(@me|\\d+)/(\\d+)(?:/(\\d+))?`);
const USER_LINK = new RegExp(`^${HOST}/users/(\\d+)`);
const INVITE_LINK = new RegExp(String.raw`^https?://(?:(?:www\.)?discord\.gg|(?:(?:www|canary|ptb)\.)?discord(?:app)?\.com/invite)/([\w-]+)`);

function openLink(url) {
	const c = CHANNEL_LINK.exec(url);
	if (c) return goTo(c[1] === "@me" ? null : c[1], c[2], c[3]);
	const u = USER_LINK.exec(url);
	if (u) return showProfile(u[1], chat && chat.guildId);
	const i = INVITE_LINK.exec(url);
	if (i) return showInvite(i[1]);
	App.ui.openUrl(url);
}

/** A channel or thread (and a message in it) from a link: opened as if picked in the list. */
function goTo(guildId, channelId, messageId) {
	const s = App.discord.state();
	if (s.status !== "ready") return App.ui.notify("Discord isn't connected yet.", "error");
	const g = guildId && fullGuild(guildId);
	if (guildId && !g) return App.ui.notify("You aren't on that server.", "error");
	// A thread we haven't joined isn't listed: it opens all the same, if we may read it.
	const c = guildId ? g.channels.find((x) => x.id === channelId) || g.threads.find((x) => x.id === channelId) || { id: channelId, name: "thread", type: 11 } : s.dms.find((x) => x.id === channelId);
	if (!c) return App.ui.notify("That conversation isn't in your direct messages.", "error");
	pick(guildId || DMS);
	show(true);
	openChat(c, guildId, messageId);
}

// ---- people: what a right click on anyone offers ----

/** The DM with someone, opened in the chat. */
function messageUser(userId) {
	return App.discord
		.openDm(userId)
		.then((d) => {
			pick(DMS);
			show(true);
			openChat(d, null);
			return d;
		})
		.catch(fail);
}

/** Calls a DM (joining its call rings the others). */
function callDm(d) {
	App.discord.join(null, d.id);
	App.discord.ring(d.id).catch(() => {});
}
const callUser = (userId) => messageUser(userId).then((d) => d && callDm(d));

function watch(userId) {
	App.discord.watchStream(userId);
	App.ui.open("call");
}

function userMenu(userId, name, guildId) {
	if (!userId) return undefined;
	const s = App.discord.state();
	const me = !!s.user && s.user.id === userId;
	const v = voiceOf(s, userId);
	const inCall = !me && !!v && !!s.voice && v.channelId === s.voice.channelId;
	const c = chat;
	return [button("Profile", () => showProfile(userId, guildId)), me ? null : button("Message", () => messageUser(userId)), me ? null : button("Call", () => callUser(userId)), c && c.canSend && !me ? button("Mention", () => (c.draft = `${c.draft}${c.draft && !c.draft.endsWith(" ") ? " " : ""}<@${userId}> `)) : null, v && v.stream && !me ? button("Watch stream", () => watch(userId)) : null, inCall ? [separator, label(`Volume of ${name || "them"}`, { small: true }), { type: "slider", value: Math.round(v.volume * 100), min: 0, max: 200, suffix: "%", onChange: (x) => App.discord.setVolume(userId, x / 100) }] : null, separator, button("Copy name", () => App.ui.copy(name || userId)), button("Copy user ID", () => App.ui.copy(userId))];
}

// ---- the server strip ----

function guildMenu(g) {
	return [
		button("Mark as read", () => App.discord.markAllRead(g.id).catch(fail), { enabled: g.unread || g.mentions > 0 }),
		button(g.muted ? "Unmute server" : "Mute server", () => App.discord.setMuted(g.id, null, !g.muted).catch(fail)),
		button("Search this server", () => {
			pick(g.id);
			show(true);
			openSearch(g);
		}),
		separator,
		button("Copy server ID", () => App.ui.copy(g.id)),
		button("Open in the browser", () => App.ui.openUrl(`https://discord.com/channels/${g.id}`)),
		g.owner ? null : [separator, button("Leave server…", () => ask(`Leave ${g.name}? You'll need an invite to come back.`, "Leave server", () => App.discord.leaveGuild(g.id).then(() => picked === g.id && pick(DMS))))],
	];
}

/** A server's icon in the strip. */
function guildIcon(s, g) {
	return {
		type: "image",
		stream: g.icon || "",
		text: initials(g.name),
		size: 44,
		selected: picked === g.id,
		tooltip: g.name,
		badge:
			g.mentions ? String(g.mentions)
			: s.voice && s.voice.guildId === g.id ? "🔊"
			: g.unread ? "●"
			: "",
		onClick: () => pick(g.id),
		contextMenu: guildMenu(g),
	};
}

// Folders opened in the strip, by folder id.
const openFolders = new Set(store.get("folders", []));

/** The servers in Discord's order: those in no folder first, then each folder (shut: its icons in one tile, open: under it). */
function guildIcons(s) {
	const byId = new Map(s.guilds.map((g) => [g.id, g]));
	const folders = s.folders || [];
	const foldered = new Set(folders.flatMap((f) => f.guildIds));
	const out = s.guilds.filter((g) => !foldered.has(g.id)).map((g) => guildIcon(s, g));
	for (const f of folders) {
		const gs = f.guildIds.map((id) => byId.get(id)).filter(Boolean);
		if (!gs.length) continue;
		if (f.id == null) {
			out.push(...gs.map((g) => guildIcon(s, g)));
			continue;
		}
		const key = String(f.id);
		const open = openFolders.has(key);
		const toggle = () => {
			open ? openFolders.delete(key) : openFolders.add(key);
			store.set("folders", [...openFolders]);
		};
		const mentions = gs.reduce((n, g) => n + g.mentions, 0);
		out.push({
			type: "image",
			stream: "",
			streams: open ? undefined : gs.slice(0, 4).map((g) => g.icon || ""),
			text: "📁",
			color: f.color || undefined,
			size: 44,
			selected: !open && gs.some((g) => g.id === picked),
			tooltip: f.name || gs.map((g) => g.name).join(", "),
			badge:
				open ? ""
				: mentions ? String(mentions)
				: gs.some((g) => g.unread) ? "●"
				: "",
			onClick: toggle,
		});
		if (open) out.push(...gs.map((g) => guildIcon(s, g)), { type: "space", size: 4 });
	}
	return out;
}

function rail() {
	const s = App.discord.state();
	if (s.status !== "ready") return null;
	const dmMentions = s.dms.reduce((n, d) => n + d.mentions, 0);
	const ringing = (s.calls || []).some((c) => c.ringing);
	return [
		{
			type: "image",
			stream: s.user.avatar || "",
			text: "💬",
			size: 44,
			selected: picked === DMS,
			tooltip: "Direct messages",
			badge:
				ringing ? "📞"
				: dmMentions ? String(dmMentions)
				: "",
			onClick: () => pick(DMS),
			contextMenu: [button("Mark all as read", () => App.discord.markAllRead(null).catch(fail), { enabled: s.dms.some((d) => d.unread || d.mentions) })],
		},
		separator,
		...guildIcons(s),
	];
}

// ---- the channel list ----

/** The login dialog's fields; `way`: "qr", "password" or "token". */
const form = { way: "qr", login: "", password: "", code: "", token: "" };

function loginView() {
	const s = App.discord.state();
	// Logged in: the dialog makes way for the panels.
	if (s.status === "ready") {
		App.ui.close("login");
		show(true);
		form.password = form.code = form.token = "";
		return null;
	}
	if (s.status === "connecting") return [{ type: "spinner" }, label("Connecting to Discord…", { color: "dim" }), s.error ? label(s.error, { small: true, color: "faint" }) : null, proxyLine(s)];
	const out = [label("Your servers, voice and chat right here, without the Discord app.")];
	const cancel = button("Cancel", () => App.discord.cancelLogin());
	const start = () => App.discord.connect();
	if (s.captcha) {
		out.push(label("Discord wants a captcha. Solve it in the browser tab that opened; the login goes on by itself.", { small: true }), { type: "row", children: [button("Open it again", () => App.ui.openUrl(s.captcha), { variant: "filled" }), cancel] });
	} else if (s.mfa) {
		const submit = () => form.code.trim() && App.discord.submitCode(form.code);
		out.push(label("Enter the 6-digit code from your authenticator app, or a backup code.", { small: true }), { type: "input", value: form.code, hint: "2FA code", onChange: (v) => (form.code = v), onSubmit: submit }, { type: "row", children: [button("Log in", submit, { variant: "filled" }), cancel] });
	} else if (s.qr) {
		out.push({ type: "video", stream: s.qr, controls: false, width: 220 });
		out.push(label(s.scanned ? `Scanned by ${s.scanned}. Confirm the login on your phone.` : "Open the Discord app on your phone, go to Settings > Scan QR Code, and scan this.", { small: true }));
		out.push(cancel);
	} else if (s.loggingIn) {
		out.push({ type: "spinner" }, label(form.way === "qr" ? "Getting a login code…" : "Logging in…", { small: true, color: "dim" }), cancel);
	} else {
		const way = (id, text) => ({ type: "button", variant: "pill", label: text, selected: form.way === id, onClick: () => (form.way = id) });
		out.push({ type: "row", children: [way("qr", "QR code"), way("password", "Password"), way("token", "From the website")] });
		if (form.way === "qr") {
			out.push(button("Show a QR code", () => (start(), App.discord.login()), { variant: "filled" }), label("Scan it with the Discord phone app. No password is typed here.", { small: true, color: "faint" }));
		} else if (form.way === "password") {
			const submit = () => form.login.trim() && form.password && (start(), App.discord.loginPassword(form.login, form.password), (form.password = ""));
			out.push(
				{ type: "input", value: form.login, hint: "Email or phone number", onChange: (v) => (form.login = v), onSubmit: submit },
				{ type: "input", value: form.password, hint: "Password", password: true, onChange: (v) => (form.password = v), onSubmit: submit },
				button("Log in", submit, { variant: "filled", enabled: !!(form.login.trim() && form.password) }),
				label("If Discord asks for a captcha it opens in your browser; a new location may need you to approve it by email first.", { small: true, color: "faint" }),
			);
		} else {
			const submit = () => form.token.trim() && (start(), App.discord.loginToken(form.token), (form.token = ""));
			out.push(
				label("Log in on the Discord website in your browser (captcha, 2FA and passkeys all work there), then copy your token: press F12, open Network, click any request to discord.com/api and copy its Authorization header.", { small: true }),
				{ type: "link", text: "Open discord.com/login", url: "https://discord.com/login" },
				{ type: "input", value: form.token, hint: "Token", password: true, onChange: (v) => (form.token = v), onSubmit: submit },
				button("Log in", submit, { variant: "filled", enabled: !!form.token.trim() }),
				label("Never give your token to anyone: it is your account.", { small: true, color: "orange" }),
			);
		}
	}
	out.push({ type: "space", size: 6 }, label("Your login is stored encrypted on this PC, and the app only talks to Discord itself.", { small: true, color: "faint" }), label("Discord doesn't officially allow third-party clients, so using one can get an account flagged.", { small: true, color: "orange" }), s.error ? label(s.error, { small: true, color: "red" }) : null, proxyLine(s));
	return out;
}

/** Which way Discord is reached, and the way to change it. */
function proxyLine(s) {
	const p = s.proxy;
	return {
		type: "item",
		icon: "🌐",
		small: true,
		text:
			!p ? "Connection: direct"
			: p.address ? `Through ${p.mode === "system" ? "Windows' proxy" : "a proxy"}: ${p.address}`
			: "Windows has no proxy set: direct",
		tooltip: "Use a proxy for Discord only",
		onClick: openConnection,
	};
}

/** Someone in a voice channel or call: talking, muted, their camera or stream. */
function member(s, m) {
	const marks = `${m.video ? "📷" : ""}${m.mute || m.selfMute ? "🔇" : ""}${m.deaf || m.selfDeaf ? "🎧" : ""}`;
	return {
		type: "item",
		text: m.name,
		image: m.avatar || "-",
		ring: m.speaking ? "green" : undefined,
		indent: 22,
		height: 28,
		detail: marks,
		badge: m.stream ? "LIVE" : undefined,
		tooltip: m.stream ? "Profile · right click to watch their stream" : "Profile",
		onClick: () => showProfile(m.userId, m.guildId),
		contextMenu: userMenu(m.userId, m.name, m.guildId),
	};
}

/** A text channel, thread or DM row: bright and bold while unread, its mentions counted at the right. */
const unreadLook = (c, text) => (c.unread || c.mentions ? { strong: true, color: text, detail: c.mentions ? `@${c.mentions}` : "" } : {});

function threadRows(g, c, text) {
	return g.threads.filter((t) => t.parentId === c.id).map((t) => ({ type: "item", icon: "↳", text: t.name, indent: 14, small: true, selected: !!chat && chat.id === t.id, ...unreadLook(t, text), onClick: () => openChat(t, g.id), contextMenu: [button("Mark as read", () => App.discord.markRead(t.id, null)), button("Copy link", () => App.ui.copy(`https://discord.com/channels/${g.id}/${t.id}`)), button("Leave thread", () => App.discord.joinThread(t.id, false).catch(fail))] }));
}

/** What a right click on a channel offers. */
function channelMenu(g, c) {
	const voice = VOICE.has(c.type);
	const link = `https://discord.com/channels/${g.id}/${c.id}`;
	const s = App.discord.state();
	return [
		voice && s.voice && s.voice.channelId === c.id ? button("Disconnect", () => App.discord.leave())
		: voice ? button("Join", () => App.discord.join(g.id, c.id), { enabled: c.canConnect })
		: null,
		button("Open chat", () => openChat(c, g.id, null, FORUM.has(c.type) ? "threads" : undefined)),
		TEXT.has(c.type) ? button("Threads", () => openChat(c, g.id, null, "threads")) : null,
		voice ? null : button("Mark as read", () => App.discord.markRead(c.id, null), { enabled: c.unread || c.mentions > 0 }),
		button(c.muted ? "Unmute channel" : "Mute channel", () => App.discord.setMuted(g.id, c.id, !c.muted).catch(fail)),
		separator,
		button("Copy link", () => App.ui.copy(link)),
		button("Copy channel ID", () => App.ui.copy(c.id)),
		button("Open in the browser", () => App.ui.openUrl(link)),
	];
}

function channelRow(s, g, c, text) {
	const muted = c.muted ? { color: "faint" } : {};
	const tip = c.topic ? `${c.topic.length > 200 ? `${c.topic.slice(0, 200)}…` : c.topic}` : undefined;
	if (VOICE.has(c.type)) {
		const here = s.voiceStates.filter((m) => m.channelId === c.id);
		const inIt = !!s.voice && s.voice.channelId === c.id;
		return [
			{
				type: "item",
				icon: c.canConnect ? "🔊" : "🔒",
				text: c.name,
				selected: inIt,
				enabled: c.canConnect,
				...muted,
				tooltip:
					inIt ? "You're here; click for its chat"
					: c.canConnect ? "Join"
					: "You can't join this channel",
				onClick: () => (inIt ? openChat(c, g.id) : App.discord.join(g.id, c.id)),
				contextMenu: channelMenu(g, c),
			},
			...here.map((m) => member(s, m)),
		];
	}
	if (FORUM.has(c.type)) return [{ type: "item", icon: "💬", text: c.name, tooltip: tip, ...muted, selected: !!chat && chat.id === c.id, onClick: () => openChat(c, g.id, null, "threads"), contextMenu: channelMenu(g, c) }, ...threadRows(g, c, text)];
	if (TEXT.has(c.type)) return [{ type: "item", icon: "#", text: c.name, tooltip: tip, ...muted, selected: !!chat && chat.id === c.id, ...unreadLook(c, text), onClick: () => openChat(c, g.id), contextMenu: channelMenu(g, c) }, ...threadRows(g, c, text)];
	return null;
}

function dmRow(s, d, text) {
	const inCall = s.voiceStates.some((v) => !v.guildId && v.channelId === d.id);
	const sub = extraLine(d);
	return {
		type: "item",
		text: d.name,
		...(d.userId ? { image: d.avatar || "-", dot: dot(d.status) } : { icon: "👥" }),
		selected: !!chat && chat.id === d.id,
		...(d.muted ? { color: "faint" } : {}),
		...unreadLook(d, text),
		...(inCall && !(d.unread || d.mentions) ? { detail: "🔊" } : {}),
		tooltip: sub || undefined,
		onClick: () => openChat(d, null),
		contextMenu: [
			d.userId ? button("Profile", () => showProfile(d.userId, null)) : null,
			button(inCall ? "Join call" : "Call", () => callDm(d)),
			button("Mark as read", () => App.discord.markRead(d.id, null), { enabled: d.unread || d.mentions > 0 }),
			button(d.muted ? "Unmute conversation" : "Mute conversation", () => App.discord.setMuted(null, d.id, !d.muted).catch(fail)),
			separator,
			d.userId ? button("Copy user ID", () => App.ui.copy(d.userId)) : null,
			button("Copy channel ID", () => App.ui.copy(d.id)),
			button("Close conversation", () =>
				App.discord
					.closeDm(d.id)
					.then(() => {
						if (chat && chat.id === d.id) {
							chat = null;
							App.ui.close("chat");
						}
					})
					.catch(fail),
			),
		],
	};
}

function channelList(s) {
	const text = bright();
	if (picked === DMS) {
		return [{ type: "item", text: "DIRECT MESSAGES", small: true, strong: true }, ...(s.dms.length ? s.dms.map((d) => dmRow(s, d, text)) : [label("No direct messages.", { small: true, color: "faint" })])];
	}
	const g = s.guilds.find((x) => x.id === picked);
	if (!g) return label("Pick a server at the left.", { small: true, color: "faint" });
	const under = (parent) => g.channels.filter((c) => c.type !== 4 && (c.parentId ?? null) === parent).sort((a, b) => (VOICE.has(a.type) ? 1 : 0) - (VOICE.has(b.type) ? 1 : 0) || by(a, b));
	const toggle = (id) => {
		collapsed.has(id) ? collapsed.delete(id) : collapsed.add(id);
		store.set("collapsed", [...collapsed]);
	};
	return [
		{ type: "item", icon: "🔍", text: "Search this server", small: true, onClick: () => openSearch(g) },
		...under(null).map((c) => channelRow(s, g, c, text)),
		...g.channels
			.filter((c) => c.type === 4)
			.sort(by)
			.map((cat) => {
				const list = under(cat.id);
				if (!list.length) return null;
				const shut = collapsed.has(cat.id);
				// A shut category still shows the voice channel you are in and unread channels, as Discord does.
				const rows = shut ? list.filter((c) => (s.voice && s.voice.channelId === c.id) || c.unread || c.mentions) : list;
				const menu = [button(shut ? "Expand" : "Collapse", () => toggle(cat.id)), button("Mark as read", () => list.filter((c) => c.unread || c.mentions).forEach((c) => App.discord.markRead(c.id, null))), button(cat.muted ? "Unmute category" : "Mute category", () => App.discord.setMuted(g.id, cat.id, !cat.muted).catch(fail))];
				return [{ type: "space", size: 6 }, { type: "item", icon: shut ? "›" : "⌄", text: cat.name.toUpperCase(), small: true, strong: true, onClick: () => toggle(cat.id), contextMenu: menu }, ...rows.map((c) => channelRow(s, g, c, text))];
			}),
	];
}

/** DM calls ringing you: who, and a way to answer or decline. Announced once with a notice. */
function incomingCalls(s) {
	const ringing = (s.calls || []).filter((c) => c.ringing && !(s.voice && s.voice.channelId === c.channelId));
	return ringing.map((c) => {
		const d = s.dms.find((x) => x.id === c.channelId);
		const name = d ? d.name : "Someone";
		if (!announced.has(c.channelId)) {
			announced.add(c.channelId);
			App.ui.notify(`Discord · ${name} is calling you`);
		}
		return [{ type: "bar", left: label(`📞 ${name} is calling…`, { strong: true, color: "green" }), right: [button("Join", () => (d ? callDm(d) : App.discord.join(null, c.channelId)), { variant: "filled" }), button("Decline", () => App.discord.decline(c.channelId).catch(fail))] }, separator];
	});
}

/** Devices to send, from App.meet (empty without the media.capture permission). */
function devices(kind) {
	try {
		return kind === "camera" ? App.meet.cameras() : App.meet.monitors().map((m) => ({ index: m.index, name: `${m.name || `Screen ${m.index + 1}`}${m.primary ? " (main)" : ""}` }));
	} catch {
		return [];
	}
}

/** Windows that can be streamed, from App.meet (empty without the media.capture permission). */
function windows() {
	try {
		return App.meet.windows();
	} catch {
		return [];
	}
}

function voicePanel(s) {
	const v = s.voice;
	if (!v) return null;
	const g = v.guildId ? s.guilds.find((x) => x.id === v.guildId) : null;
	const ch = g ? g.channels.find((c) => c.id === v.channelId) : s.dms.find((d) => d.id === v.channelId);
	const status =
		v.status === "connected" ? "Voice Connected"
		: v.status === "error" ? "Voice failed"
		: "Connecting…";
	const camOn = v.video === true;
	const live = s.golive;
	const pickMenu = (kind, chosen, use) => devices(kind).map((d) => button(`${d.index === chosen ? "✓ " : ""}${d.name}`, () => use(d.index)));
	const camera = (i) => {
		store.set("camera", i);
		App.discord.setVideo(i);
	};
	// Go Live: a screen `{ monitor }` or window `{ window }`, at the saved quality and frame rate; a window
	// that closed since falls back to the main screen.
	const goLive = (what) => {
		if (what) store.set("golive", what);
		let pick = store.get("golive", { monitor: store.get("screen", 0) });
		if (pick.window != null && !windows().some((w) => w.id === pick.window)) pick = { monitor: 0 };
		App.discord.goLive(pick, { height: store.get("liveHeight", 720), fps: store.get("liveFps", 30) });
	};
	// Changed while live: the stream starts over with it.
	const liveSetting = (key, value) => {
		store.set(key, value);
		if (live) goLive();
	};
	const liveMenu = () => {
		const pick = store.get("golive", { monitor: store.get("screen", 0) });
		const height = store.get("liveHeight", 720);
		const fps = store.get("liveFps", 30);
		const check = (on, text) => `${on ? "✓ " : ""}${text}`;
		const wins = windows().slice(0, 20);
		return [
			label("SCREENS", { small: true, color: "dim" }),
			...devices("screen").map((d) => button(check(pick.window == null && pick.monitor === d.index, d.name), () => goLive({ monitor: d.index }))),
			wins.length ? [separator, label("WINDOWS", { small: true, color: "dim" })] : null,
			...wins.map((w) => button(check(pick.window === w.id, w.title.length > 40 ? `${w.title.slice(0, 39)}…` : w.title), () => goLive({ window: w.id }), { tooltip: `${w.app || w.title} · ${w.width}×${w.height}` })),
			separator,
			label("QUALITY", { small: true, color: "dim" }),
			{ type: "row", children: [[480, "480p"], [720, "720p"], [1080, "1080p"], [4320, "Source"]].map(([v, t]) => button(check(height === v, t), () => liveSetting("liveHeight", v))) },
			label("FRAME RATE", { small: true, color: "dim" }),
			{ type: "row", children: [15, 30, 60].map((v) => button(check(fps === v, `${v} fps`), () => liveSetting("liveFps", v))) },
			height > 720 || fps > 30 ? label("Above 720p 30 fps needs Discord Nitro", { small: true, color: "faint" }) : null,
		].filter(Boolean);
	};
	const sees = s.voiceStates.some((m) => m.channelId === v.channelId && (m.video || m.stream)) || camOn || !!live || !!s.watching;
	const color =
		v.status === "error" ? "red"
		: v.status === "connected" ? "green"
		: "yellow";
	// One of the wide buttons under the call's name, as in Discord.
	const tile = (glyph, tooltip, onClick, on, extra = {}) => ({ type: "button", label: glyph, width: "fill", height: 32, tooltip, onClick, selected: on, ...extra });
	// The privacy code sits on the signal tile, to keep the panel as small as Discord's.
	const signal = v.privacyCode ? icon("📶", `🔒 End-to-end encrypted · ${v.privacyCode}\nClick to copy the code`, () => App.ui.copy(v.privacyCode)) : icon("📶", status);
	return [
		{
			type: "bar",
			left: [{ ...signal, color, fill: "surface" }, { type: "column", spacing: 0, children: [label(status, { strong: true, color }), label(callName(s, v), { small: true, color: "dim" })] }],
			right: icon("📞", "Disconnect", () => App.discord.leave(), false, { size: 18 }),
		},
		{
			type: "grid",
			columns: 4,
			fill: true,
			children: [tile("📷", camOn ? "Turn off your camera" : "Turn on your camera (right click: which one)", () => (camOn ? App.discord.setVideo(null) : camera(store.get("camera", 0))), camOn, { contextMenu: pickMenu("camera", store.get("camera", 0), camera) }), tile("🖥", live ? "Stop streaming (right click: screen, window, quality)" : "Go Live: stream a screen or window (right click: which one, quality, frame rate)", () => (live ? App.discord.goLive(null) : goLive()), !!live, { contextMenu: liveMenu() }), tile("📺", "Cameras and streams", () => (App.ui.isOpen("call") ? App.ui.close("call") : App.ui.open("call")), App.ui.isOpen("call"), { enabled: sees }), tile("💬", "The call's chat", () => ch && openChat(ch, v.guildId), !!ch && !!chat && chat.id === ch.id, { enabled: !!ch })],
		},
		v.status === "error" ? label(v.error, { small: true, color: "red" }) : null,
		v.video && v.video !== true && v.video.error ? label(`Camera: ${v.video.error}`, { small: true, color: "red" }) : null,
		live ?
			label(
				live.status === "error" ? `Go Live failed: ${live.error}`
				: live.status === "connected" ? `🔴 Live · ${plural(live.viewers || 0, "viewer")}`
				: "Going live…",
				{ small: true, color: "red" },
			)
		:	null,
	];
}

/** Your name, status and the call's mute and deafen at the bottom, as in Discord; ⚙ for your status and account. */
function userBar(s) {
	const status = s.user.status || "online";
	const mine = extraLine(s.user);
	const v = s.voice;
	const sub =
		v ?
			label("🔊 In voice", { small: true, color: "green" })
		:	label(
				mine ?
					mine.length > 22 ?
						`${mine.slice(0, 22)}…`
					:	mine
				: STATUS[status] ? STATUS[status][0]
				: "",
				{ small: true, color: "dim" },
			);
	return {
		type: "bar",
		left: [
			{ type: "image", stream: s.user.avatar || "", text: initials(s.user.name || s.user.username || "?"), size: 32, morph: false, dot: dot(status), ring: voiceOf(s, s.user.id)?.speaking ? "green" : undefined, tooltip: "Your profile", onClick: () => showProfile(s.user.id, null), contextMenu: accountMenu(s) },
			{ type: "column", children: [label(s.user.name || s.user.username, { strong: true }), sub] },
		],
		right: [v ? icon(v.selfMute ? "🔇" : "🎤", v.selfMute ? "Unmute" : "Mute", () => App.discord.setMute(!v.selfMute), !!v.selfMute) : null, v ? icon(v.selfDeaf ? "🔕" : "🎧", v.selfDeaf ? "Undeafen" : "Deafen", () => App.discord.setDeaf(!v.selfDeaf), !!v.selfDeaf) : null, icon("⚙", "Status and account", () => App.ui.open("account"), App.ui.isOpen("account"), { contextMenu: accountMenu(s) })],
	};
}

/** Your status, custom status, connection, going offline and logging out. */
function accountMenu(s) {
	const status = s.user.status || "online";
	const mine = extraLine(s.user);
	return [
		...Object.entries(STATUS)
			.filter(([k]) => k !== "offline")
			.map(([k, [name]]) => button(`${k === status ? "✓ " : ""}${name}`, () => App.discord.setStatus(k))),
		separator,
		button(mine ? "Edit custom status…" : "Set a custom status…", openCustom),
		mine ? button("Clear custom status", () => App.discord.setCustomStatus(null, null)) : null,
		separator,
		button("Copy user ID", () => App.ui.copy(s.user.id)),
		button("Connection and proxy…", openConnection),
		button("Disconnect (go offline)", goOffline, { tooltip: "Leaves Discord until you open it again from the menu; you stay logged in" }),
		button("Log out of Discord", () => {
			store.set("auto", false);
			show(false);
			App.discord.logout();
		}),
	];
}

function channels() {
	let s = App.discord.state();
	if (loggedOut(s)) {
		// Logged out (or the login expired): the login dialog instead of the panels.
		sentFocus = undefined;
		show(true);
		return null;
	}
	if (s.status !== "ready") {
		App.ui.close("rail");
		sentFocus = undefined;
		return [{ type: "spinner" }, label("Connecting to Discord…", { color: "dim" }), s.error ? label(s.error, { small: true, color: "faint" }) : null, proxyLine(s), button("Go offline", goOffline)];
	}
	if (!store.get("auto", false)) store.set("auto", true);
	// A render queued before the menu button hid Discord must not bring the server strip back.
	if (App.ui.isOpen("channels") && !App.ui.isOpen("rail")) App.ui.open("rail");
	if (sentFocus !== picked) s = focusOn(picked);
	const g = s.guilds.find((x) => x.id === picked);
	const title =
		picked === DMS ? "Direct Messages"
		: g ? g.name
		: "Discord";
	const calls = incomingCalls(s);
	return [
		{ type: "item", text: title, strong: true, height: 34, contextMenu: g ? guildMenu(g) : undefined },
		separator,
		calls,
		// The list scrolls; the call and your name stay in a card at the bottom, as in Discord.
		{
			type: "pinned",
			top: { type: "scroll", reserve: "pinned", children: channelList(s) },
			bottom: [{ type: "group", padding: 8, children: [voicePanel(s), userBar(s)] }, { type: "space", size: 6 }],
		},
	];
}

App.ui.registerPanel({ id: "rail", title: "Discord servers", dock: "left", width: 72, header: false, resizable: false, render: rail });
App.ui.registerPanel({ id: "channels", title: "Discord", dock: "left", width: 350, minWidth: 350, header: false, render: channels });

// ---- chat ----

/** Opens a channel's chat; with `around`, at that message (a link to it); `view` "threads" for a forum's posts. */
function openChat(c, guildId, around, view) {
	slash = null;
	const forum = FORUM.has(c.type);
	chat = { id: c.id, guildId, name: c.name, type: c.type, userId: c.userId || null, canSend: c.canSend !== false, messages: [], draft: "", loading: !forum, error: null, more: false, jumped: !!around, replyTo: null, editing: null, deleting: null, files: [], typing: new Map(), typed: 0, view: view || (forum ? "threads" : "messages"), list: null, query: "", newThread: null };
	const mine = chat;
	App.ui.open("chat");
	if (guildId && store.get("members", true)) App.ui.open("members");
	if (chat.view === "threads") loadThreads(mine, false);
	if (forum) return;
	App.discord
		.messages(c.id, guildId, around ? { around } : null)
		.then((m) => {
			mine.messages = m;
			mine.more = m.length >= 50;
			markRead(mine);
		})
		.catch((e) => {
			mine.error = e.message;
		})
		.finally(() => {
			mine.loading = false;
		});
}

function loadOlder() {
	const mine = chat;
	if (!mine || mine.loading || !mine.messages.length) return;
	mine.loading = true;
	App.discord
		.messages(mine.id, mine.guildId, { before: mine.messages[0].id })
		.then((m) => {
			mine.messages = [...m, ...mine.messages];
			mine.more = m.length >= 50;
		})
		.catch((e) => {
			mine.error = e.message;
		})
		.finally(() => {
			mine.loading = false;
		});
}

/** Fills `chat.list` for the pins, a search or the threads view. */
function loadList(c, view, ask) {
	c.view = view;
	c.list = { loading: true, items: [], error: null, archived: false };
	const list = c.list;
	ask()
		.then((r) => Object.assign(list, r))
		.catch((e) => {
			list.error = e.message;
		})
		.finally(() => {
			list.loading = false;
		});
	return list;
}
const loadPins = (c) => loadList(c, "pins", () => App.discord.pins(c.id).then((m) => ({ items: m.reverse() })));
const loadThreads = (c, archived) => (loadList(c, "threads", () => App.discord.threads(c.id, archived).then((r) => ({ items: r.threads }))).archived = archived);
function runSearch(c) {
	const text = c.query.trim();
	if (!text) return;
	loadList(c, "search", () => App.discord.search(text, c.guildId ? { guildId: c.guildId } : { channelId: c.id }).then((r) => ({ items: r.messages, total: r.total })));
}
function openSearch(g) {
	g = fullGuild(g.id) || g;
	const c = g.channels.find((x) => TEXT.has(x.type));
	if (!c) return;
	if (!chat || chat.guildId !== g.id) openChat(c, g.id);
	chat.view = "search";
	chat.list = null;
}

// Read up to the newest message shown; at most every couple of seconds while messages pour in.
let readTimer = 0;
function markRead(c) {
	clearTimeout(readTimer);
	readTimer = setTimeout(() => {
		const last = c.messages[c.messages.length - 1];
		// Not while looking at older messages: that would mark the channel less read than it was.
		if (last && chat === c && !c.jumped && App.ui.isOpen("chat")) App.discord.markRead(c.id, last.id);
	}, 1500);
}

App.events.on("discord.message", (e) => {
	if (e.kind === "create") notifyMention(e);
	if (!chat || e.channelId !== chat.id) return;
	const i = chat.messages.findIndex((m) => m.id === e.id);
	if (e.kind === "delete") {
		if (i >= 0) chat.messages.splice(i, 1);
		return;
	}
	// An update carries only what changed (an edit, or the preview of a link); the rest is null.
	if (e.kind === "update") {
		if (i >= 0) chat.messages[i] = { ...chat.messages[i], ...Object.fromEntries(Object.entries(e.message).filter(([, v]) => v != null)) };
		return;
	}
	// Looking at older messages (a link to one): new ones come when going back to the present.
	if (i < 0 && !chat.jumped) chat.messages.push(e.message);
	chat.typing.delete(e.message.authorId);
	markRead(chat);
});

App.events.on("discord.reaction", (e) => {
	const m = chat && e.channelId === chat.id && chat.messages.find((x) => x.id === e.messageId);
	if (!m) return;
	const list = (m.reactions = m.reactions || []);
	let r = list.find((x) => (x.emojiId || x.emoji) === (e.emojiId || e.emoji));
	if (e.kind === "add") {
		if (!r) list.push((r = { emoji: e.emoji, emojiId: e.emojiId, image: e.image, count: 0, me: false }));
		r.count++;
		if (e.me) r.me = true;
	} else if (r) {
		r.count--;
		if (e.me) r.me = false;
		if (r.count <= 0) list.splice(list.indexOf(r), 1);
	}
});

App.events.on("discord.typing", (e) => {
	if (chat && e.channelId === chat.id) chat.typing.set(e.userId, { name: e.name || "Someone", until: Date.now() + 10e3 });
});

// A toast for a DM or a mention while that chat isn't open (Settings > Plugins can turn it off); spoilers stay hidden.
function notifyMention(e) {
	const m = e.message;
	const s = App.discord.state();
	if (!store.get("notify", true) || !s.user || m.authorId === s.user.id || s.user.status === "dnd") return;
	if (!(m.mentioned || e.guildId == null) || (chat && chat.id === e.channelId && App.ui.isOpen("chat"))) return;
	const text = (m.content || (m.images && m.images.length ? "a picture" : "")).replace(/\|\|[\s\S]*?\|\|/g, "▒▒▒").replace(/\s+/g, " ");
	App.ui.notify(`Discord · ${m.author || "Someone"}: ${text.length > 90 ? `${text.slice(0, 90)}…` : text}`);
}
App.ui.registerSettings(() => [{ type: "checkbox", label: "Show a notice for direct messages, mentions and calls (not while Do Not Disturb)", checked: store.get("notify", true), onChange: (v) => store.set("notify", v) }, button("Connection and proxy…", openConnection), App.discord.state().status === "idle" ? button("Connect to Discord", () => (App.discord.connect(), show(true))) : button("Disconnect (go offline)", goOffline, { tooltip: "You show as offline until you open Discord again from the menu; you stay logged in" })]);

function send() {
	if (!chat) return;
	const text = chat.draft.trim();
	const mine = chat;
	const { editing, replyTo, files } = mine;
	if (!text && !files.length) return;
	if (slash && slash.channelId === mine.id && !slash.command) {
		if (slash.commands.length) selectSlashCommand(slash.commands[slash.selected] || slash.commands[0]);
		else mine.error = "No matching commands were found.";
		return;
	}
	mine.draft = "";
	mine.editing = mine.replyTo = null;
	mine.files = [];
	const done = editing ? App.discord.edit(mine.id, editing.id, text) : App.discord.send(mine.id, text, replyTo && replyTo.id, files);
	done.catch((e) => {
		mine.error = `Not sent: ${e.message}`;
		mine.draft = text;
		mine.editing = editing;
		mine.replyTo = replyTo;
	});
}

function loadSlashCommands(query) {
	if (!slash || slash.command) return;
	slash.query = query;
	slash.loading = true;
	slash.error = null;
	const mine = slash;
	const request = ++mine.request;
	App.discord.commands(mine.channelId, mine.guildId, query)
		.then((commands) => {
			if (slash !== mine || mine.request !== request) return;
			mine.commands = commands;
			mine.selected = 0;
			mine.reveal = true;
			mine.loading = false;
		})
		.catch((e) => {
			if (slash !== mine || mine.request !== request) return;
			mine.error = e.message;
			mine.loading = false;
		});
}

function findSlash(query) {
	if (!chat || !chat.canSend || chat.view !== "messages" || chat.editing) {
		slash = null;
		return;
	}
	if (!slash || slash.channelId !== chat.id || slash.command) {
		// Loading from the start, or "No matching commands" flashes before the first answer.
		slash = { channelId: chat.id, guildId: chat.guildId, query, commands: [], selected: 0, reveal: false, command: null, error: null, loading: true, request: 0, timer: null };
	}
	clearTimeout(slash.timer);
	const mine = slash;
	// The index is kept after its first fetch, so searching it can follow the typing closely.
	slash.timer = setTimeout(() => {
		if (slash === mine) loadSlashCommands(query);
	}, 50);
}

// Up and down choose in the list, Esc closes it (what was typed stays).
function slashKey(key) {
	if (!slash || slash.command) return;
	if (key === "escape") {
		slash = null;
		return;
	}
	const count = slash.commands.length;
	if (!count) return;
	slash.selected = (slash.selected + (key === "up" ? count - 1 : 1)) % count;
	slash.reveal = true;
}

function openSlashCommands() {
	if (!chat || !chat.canSend || chat.view !== "messages" || chat.editing) return;
	chat.draft = "/";
	chat.error = null;
	findSlash("");
}

// A row's subcommand (`/playlist add`), or the command itself.
const commandLeaf = (row) => (row.path || []).reduce((node, name) => (node.options || []).find((o) => o.name === name) || {}, row);
const commandTitle = (row) => ["/" + row.name, ...(row.path || [])].join(" ");

function selectSlashCommand(row) {
	if (!chat || !slash) return;
	// The rest of the row is the definition Discord gets back when the command is run.
	const { path, image, ...command } = row;
	slash.command = command;
	slash.title = commandTitle(row);
	slash.image = image;
	slash.path = path || [];
	slash.values = {};
	slash.focus = true;
	slash.timer && clearTimeout(slash.timer);
	chat.draft = "";
	chat.error = null;
}

function slashFields() {
	let options = slash.command.options || [];
	const wrappers = [];
	while (options.some((o) => o.type === 1 || o.type === 2)) {
		const choices = options.filter((o) => o.type === 1 || o.type === 2);
		const item = choices.find((o) => o.name === slash.path[wrappers.length]) || choices[0];
		wrappers.push(item);
		options = item.options || [];
	}
	return { fields: options, wrappers };
}

function submitSlash() {
	if (!slash || !slash.command || slash.loading) return;
	const { fields, wrappers } = slashFields();
	const values = [];
	for (const field of fields) {
		let value = slash.values[field.name];
		if (field.type === 5 && value === undefined) value = false;
		if (value === undefined || value === "") {
			if (field.required) {
				slash.error = `${field.name} is required.`;
				return;
			}
			continue;
		}
		if (field.type === 4 || field.type === 10) {
			value = Number(value);
			if (!Number.isFinite(value) || (field.type === 4 && !Number.isInteger(value)) || (field.min_value != null && value < field.min_value) || (field.max_value != null && value > field.max_value)) {
				slash.error = `${field.name} must be a valid ${field.type === 4 ? "integer" : "number"}.`;
				return;
			}
		}
		values.push({ name: field.name, type: field.type, value });
	}
	let options = values;
	for (let i = wrappers.length - 1; i >= 0; i--) options = [{ name: wrappers[i].name, type: wrappers[i].type, options }];
	slash.loading = true;
	slash.error = null;
	const mine = slash;
	App.discord.interact(mine.channelId, mine.guildId, mine.command, options)
		.then(() => {
			if (slash === mine) slash = null;
		})
		.catch((e) => {
			if (slash === mine) {
				mine.loading = false;
				mine.error = `Command failed: ${e.message}`;
			}
		});
}

const COMMAND_ROW = 48;
// How much of the chat the picker takes: its rows up to a limit, so a short list leaves the messages in view.
const slashHeight = () => Math.min(360, 28 + Math.max(slash.commands.length, 1) * (COMMAND_ROW + 2));

/** A command's values in a card in place of the message box, as Discord fills them in: each option's name, what it wants, its field. */
function slashForm() {
	const { fields } = slashFields();
	const close = () => {
		slash = null;
	};
	let focus = slash.focus;
	slash.focus = false;
	const controls = fields.map((field) => {
		const choices = Array.isArray(field.choices) ? field.choices : [];
		const set = (v) => (slash.values[field.name] = v);
		let control;
		if (field.type === 5) control = { type: "checkbox", label: "Yes", checked: slash.values[field.name] === true, onChange: set };
		// Blank until chosen: an option left alone isn't sent, so showing the first choice would be untrue.
		else if (choices.length) control = { type: "select", value: slash.values[field.name] ?? null, options: choices.map((choice) => ({ value: choice.value, label: choice.name })), onChange: set };
		else {
			control = { type: "input", value: slash.values[field.name] == null ? "" : String(slash.values[field.name]), hint: field.required ? "Required" : "Optional", padding: 6, focus, onChange: set, onSubmit: submitSlash, onKey: (key) => key === "escape" && close() };
			focus = false;
		}
		return [{ type: "row", children: [label(`${field.name}${field.required ? " *" : ""}`, { small: true, strong: true }), label(field.description || "", { small: true, color: "dim" })] }, { type: "bar", left: [{ type: "button", variant: "pill", label: field.name, selected: true }, control] }];
	});
	return {
		type: "group",
		padding: 10,
		children: [
			{
				type: "bar",
				left: [{ type: "image", stream: slash.image || "", text: "/", size: 24, morph: false }, label(slash.title, { strong: true }), label(slash.command.application?.name || "", { small: true, color: "dim" })],
				right: icon("✕", "Cancel (Esc)", close),
			},
			controls,
			slash.error ? label(slash.error, { small: true, color: "red" }) : null,
			{ type: "bar", left: label("Enter to run · Esc to cancel", { small: true, color: "faint" }), right: button(slash.loading ? "Sending…" : "Run", submitSlash, { variant: "filled", enabled: !slash.loading }) },
		],
	};
}

function slashView(c) {
	if (!slash || slash.channelId !== c.id) return null;
	if (slash.command) return slashForm();
	const reveal = slash.reveal;
	slash.reveal = false;
	return [
		{ type: "separator" },
		{
			type: "scroll",
			reserve: 70,
			spacing: 2,
			children: [
				label(slash.query ? `Commands matching /${slash.query}` : "Commands", { small: true, color: "dim" }),
				...slash.commands.map((row, index) => {
					const leaf = commandLeaf(row);
					return {
						type: "item",
						image: row.image,
						icon: "/",
						text: commandTitle(row),
						strong: true,
						// The values it can't run without, as Discord shows them next to the name.
						chips: (leaf.options || []).filter((o) => o.required).map((o) => o.name),
						subtitle: leaf.description || "No description",
						detail: row.application?.name || row.application_name || "",
						height: COMMAND_ROW,
						selected: index === slash.selected,
						reveal: reveal && index === slash.selected,
						onClick: () => selectSlashCommand(row),
					};
				}),
				slash.commands.length ? null : slash.error ? label(slash.error, { small: true, color: "red" }) : slash.loading ? { type: "spinner" } : label("No matching commands.", { small: true, color: "faint" }),
			],
		},
	];
}

function attach() {
	const c = chat;
	if (!c) return;
	try {
		c.files = [...c.files, ...App.discord.pickFiles()].slice(0, 10);
	} catch (e) {
		fail(e);
	}
}

function typed(v) {
	if (!chat) return;
	chat.draft = v;
	if (slash && slash.command) {
		if (!v.startsWith(`/${slash.command.name}`) || (v.length > slash.command.name.length + 1 && !/\s/.test(v[slash.command.name.length + 1]))) slash = null;
	} else {
		const match = /^\/([^\s]*)$/.exec(v);
		if (match && !chat.editing) findSlash(match[1]);
		else slash = null;
	}
	// Discord shows "is typing" for 10 seconds; told again while typing goes on.
	if (v && !chat.editing && Date.now() - chat.typed > 8e3) {
		chat.typed = Date.now();
		App.discord.typing(chat.id);
	}
}

const date = (t) => {
	const d = new Date(t);
	return isNaN(+d) ? "" : d.toLocaleDateString();
};
// The hour, with the date only when it isn't today, as Discord shows it.
const time = (t) => {
	const d = new Date(t);
	if (isNaN(+d)) return "";
	const hour = `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
	return date(t) === date(Date.now()) ? hour : `${date(t)} ${hour}`;
};

// A picture in chat at most this wide (GIFs play); a click opens it in the app's picture viewer. A spoiler stays
// covered until clicked, as in Discord.
const picture = (p) => (p.spoiler && !revealed.has(p.stream) ? button("▒▒  Spoiler: click to show  ▒▒", () => revealed.add(p.stream), { tooltip: "The sender marked this picture as a spoiler" }) : { type: "video", stream: p.stream, controls: false, width: Math.min(p.width || 400, 400), height: 300, text: "Loading picture…", tooltip: "Click to view", onClick: () => App.ui.view(p.url) });

const VIDEO = /\.(mp4|webm|mov|mkv|m4v)(\?|$)/i;
/** A file in a message: a video plays in the app's player, anything else opens in the browser. */
const attachment = (f) => (VIDEO.test(f.name) || VIDEO.test(f.url) ? { type: "link", text: `▶ ${f.name}`, onClick: () => App.ui.view(f.url, f.name) } : { type: "link", text: `📎 ${f.name}`, url: f.url });

// A bot's card or a link preview: who it is from, the title (a link, or in the embed's color), text and picture.
function embed(e) {
	return {
		type: "group",
		children: [
			e.author ? label(e.author, { small: true, strong: true }) : null,
			e.title ?
				e.url ?
					{ type: "link", text: e.title, onClick: () => openLink(e.url) }
				:	label(e.title, { strong: true, color: e.color || undefined })
			:	null,
			e.text ? { type: "markdown", text: e.text, onLink: openLink } : null,
			e.image ? picture(e.image) : null,
		],
	};
}

// A server's own emoji as Discord's API names it ("name:id"), or the emoji itself.
const emojiKey = (r) => (r.emojiId ? `${r.emoji}:${r.emojiId}` : r.emoji);
const messageLink = (c, m) => `https://discord.com/channels/${c.guildId || "@me"}/${c.id}/${m.id}`;

/** What a right click on a message offers: a quick reaction, reply, edit, pin and delete, copying, and its link. */
function messageMenu(m, me) {
	const c = chat;
	const react = (e) => () => App.discord.react(c.id, m.id, e, true).catch(fail);
	return [
		{ type: "row", children: QUICK.map((e) => ({ type: "button", variant: "icon", label: e, size: 16, tooltip: "React", onClick: react(e) })) },
		c.canSend ?
			button("Reply", () => {
				c.replyTo = m;
				c.editing = null;
			})
		:	null,
		m.authorId === me && m.raw ?
			button("Edit", () => {
				c.editing = m;
				c.replyTo = null;
				c.draft = m.raw;
			})
		:	null,
		button(m.pinned ? "Unpin" : "Pin", () =>
			App.discord
				.pin(c.id, m.id, !m.pinned)
				.then(() => {
					m.pinned = !m.pinned;
				})
				.catch(fail),
		),
		c.guildId ? button("Start a thread", () => (c.newThread = { name: (m.raw || "").slice(0, 60), text: "" })) : null,
		separator,
		m.raw ? button("Copy text", () => App.ui.copy(m.raw)) : null,
		button("Copy message link", () => App.ui.copy(messageLink(c, m))),
		button("Copy message ID", () => App.ui.copy(m.id)),
		button("Open in the browser", () => App.ui.openUrl(messageLink(c, m))),
		m.authorId && m.authorId !== me ? [separator, button(`Profile of ${m.author || "them"}`, () => showProfile(m.authorId, c.guildId)), button(`Message ${m.author || "them"}`, () => messageUser(m.authorId)), c.canSend ? button("Mention", () => (c.draft = `${c.draft}<@${m.authorId}> `)) : null] : null,
		m.authorId === me ? [separator, button("Delete", () => (c.deleting = m))] : null,
	];
}

/** Reactions under a message: a server's emoji as its picture, then the count; a click adds or takes back yours. */
function reactionRow(m) {
	if (!m.reactions || !m.reactions.length) return null;
	const toggle = (r) => () => App.discord.react(chat.id, m.id, emojiKey(r), !r.me).catch(fail);
	return {
		type: "row",
		children: m.reactions.flatMap((r) => {
			const tip = r.me ? "Take your reaction back" : "React too";
			return r.image ?
					[
						{ type: "image", stream: r.image, size: 20, round: false, morph: false, text: ":", tooltip: `:${r.emoji}:`, onClick: toggle(r) },
						{ type: "button", variant: "pill", label: String(r.count), selected: r.me, tooltip: tip, onClick: toggle(r) },
					]
				:	[{ type: "button", variant: "pill", label: `${r.emoji} ${r.count}`, selected: r.me, tooltip: tip, onClick: toggle(r) }];
		}),
	};
}

// What Discord writes for messages that are events rather than text.
const SYSTEM = { 1: "added someone to the group.", 2: "removed someone from the group.", 3: "started a call.", 4: "changed the group's name.", 5: "changed the group's icon.", 6: "pinned a message to this channel.", 7: "joined the server. 👋", 8: "boosted the server! 🚀", 9: "boosted the server! 🚀", 10: "boosted the server! 🚀", 11: "boosted the server! 🚀", 18: "started a thread." };

// One header per run of messages from the same person within a few minutes, as Discord groups them. In a list of
// found or pinned messages (`jump`), each has its header and a way to it.
function messageRows(list, me, jump) {
	return list.map((m, i) => {
		if (SYSTEM[m.type] && !m.content) return label(`→ ${m.author || "Someone"} ${SYSTEM[m.type]}`, { small: true, color: "faint" });
		const prev = list[i - 1];
		const joined = !jump && !m.replyTo && prev && !SYSTEM[prev.type] && prev.authorId === m.authorId && Date.parse(m.timestamp) - Date.parse(prev.timestamp) < 5 * 60e3;
		const menu = messageMenu(m, me);
		const reply = m.replyTo;
		// A line with the date where a new day starts, as Discord divides its chat.
		const day = date(m.timestamp);
		const newDay = !jump && (!prev || date(prev.timestamp) !== day);
		return {
			type: "column",
			spacing: 0,
			children: [
				newDay ? [{ type: "space", size: 6 }, label(day, { small: true, strong: true, color: "faint" }), separator] : null,
				joined && !newDay ? null : { type: "space", size: 8 },
				reply ? { type: "item", icon: "↪", small: true, indent: 12, text: `${reply.author ? `@${reply.author}  ` : ""}${reply.content}`, onClick: reply.authorId ? () => showProfile(reply.authorId, chat.guildId) : undefined } : null,
				joined && !newDay ? null : (
					{
						type: "item",
						image: m.avatar || "-",
						text: `${m.author || "?"}${m.bot ? "  [BOT]" : ""}`,
						detail: `${m.pinned ? "📌 " : ""}${time(m.timestamp)}`,
						strong: true,
						color: m.mentioned ? "yellow" : bright(),
						height: 30,
						tooltip: "Profile · right click for more",
						onClick: () => showProfile(m.authorId, chat.guildId),
						contextMenu: menu,
					}
				),
				// Everything said goes under the name, past the avatar, as in Discord.
				{
					type: "column",
					indent: 36,
					spacing: 2,
					children: [m.content ? { type: "markdown", text: m.content, onLink: openLink, contextMenu: menu } : null, m.edited ? label("(edited)", { small: true, color: "faint" }) : null, ...(m.images || []).map(picture), ...(m.embeds || []).map(embed), ...(m.attachments || []).map(attachment), reactionRow(m), jump ? { type: "link", text: "Jump to it", onClick: () => goTo(chat.guildId, m.channelId, m.id) } : null],
				},
			],
		};
	});
}

/** Above the input, when there is any: a reply or edit under way, a delete to confirm, or files to send. */
function inputBar(c) {
	const cancel = (onClick) => icon("✕", "Cancel", onClick);
	if (c.deleting) {
		const m = c.deleting;
		return {
			type: "bar",
			left: label("Delete this message?", { small: true, color: "red" }),
			right: [
				button("Delete", () => {
					c.deleting = null;
					App.discord.deleteMessage(c.id, m.id).catch(fail);
				}),
				cancel(() => (c.deleting = null)),
			],
		};
	}
	if (c.editing) return { type: "bar", left: label("Editing your message", { small: true, color: "accent" }), right: cancel(() => ((c.editing = null), (c.draft = ""))) };
	const files = c.files.length ? { type: "row", children: c.files.map((f) => button(`📄 ${f.name} (${size(f.size)}) ✕`, () => (c.files = c.files.filter((x) => x !== f)), { tooltip: "Don't send" })) } : null;
	if (c.replyTo) return { type: "bar", left: [label(`Replying to ${c.replyTo.author || "them"}`, { small: true, color: "accent" }), files], right: cancel(() => (c.replyTo = null)) };
	return files && { type: "bar", left: files };
}

/** Who is typing, under the input. */
function typingLine(c) {
	const now = Date.now();
	const names = [...c.typing.values()].filter((t) => t.until > now).map((t) => t.name);
	return (
		names.length > 3 ? "Several people are typing…"
		: names.length > 1 ? `${names.join(", ")} are typing…`
		: names.length ? `${names[0]} is typing…`
		: ""
	);
}

/** The pins, a search or the threads, in place of the messages. */
function listView(c, me) {
	const l = c.list;
	const back = c.type != null && FORUM.has(c.type) ? null : button("← Back to the messages", () => ((c.view = "messages"), (c.list = null)));
	if (c.view === "search") {
		return [
			back,
			{ type: "input", value: c.query, hint: c.guildId ? "Search this server" : "Search this conversation", onChange: (v) => (c.query = v), onSubmit: () => runSearch(c) },
			!l ? label("Type and press Enter.", { small: true, color: "faint" })
			: l.loading ? { type: "spinner" }
			: l.error ? label(l.error, { small: true, color: "red" })
			: [label(`${l.total ?? l.items.length} results`, { small: true, color: "dim" }), ...messageRows(l.items, me, true)],
		];
	}
	if (!l) return null;
	if (c.view === "pins")
		return [
			back,
			heading("PINNED MESSAGES"),
			l.loading ? { type: "spinner" }
			: l.error ? label(l.error, { small: true, color: "red" })
			: l.items.length ? messageRows(l.items, me, true)
			: label("Nothing is pinned here.", { small: true, color: "faint" }),
		];
	const forum = FORUM.has(c.type);
	return [
		back,
		{ type: "bar", left: heading(forum ? "POSTS" : "THREADS"), right: [button(l.archived ? "Active" : "Older", () => loadThreads(c, !l.archived), { tooltip: l.archived ? "Show active threads" : "Show archived threads" }), c.canSend ? button(forum ? "New post" : "New thread", () => (c.newThread = { name: "", text: "" })) : null] },
		newThreadForm(c, forum),
		l.loading ? { type: "spinner" }
		: l.error ? label(l.error, { small: true, color: "red" })
		: l.items.length ?
			l.items.map((t) => ({
				type: "column",
				children: [
					{
						type: "item",
						icon: t.archived ? "🗄" : "🧵",
						text: t.name,
						strong: true,
						detail: `${t.messages ?? 0} 💬`,
						onClick: () => openChat({ ...t, canSend: c.canSend }, c.guildId),
						contextMenu: [
							button(t.joined ? "Leave" : "Join (show it in the list)", () =>
								App.discord
									.joinThread(t.id, !t.joined)
									.then(() => (t.joined = !t.joined))
									.catch(fail),
							),
							button("Copy link", () => App.ui.copy(`https://discord.com/channels/${c.guildId}/${t.id}`)),
						],
					},
					t.preview ? label(t.preview, { small: true, color: "dim" }) : null,
					t.owner ? label(`by ${t.owner}`, { small: true, color: "faint" }) : null,
				],
			}))
		:	label(l.archived ? "No older threads." : "No threads yet.", { small: true, color: "faint" }),
	];
}

/** A new thread's name (and for a forum post, its first message). */
function newThreadForm(c, forum) {
	const t = c.newThread;
	if (!t) return null;
	const create = () => {
		if (!t.name.trim() || (forum && !t.text.trim())) return;
		App.discord
			.createThread(c.id, t.name, forum ? t.text : null)
			.then((th) => openChat({ ...th, canSend: true }, c.guildId))
			.catch(fail);
		c.newThread = null;
	};
	return {
		type: "group",
		children: [{ type: "input", value: t.name, hint: forum ? "Post title" : "Thread name", onChange: (v) => (t.name = v), onSubmit: forum ? undefined : create }, forum ? { type: "input", value: t.text, hint: "Your post", multiline: true, onChange: (v) => (t.text = v) } : null, { type: "row", children: [button(forum ? "Post" : "Create", create, { variant: "filled" }), button("Cancel", () => (c.newThread = null))] }],
	};
}

App.ui.registerPanel({
	id: "chat",
	title: "Discord chat",
	// Docked left after the channel list: panels dock in the order they are registered.
	dock: "left",
	width: 380,
	header: false,
	render: () => {
		if (!chat) return label("Pick a text channel in the Discord list.");
		const c = chat;
		const s = App.discord.state();
		const me = s.user ? s.user.id : null;
		const forum = FORUM.has(c.type);
		const dm = !c.guildId && s.dms.find((d) => d.id === c.id);
		const inCall = !!s.voice && s.voice.channelId === c.id;
		const header = {
			type: "bar",
			left: {
				type: "item",
				icon:
					forum ? "💬"
					: c.guildId ? "#"
					: "@",
				text: c.name,
				strong: true,
				height: 30,
				contextMenu: dm && dm.userId ? userMenu(dm.userId, dm.name, null) : undefined,
			},
			right: [dm ? icon("📞", inCall ? "Leave the call" : "Start a call", () => (inCall ? App.discord.leave() : callDm(dm)), inCall) : null, c.canSend && !forum ? icon("/", "Browse slash commands", openSlashCommands) : null, forum ? null : icon("📌", "Pinned messages", () => (c.view === "pins" ? (c.view = "messages") : loadPins(c)), c.view === "pins"), c.guildId && !forum ? icon("🧵", "Threads", () => (c.view === "threads" ? (c.view = "messages") : loadThreads(c, false)), c.view === "threads") : null, icon("🔍", "Search", () => (c.view = c.view === "search" ? "messages" : "search"), c.view === "search"), c.guildId ? icon("👥", "Members", () => (App.ui.isOpen("members") ? (App.ui.close("members"), store.set("members", false)) : (App.ui.open("members"), store.set("members", true))), App.ui.isOpen("members")) : null, icon("✕", "Close this chat", () => App.ui.close("chat"))],
		};
		if (c.view !== "messages") return [header, separator, c.error ? label(c.error, { color: "red", small: true }) : null, { type: "scroll", children: listView(c, me) }];
		const above = inputBar(c);
		const commandPicker = c.canSend ? slashView(c) : null;
		// A command's form takes the message box's place and is as tall as its options.
		const form = !!commandPicker && !!slash.command;
		return [
			header,
			separator,
			c.error ? label(c.error, { color: "red", small: true }) : null,
			{
				type: "pinned",
				top: {
					type: "scroll",
					// The newest at the bottom and from there upward, as in Discord; a link to an older message stays on it.
					stickToBottom: !c.jumped,
					key: c.id,
					spacing: 2,
					reserve: form ? "pinned" : (c.canSend ? 76 : 30) + (above ? 40 : 0) + (commandPicker ? slashHeight() : 0),
					children: [c.more ? button(c.loading ? "Loading…" : "Load older messages", loadOlder, { enabled: !c.loading }) : null, c.loading && !c.messages.length ? { type: "spinner" } : null, c.newThread ? newThreadForm(c, false) : null, ...messageRows(c.messages, me, false), c.jumped ? button("Jump to the present", () => openChat(c, c.guildId)) : null],
				},
				bottom: [
					above,
					c.canSend ?
						[
							commandPicker,
							form ? null : (
								{
									type: "bar",
									left: [
										c.editing ? null : icon("📎", "Send files (up to 10 MB together)", attach),
										{
											type: "input",
											value: c.draft,
											padding: 10,
											keepFocus: true,
											hint:
												c.editing ? "Edit your message"
												: c.files.length ? "Add a message (optional)"
												: `Message ${c.guildId ? "#" : "@"}${c.name}`,
											onChange: typed,
											onSubmit: send,
											onKey: commandPicker ? slashKey : undefined,
										},
									],
								}
							),
							label(typingLine(c), { small: true, color: "dim" }),
						]
					:	label("You can't send messages in this channel.", { small: true, color: "faint" }),
				],
			},
		];
	},
});

// ---- the member list, at the right as in Discord ----

App.ui.registerPanel({
	id: "members",
	title: "Members",
	dock: "right",
	width: 280,
	render: () => {
		const s = App.discord.state();
		const list = s.members;
		if (!chat || !chat.guildId) return label("Open a server's channel to see who is in it.", { small: true, color: "faint" });
		if (!list || list.guildId !== chat.guildId) return [{ type: "spinner" }, label("Getting the member list…", { small: true, color: "faint" })];
		const g = chat.guildId;
		const upto = membersUpto.get(g) || 100;
		// Discord lists everyone online (and offline people in smaller servers); further rows come 100 at a time.
		const more = list.loaded >= upto - 1;
		return [
			label(`${list.online} online · ${list.total} members`, { small: true, color: "dim" }),
			{
				type: "scroll",
				children: [
					list.rows.map((r) => {
						if (r.group != null) return [{ type: "space", size: 6 }, heading(`${r.group.toUpperCase()} — ${r.count}`)];
						const sub = extraLine(r);
						const open = () => showProfile(r.userId, g);
						return [{ type: "item", text: `${r.name || "?"}${r.bot ? "  [BOT]" : ""}`, image: r.avatar || "-", dot: dot(r.status), color: r.color || undefined, height: sub ? 26 : 32, tooltip: r.activity && r.custom ? r.activity : undefined, onClick: open, contextMenu: userMenu(r.userId, r.name, g) }, sub ? { type: "item", text: sub, small: true, color: "faint", indent: 34, height: 14, onClick: open } : null];
					}),
					more ?
						button("Show more members", () => {
							membersUpto.set(g, upto + 100);
							App.discord.memberRange(g, chat.id, upto + 99);
						})
					:	null,
				],
			},
		];
	},
});

// ---- cameras and Go Live streams in the call ----

function callView() {
	const s = App.discord.state();
	const v = s.voice;
	if (!v) return label("Join a voice channel or call to see its cameras and streams.", { small: true, color: "faint" });
	const me = s.user.id;
	const here = s.voiceStates.filter((m) => m.channelId === v.channelId);
	const w = s.watching;
	const tile = (stream, name, speaking) => ({ type: "column", children: [{ type: "video", stream, height: 180, text: "Waiting for video…" }, label(name, { small: true, strong: true, color: speaking ? "green" : undefined })] });
	const tiles = [v.video === true ? tile(`discord-video:${me}`, "You", false) : null, s.golive && s.golive.status === "connected" ? tile(`discord-stream:${me}`, `Your stream · ${plural(s.golive.viewers || 0, "viewer")}`, false) : null, ...here.filter((m) => m.userId !== me && m.video).map((m) => tile(`discord-video:${m.userId}`, m.name, m.speaking))].filter(Boolean);
	const streamers = here.filter((m) => m.userId !== me && m.stream && !(w && w.userId === m.userId));
	const watched = w && here.find((m) => m.userId === w.userId);
	return [
		w ?
			[
				{
					type: "bar",
					left: label(
						`${watched ? watched.name : "Their"} stream${
							w.status === "connecting" ? " · connecting…"
							: w.status === "ended" ? " ended"
							: ""
						}`,
						{ strong: true },
					),
					right: button("Stop watching", () => App.discord.watchStream(null)),
				},
				w.error ? label(w.error, { small: true, color: w.status === "error" ? "red" : "faint" }) : null,
				w.status === "ended" ? null : { type: "video", stream: `discord-stream:${w.userId}`, height: "60%", text: "Waiting for the stream…" },
				separator,
			]
		:	null,
		streamers.length ? { type: "row", children: streamers.map((m) => button(`🔴 Watch ${m.name}`, () => watch(m.userId))) } : null,
		tiles.length ? { type: "grid", columns: 2, fill: true, minWidth: 220, children: tiles }
		: w ? null
		: label("Nobody here has a camera on or is live.", { small: true, color: "faint" }),
	];
}

// ---- profiles and invites, in windows of their own ----

function showProfile(userId, guildId) {
	if (!userId) return;
	profile = { userId, data: null, error: null, draft: "" };
	const mine = profile;
	App.ui.open("profile");
	App.discord
		.profile(userId, guildId)
		.then((p) => {
			mine.data = p;
		})
		.catch((e) => {
			mine.error = e.message;
		});
}

function profileView() {
	if (!profile) return null;
	const p = profile.data;
	if (!p) return profile.error ? label(profile.error, { color: "red" }) : { type: "spinner" };
	const s = App.discord.state();
	const me = s.user && s.user.id === p.id;
	const name = p.nick || p.name || p.username || "?";
	const section = (title, body) => [{ type: "space", size: 8 }, heading(title), body];
	const known = [...(s.voiceStates || []), ...((s.members && s.members.rows) || []), ...(s.dms || [])].find((x) => x.userId === p.id);
	const status = me ? s.user.status : p.status || (known && known.status);
	const extra =
		me ? s.user
		: p.custom || p.activity ? p
		: known;
	const custom = extra && (extra.custom || extra.customEmoji || extra.customEmojiImage);
	const activity = extra && extra.activity;
	const mutual = [p.mutualFriends ? plural(p.mutualFriends, "mutual friend") : null, p.mutualGuilds.length ? plural(p.mutualGuilds.length, "mutual server") : null].filter(Boolean).join(" · ");
	const sendDm = () => {
		const text = profile.draft.trim();
		if (!text) return;
		profile.draft = "";
		messageUser(p.id).then((d) => d && App.discord.send(d.id, text).then(() => App.ui.close("profile"), fail));
	};
	return [
		p.banner ? { type: "video", stream: p.banner, controls: false, text: " " } : null,
		{
			type: "row",
			children: [
				{ type: "image", stream: p.avatar, text: initials(name), size: 72, morph: false, ring: dot(status), tooltip: status && STATUS[status] ? STATUS[status][0] : undefined },
				{
					type: "column",
					children: [{ type: "heading", text: name }, label([p.username, p.pronouns].filter(Boolean).join(" • ") + (p.bot ? "  · BOT" : ""), { color: "dim" }), p.nick && p.name && p.nick !== p.name ? label(p.name, { small: true, color: "faint" }) : null, p.badges.length ? { type: "row", children: p.badges.map((b) => ({ type: "image", stream: b.image, size: 20, round: false, morph: false, text: "", tooltip: b.description, onClick: b.link ? () => openLink(b.link) : undefined })) } : null],
				},
			],
		},
		custom ?
			{
				type: "group",
				children: [{ type: "row", children: [extra.customEmojiImage ? { type: "image", stream: extra.customEmojiImage, size: 18, round: false, morph: false, text: "" } : null, label(`${extra.customEmoji ? `${extra.customEmoji} ` : ""}${extra.custom || ""}`)] }],
			}
		:	null,
		activity ? label(`🎮 ${activity}`, { small: true, color: "accent" }) : null,
		mutual ? label(mutual, { small: true, color: "dim" }) : null,
		p.error ? label(`Only part of the profile shows: ${p.error}`, { small: true, color: "faint" }) : null,
		separator,
		{
			type: "scroll",
			reserve: me ? 40 : 84,
			children: [
				p.bio ? section("ABOUT ME", { type: "markdown", text: p.bio, onLink: openLink }) : null,
				section("MEMBER SINCE", label(`Discord: ${date(p.createdAt)}${p.joinedAt ? `   ·   This server: ${date(p.joinedAt)}` : ""}`, { small: true })),
				p.roles.length ? section("ROLES", { type: "grid", columns: 2, children: p.roles.map((r) => label(`● ${r.name}`, { small: true, color: r.color || "dim" })) }) : null,
				p.mutualGuilds.length ? section("MUTUAL SERVERS", label(p.mutualGuilds.join(", "), { small: true })) : null,
				p.connections.length ?
					section(
						"CONNECTIONS",
						p.connections.map((c) => label(`${c.type}: ${c.name}`, { small: true })),
					)
				:	null,
			],
		},
		me ? null : { type: "input", value: profile.draft, hint: `Message @${name}`, onChange: (v) => (profile.draft = v), onSubmit: sendDm },
		{
			type: "row",
			children: [me || p.bot ? null : button("Call", () => callUser(p.id)), button("Copy user name", () => App.ui.copy(p.username || name)), button("Copy user ID", () => App.ui.copy(p.id))],
		},
	];
}

function showInvite(code) {
	invite = { code, data: null, error: null, joining: false };
	const mine = invite;
	App.ui.open("invite");
	App.discord
		.invite(code)
		.then((v) => {
			mine.data = v;
		})
		.catch((e) => {
			mine.error = e.message;
		});
}

function inviteView() {
	if (!invite) return null;
	const v = invite.data;
	const inBrowser = button("Join in the browser", () => App.ui.openUrl(`https://discord.com/invite/${invite.code}`), { tooltip: "Discord's site shows its captcha; the server then shows up here" });
	if (!v) return invite.error ? [label(`This invite doesn't work: ${invite.error}`, { color: "red" }), inBrowser] : { type: "spinner" };
	const go = () => {
		pick(v.guildId);
		show(true);
		App.ui.close("invite");
	};
	const join = () => {
		const mine = invite;
		mine.joining = true;
		mine.error = null;
		App.discord
			.acceptInvite(v.code)
			.then(go)
			.catch((e) => {
				mine.error = e.message;
			})
			.finally(() => {
				mine.joining = false;
			});
	};
	// A captcha can only be done on Discord's own site: joining there brings the server here too.
	const captcha = !!invite.error && /captcha/i.test(invite.error);
	return [
		label(v.inviter ? `${v.inviter} invited you to join` : "You're invited to join", { small: true, color: "dim" }),
		{ type: "heading", text: v.guild || "a server" },
		v.members != null ? label(`🟢 ${v.online ?? 0} online   ·   ${v.members} members`, { small: true, color: "dim" }) : null,
		v.channel ? label(`#${v.channel}`, { small: true, color: "faint" }) : null,
		v.description ? label(v.description, { small: true }) : null,
		{ type: "space", size: 8 },
		v.joined ? button("Go to the server", go, { variant: "filled" })
		: invite.joining ? { type: "spinner" }
		: button("Join the server", join, { variant: "filled" }),
		invite.error ? label(captcha ? "Discord wants a captcha for this, which only its own site can show. Join there; the server then appears here by itself." : invite.error, { small: true, color: captcha ? "yellow" : "red" }) : null,
		captcha ? inBrowser : null,
	];
}

// ---- your custom status, and questions to confirm ----

let customEdit = null;
function openCustom() {
	const u = App.discord.state().user || {};
	customEdit = { text: u.custom || "", emoji: u.customEmoji || "" };
	App.ui.open("custom");
}

function customView() {
	if (!customEdit) return null;
	const c = customEdit;
	const save = () => {
		App.discord.setCustomStatus(c.text.trim() || null, c.emoji.trim() || null);
		App.ui.close("custom");
	};
	return [
		label("What's on your mind? Everyone who can see you sees it beside your name.", { small: true, color: "dim" }),
		{
			type: "row",
			children: [
				{ type: "input", value: c.emoji, hint: "😀", width: 44, onChange: (v) => (c.emoji = [...v].slice(0, 2).join("")) },
				{ type: "input", value: c.text, hint: "Set a custom status", onChange: (v) => (c.text = v.slice(0, 128)), onSubmit: save },
			],
		},
		{ type: "space", size: 6 },
		{ type: "row", children: [button("Save", save, { variant: "filled" }), button("Clear", () => ((c.text = ""), (c.emoji = ""), save()))] },
	];
}

/** Asks before something that can't be undone here; `run` returns a promise. */
function ask(text, yes, run) {
	confirm = { text, yes, run, busy: false };
	App.ui.open("confirm");
}

function confirmView() {
	if (!confirm) return null;
	const q = confirm;
	const go = () => {
		q.busy = true;
		Promise.resolve(q.run())
			.then(() => App.ui.close("confirm"))
			.catch((e) => {
				q.busy = false;
				fail(e);
			});
	};
	return [label(q.text), { type: "space", size: 8 }, q.busy ? { type: "spinner" } : { type: "row", children: [button(q.yes, go, { variant: "filled" }), button("Cancel", () => App.ui.close("confirm"))] }];
}

// ---- the connection: straight to Discord, or through a proxy ----

let conn = null;
function openConnection() {
	const p = App.discord.state().proxy;
	const saved = store.get("proxyAddress", "");
	conn = { mode: !p ? "off" : p.mode, address: saved, testing: false, result: null };
	// Testing goes through the Discord client; starting it does nothing more until you log in.
	App.discord.connect();
	App.ui.open("connection");
}

function connectionView() {
	if (!conn) return null;
	const c = conn;
	const setting = () =>
		c.mode === "off" ? null
		: c.mode === "system" ? "system"
		: c.address.trim();
	const test = () => {
		c.testing = true;
		c.result = null;
		App.discord
			.testProxy(setting())
			.then((r) => (c.result = { ok: true, text: `Discord answered in ${r.ms} ms.` }))
			.catch((e) => (c.result = { ok: false, text: `Can't reach Discord: ${e.message}` }))
			.finally(() => (c.testing = false));
	};
	const save = () => {
		try {
			App.discord.setProxy(setting());
			if (c.mode === "custom") store.set("proxyAddress", c.address.trim());
			App.ui.close("connection");
		} catch (e) {
			c.result = { ok: false, text: e.message };
		}
	};
	const shown = App.discord.state().proxy;
	return [
		label("Only Discord's traffic takes this way: TeamSpeak and everything else stay as they are.", { small: true, color: "dim" }),
		{ type: "space", size: 4 },
		{
			type: "select",
			value: c.mode,
			options: [
				{ value: "off", label: "Direct (no proxy)" },
				{ value: "system", label: "Windows' proxy (as set by v2rayN, Clash and the like)" },
				{ value: "custom", label: "This proxy" },
			],
			onChange: (v) => ((c.mode = v), (c.result = null)),
		},
		c.mode === "custom" ? [{ type: "input", value: c.address, hint: "socks5://127.0.0.1:10808 or http://127.0.0.1:10809", onChange: (v) => ((c.address = v), (c.result = null)), onSubmit: test }, label("SOCKS5 or HTTP, with user:password@ in front of the address if it wants a login. A tunnel app (v2rayN, Clash, Psiphon, Tor…) shows its local port in its settings.", { small: true, color: "faint" })]
		: c.mode === "system" ? label(shown && shown.mode === "system" && shown.address ? `Now: ${shown.address}` : "Uses what Windows' proxy settings say when connecting.", { small: true, color: "faint" })
		: null,
		c.mode !== "off" ? label("Voice needs a SOCKS5 proxy that relays UDP; through an HTTP proxy, voice goes direct.", { small: true, color: "faint" }) : null,
		{ type: "space", size: 6 },
		{ type: "row", children: [button("Test", test, { enabled: !c.testing }), button("Save and reconnect", save, { variant: "filled", enabled: c.mode !== "custom" || !!c.address.trim() })] },
		c.testing ? { type: "spinner" } : null,
		c.result ? label(c.result.text, { small: true, color: c.result.ok ? "green" : "red" }) : null,
	];
}

// Floating windows (no dock), closed with their ✕.
App.ui.registerPanel({ id: "profile", title: "Discord profile", width: 340, height: 600, render: profileView });
App.ui.registerPanel({ id: "invite", title: "Discord invite", width: 320, height: 260, render: inviteView });
App.ui.registerPanel({ id: "connection", title: "Discord connection", width: 380, height: 330, render: connectionView });
App.ui.registerPanel({ id: "call", title: "Discord call", width: 640, height: 480, render: callView });
App.ui.registerPanel({ id: "custom", title: "Custom status", width: 340, height: 170, render: customView });
App.ui.registerPanel({ id: "confirm", title: "Discord", width: 320, height: 150, render: confirmView });

// Dialogs over the app: the login, and your status and account (⚙ under the channels); a pick closes it.
App.ui.registerModal({ id: "login", title: "Log in to Discord", width: 360, render: loginView });
App.ui.registerModal({
	id: "account",
	title: "Discord",
	width: 280,
	render: () => {
		const s = App.discord.state();
		if (s.status !== "ready") return null;
		return accountMenu(s)
			.filter(Boolean)
			.map((n) =>
				n.type === "button" ?
					{
						...n,
						onClick: () => {
							App.ui.close("account");
							n.onClick();
						},
					}
				:	n,
			);
	},
});

if (store.get("open", false)) show(true);
