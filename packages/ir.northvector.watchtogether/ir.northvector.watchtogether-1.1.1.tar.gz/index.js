// Watch a video with your channel over App.p2p and App.player. Sharing invites everyone in your channel
// who runs this plugin; who joins gets the video and plays it at the same moment. Each shared video is a
// room: whoever shared it is its hub, connected to every viewer, and passes on what one of them does.
// Play, pause and seek go to everyone in the room: the last one who acted repeats where they are every
// 2 seconds, and whoever is more than 1.5 s off seeks there. Leaving a room leaves the others watching,
// and frees you to join someone else's. Audio track, subtitle and volume stay each viewer's own; a
// subtitle file can be shared (sent in pieces), and someone watching without subtitles gets the shared
// one turned on. Who joins later is sent the subtitles shared so far.

const DRIFT = 1.5;
const BEAT = 2000;
// Base64 per message, under the 60 KB P2P limit.
const PIECE = 48000;

// By session: the person, its route once open, messages waiting for it to open (or for "busy" to pass);
// `pending`: they asked us and we haven't said yes; `invited`: we asked them to our room;
// `member`: watching the same video as us.
const peers = new Map();
// What we watch: { url, sub, room, host } (host: the session of who shared it; null when we did), and
// the newest action seen ({ time, by }), so an older one never wins.
let video = null;
let last = { time: 0, by: "" };
// We acted last, so we repeat where we are.
let leading = false;
// Invitations to someone's room, oldest first: { session, name, url, sub, pos, playing, room, time, by }.
// `url` is null until their video arrives; `joining`: we said yes and wait for it.
let invites = [];
// Subtitles: { name, file } ("user:name" or an address), `from` who sent it (none: we shared it);
// and pieces still coming, by id: { name, from, session, parts, of }.
const shared = [];
const incoming = new Map();
let url = "";
let subUrl = "";
let error = null;
// The share field while a video plays, and the track settings (⚙).
let picking = false;
let settings = false;

const me = () => {
  const s = App.app.state();
  const c = s.connections.find((c) => c.id === s.active);
  return c && c.ownClientId != null ? { conn: c, name: (c.clients.find((x) => x.id === c.ownClientId) || {}).name || "me" } : null;
};
const myName = () => (me() || {}).name || "";

// Everyone in our channel who runs this app (P2P knows who does).
const channelMates = () => {
  const m = me();
  if (!m) return [];
  const app = App.p2p.peers();
  return m.conn.clients
    .filter((c) => c.channelId === m.conn.channelId && c.id !== m.conn.ownClientId && app.some((q) => q.connection === m.conn.id && q.clientId === c.id))
    .map((c) => ({ connection: m.conn.id, clientId: c.id, name: c.name }));
};

const flush = (p) => {
  while (p.route && p.outbox.length) {
    try {
      App.p2p.send(p.session, p.outbox[0]);
    } catch (e) {
      // One retry waiting at a time, however many messages queue meanwhile.
      if (String(e.message).startsWith("busy") && !p.retry) p.retry = setTimeout(() => ((p.retry = null), flush(p)), 500);
      return;
    }
    p.outbox.shift();
  }
};
const send = (p, msg) => {
  p.outbox.push(JSON.stringify(msg));
  flush(p);
};
const members = () => [...peers.values()].filter((p) => p.member);
const roomcast = (msg) => members().forEach((p) => send(p, msg));
// As the room's hub, what one viewer did goes on to the others.
const relay = (from, msg) => {
  if (video && !video.host) members().forEach((p) => p !== from && send(p, msg));
};

// ffmpeg, VLC and mpv are looked up on disk: asked again every 2 s (or while installing), not on every frame.
let found = null;
let foundAt = 0;
const backends = () => {
  if (!found || found.installing || Date.now() - foundAt > 2000) {
    found = App.player.backends();
    foundAt = Date.now();
  }
  return found;
};
const setPrefs = (prefs) => {
  App.player.setPrefs(prefs);
  found = null;
};

const now = () => {
  const s = App.player.state();
  return s.open ? { pos: s.position, playing: s.playing } : { pos: 0, playing: false };
};
const loadMsg = () => ({ t: "load", room: video.room, url: video.url, sub: video.sub || null, ...now(), time: last.time, by: last.by });

// An action of ours: everyone follows, and we keep telling them where we are.
const act = (f) => {
  f();
  last = { time: Date.now(), by: myName() };
  leading = true;
  setTimeout(() => video && roomcast({ t: "state", room: video.room, ...now(), time: last.time, by: last.by }), 300);
};

const play = (u, at, playing, sub) => {
  error = null;
  try {
    App.player.open(u, { at, subtitle: sub || -1 });
    if (!playing) App.player.pause();
    return true;
  } catch (e) {
    error = `Couldn't play that video: ${e.message}`;
    return false;
  }
};

// Leaves the room, for us only: the others keep watching.
const leave = () => {
  if (!video) return;
  roomcast({ t: "leave", room: video.room });
  for (const p of peers.values()) p.member = false;
  App.player.close();
  video = null;
  leading = false;
  picking = false;
  settings = false;
};

// Asks the channel mates not asked yet (or asked to an older video) to this room.
const inviteMates = () => {
  for (const m of channelMates()) {
    const known = [...peers.values()].find((p) => p.connection === m.connection && p.clientId === m.clientId);
    if (known) {
      if (known.member) continue;
      known.invited = true;
      if (known.route && !known.pending) send(known, loadMsg());
      continue;
    }
    try {
      const session = App.p2p.connect(m.connection, m.clientId);
      if (!peers.has(session)) peers.set(session, { session, ...m, route: null, outbox: [], invited: true });
    } catch {
      // Not reachable over P2P right now: nothing to ask.
    }
  }
};

const share = () => {
  const u = url.trim();
  if (!/^https?:\/\//i.test(u)) return (error = "That isn't a web address. Paste one that starts with http:// or https://.");
  leave();
  if (!play(u, 0, true, null)) return;
  video = { url: u, sub: null, room: `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`, host: null };
  url = "";
  picking = false;
  act(() => {});
  inviteMates();
};

const fileName = (u) => {
  try {
    return decodeURIComponent(u.split(/[?#]/)[0].split("/").pop()) || u;
  } catch {
    return u;
  }
};
const hostOf = (u) => (u.match(/^https?:\/\/([^/?#]+)/i) || [])[1] || "";

// Shows a subtitle, unless the player isn't open yet (then `play` is given it).
const useSubtitle = (file) => {
  try {
    if (App.player.state().open) App.player.setTracks({ subtitle: file });
  } catch (e) {
    error = e.message;
  }
};

// A subtitle someone shared: turned on for us when we watch without one.
const received = (entry) => {
  shared.push(entry);
  const s = App.player.state();
  if (s.open && s.subtitle === -1) useSubtitle(entry.file);
  App.ui.notify(`${entry.from} shared subtitles: ${entry.name}`);
};

// The messages that send one of our subtitles: an address as is, a file in pieces.
const subtitleMsgs = (x) => {
  const room = video && video.room;
  const from = x.from || myName();
  if (!x.file.startsWith("user:")) return [{ t: "subUrl", room, from, url: x.file }];
  const data = App.player.readSubtitle(x.file);
  const id = `${Date.now()}-${x.name}`;
  const of = Math.ceil(data.length / PIECE) || 1;
  return Array.from({ length: of }, (_, part) => ({ t: "sub", room, from, id, name: x.name, part, of, data: data.slice(part * PIECE, (part + 1) * PIECE) }));
};

const shareSubtitle = () => {
  const file = App.player.pickSubtitle();
  if (!file) return;
  const x = { name: file.slice(5), file };
  try {
    subtitleMsgs(x).forEach(roomcast);
  } catch (e) {
    error = e.message;
  }
  shared.push(x);
  useSubtitle(file);
};

// A subtitle on the web: everyone downloads it themselves.
const shareSubtitleUrl = () => {
  const u = subUrl.trim();
  if (!/^https?:\/\//i.test(u)) return (error = "That isn't a subtitle address. Paste one that starts with http:// or https://.");
  subUrl = "";
  if (!shared.some((x) => x.file === u)) shared.push({ name: fileName(u), file: u });
  if (video) video.sub = u;
  useSubtitle(u);
  roomcast({ t: "subUrl", room: video && video.room, from: myName(), url: u });
};

// Joins the room of an invitation: at once when its video is here, else once it comes.
const join = (inv) => {
  const p = peers.get(inv.session);
  if (!p) return (invites = invites.filter((i) => i !== inv));
  if (p.pending) {
    App.p2p.accept(inv.session);
    p.pending = false;
  }
  if (!inv.url) return (inv.joining = true);
  invites = invites.filter((i) => i !== inv);
  leave();
  // Their subtitle address, else the newest subtitle someone sent us.
  const sent = shared.filter((x) => x.from).pop();
  if (!play(inv.url, inv.pos || 0, inv.playing !== false, inv.sub || (sent && sent.file))) return;
  video = { url: inv.url, sub: inv.sub || null, room: inv.room, host: inv.session };
  last = { time: inv.time || 0, by: inv.by || "" };
  p.member = true;
  // They answer with where they are now, however long the invitation waited.
  send(p, { t: "joined", room: inv.room });
};

const decline = (inv) => {
  invites = invites.filter((i) => i !== inv);
  const p = peers.get(inv.session);
  if (!p) return;
  if (p.pending) App.p2p.close(inv.session);
  else send(p, { t: "no", room: inv.room });
};

App.events.on("p2p.request", (r) => {
  peers.set(r.session, { session: r.session, connection: r.connection, clientId: r.clientId, name: r.name, route: null, outbox: [], pending: true });
  invites.push({ session: r.session, name: r.name, url: null });
  App.ui.notify(`${r.name} invites you to watch together`);
  App.ui.open("watch");
});
App.events.on("p2p.open", ({ session, route }) => {
  const p = peers.get(session);
  if (!p) return;
  p.route = route;
  if (video && !video.host && p.invited && !p.member) send(p, loadMsg());
  flush(p);
});
App.events.on("p2p.closed", ({ session, reason }) => {
  const p = peers.get(session);
  if (!p) return;
  if (p.retry) clearTimeout(p.retry);
  peers.delete(session);
  const inv = invites.find((i) => i.session === session);
  invites = invites.filter((i) => i !== inv);
  if (inv && inv.joining) error = `Couldn't join ${p.name}${reason ? `: ${reason}` : ""}.`;
  else if (p.member) App.ui.notify(`${p.name} left`);
  else if (p.invited && video && !video.host) App.ui.notify(reason === "declined" ? `${p.name} declined` : `${p.name} didn't join${reason ? `: ${reason}` : ""}`);
  // Pieces from them that will never complete.
  for (const [id, got] of incoming) if (got.session === session) incoming.delete(id);
});
App.events.on("p2p.message", ({ session, data }) => {
  const p = peers.get(session);
  if (!p) return;
  let m;
  try { m = JSON.parse(data); } catch { return; }
  const here = video && m.room === video.room;
  const newer = () => m.time > last.time || (m.time === last.time && String(m.by) > last.by);
  if (m.t === "load" && typeof m.url === "string") {
    if (here) return;
    const offer = { url: m.url, sub: m.sub, pos: m.pos, playing: m.playing, room: m.room, time: m.time, by: m.by };
    const inv = invites.find((i) => i.session === session);
    if (inv) {
      Object.assign(inv, offer);
      if (inv.joining) join(inv);
      return;
    }
    invites.push({ session, name: p.name, ...offer });
    App.ui.open("watch");
    App.ui.notify(`${p.name} wants to watch a video with you`);
  } else if (m.t === "joined" && here && !video.host) {
    p.member = true;
    send(p, { t: "sync", room: video.room, ...now(), time: last.time, by: last.by });
    for (const x of shared.filter((x) => x.file !== video.sub)) {
      try {
        subtitleMsgs(x).forEach((msg) => send(p, msg));
      } catch {
        // Gone from our data meanwhile: nothing to send.
      }
    }
    App.ui.notify(`${p.name} joined`);
  } else if (m.t === "no" && here) {
    App.ui.notify(`${p.name} said not now`);
  } else if (m.t === "leave" && here && p.member) {
    p.member = false;
    App.ui.notify(video.host === session ? `${p.name} left. Play and pause no longer stay in step with the others.` : `${p.name} left`);
  } else if (m.t === "sync" && here) {
    last = { time: m.time, by: m.by };
    leading = false;
    follow(m);
  } else if (m.t === "state" && here && newer()) {
    last = { time: m.time, by: m.by };
    leading = false;
    follow(m);
    relay(p, m);
  } else if (m.t === "beat" && here && m.time === last.time && m.by === last.by) {
    follow(m);
    relay(p, m);
  } else if (m.t === "subUrl" && /^https?:\/\//i.test(m.url)) {
    if (here) relay(p, m);
    if (!shared.some((x) => x.file === m.url)) received({ name: fileName(m.url), file: m.url, from: m.from || p.name });
  } else if (m.t === "sub" && typeof m.data === "string" && m.of > 0 && m.part >= 0 && m.part < m.of) {
    if (here) relay(p, m);
    const got = incoming.get(m.id) || { name: m.name, from: m.from || p.name, session, parts: [], of: m.of };
    got.parts[m.part] = m.data;
    incoming.set(m.id, got);
    if (got.parts.filter((x) => x != null).length === m.of) {
      incoming.delete(m.id);
      try {
        const file = App.player.saveSubtitle(got.name, got.parts.join(""));
        if (!shared.some((x) => x.file === file && x.from === got.from)) received({ name: got.name, file, from: got.from });
      } catch (e) {
        error = e.message;
      }
    }
  }
});

// Matches someone else's play state and position.
const follow = (m) => {
  const s = App.player.state();
  if (!s.open) return;
  if (m.playing && !s.playing) App.player.resume();
  if (!m.playing && s.playing) App.player.pause();
  if (Math.abs(s.position - m.pos) > DRIFT) App.player.seek(m.pos);
};

setInterval(() => {
  if (leading && video && members().length) roomcast({ t: "beat", room: video.room, ...now(), time: last.time, by: last.by });
}, BEAT);

const clock = (t) => {
  t = Math.max(0, Math.floor(t || 0));
  const h = Math.floor(t / 3600), m = Math.floor((t / 60) % 60), s = t % 60;
  return `${h ? `${h}:${String(m).padStart(2, "0")}` : m}:${String(s).padStart(2, "0")}`;
};

const CHARSETS = [
  { value: "", label: "Auto" }, { value: "UTF-8", label: "UTF-8" }, { value: "CP1256", label: "Arabic / Persian" }, { value: "CP1252", label: "Western" },
  { value: "CP1250", label: "Central European" }, { value: "CP1251", label: "Cyrillic" }, { value: "CP1253", label: "Greek" }, { value: "CP1254", label: "Turkish" },
  { value: "CP1255", label: "Hebrew" }, { value: "CP874", label: "Thai" }, { value: "GBK", label: "Chinese (GBK)" }, { value: "BIG5", label: "Chinese (Big5)" },
  { value: "SHIFT_JIS", label: "Japanese" }, { value: "EUC-KR", label: "Korean" },
];

// ---- what the window shows ----

const setup = (b) => {
  if (b.ffmpeg || b.vlc || b.mpv) return null;
  return {
    type: "group",
    children: [
      { type: "label", text: "One thing first: a video player", strong: true },
      { type: "label", text: "Videos play with ffmpeg (about 90 MB, downloaded once), or with VLC or mpv if you have one installed.", color: "dim" },
      { type: "space", size: 6 },
      b.installing
        ? { type: "progress", value: b.progress, text: `Downloading ffmpeg… ${Math.round((b.progress || 0) * 100)} %` }
        : { type: "button", label: "Download ffmpeg", variant: "filled", onClick: () => App.player.install() },
      b.installError && { type: "label", text: `The download failed: ${b.installError}. Try again, or install VLC or mpv.`, color: "red" },
      { type: "space", size: 4 },
      downloads,
    ],
  };
};

// Where to get each player, for whoever would rather install one themselves.
const downloads = {
  type: "row",
  children: [
    { type: "label", text: "Download", color: "dim", small: true },
    { type: "link", text: "ffmpeg", url: "https://ffmpeg.org/download.html" },
    { type: "link", text: "VLC", url: "https://www.videolan.org/vlc/" },
    { type: "link", text: "mpv", url: "https://mpv.io/installation/" },
  ],
};

const PRIVACY = "Joining connects you straight to them, so they can see your IP address (unless Relay only is on in Settings > Plugins).";

const inviteCard = (inv, can) => ({
  type: "group",
  children: [
    { type: "label", text: inv.url ? `${inv.name} wants to watch with you` : `${inv.name} invites you to watch together`, strong: true },
    inv.url && { type: "label", text: `${fileName(inv.url)}  ·  ${hostOf(inv.url)}`, color: "dim" },
    { type: "space", size: 6 },
    inv.joining
      ? { type: "row", children: [{ type: "spinner" }, { type: "label", text: `Connecting to ${inv.name}…`, color: "dim" }, { type: "button", label: "Cancel", onClick: () => decline(inv) }] }
      : [
          { type: "row", children: [
            { type: "button", label: video ? "Leave this one and join" : "Join", variant: "filled", enabled: can, onClick: () => join(inv) },
            { type: "button", label: inv.url ? "Not now" : "Decline", width: 96, height: 36, onClick: () => decline(inv) },
          ] },
          !can && { type: "label", text: "Set up a video player above to join.", color: "orange", small: true },
          { type: "label", text: PRIVACY, color: "dim", small: true },
        ],
  ],
});

const backendSelect = (b) => ({
  type: "row",
  children: [
    { type: "label", text: "Play", color: "dim" },
    { type: "select", value: b.backend, options: [{ value: "native", label: "in this app" }, ...(b.vlc ? [{ value: "vlc", label: "in VLC" }] : []), ...(b.mpv ? [{ value: "mpv", label: "in mpv" }] : [])], onChange: (v) => setPrefs({ backend: v }) },
  ],
});

const urlField = (can, label) => ({
  type: "row",
  children: [
    { type: "input", value: url, hint: "https://example.com/movie.mp4", width: 440, padding: 8, onChange: (v) => (url = v), onSubmit: share },
    { type: "button", label, variant: "filled", enabled: can && !!url.trim(), onClick: share },
  ],
});

// Nothing playing: what sharing does and who would get it.
const idle = (b, can) => {
  const mates = channelMates();
  return {
    type: "group",
    children: [
      { type: "label", text: "Share a video with your channel", strong: true },
      { type: "label", text: "Paste a link to a video file or stream (MP4, MKV, WebM, HLS). Everyone in your channel with Watch together gets an invitation; play, pause and seeking stay in step for all who join.", color: "dim" },
      { type: "space", size: 8 },
      urlField(can, "Share"),
      { type: "space", size: 4 },
      backendSelect(b),
      { type: "space", size: 4 },
      {
        type: "label",
        text: mates.length ? `Would invite ${mates.map((m) => m.name).join(", ")}` : "Nobody else in your channel runs TeamSpeak Desktop right now. You can still watch on your own.",
        color: "dim",
        small: true,
      },
    ],
  };
};

const skip = (s, by) => act(() => App.player.seek(Math.max(0, Math.min(s.position + by, s.duration || Infinity))));

// The player's control bar: seek bar over one line of controls, volume and time at the left, play in
// the middle, settings and fullscreen at the right.
const controls = (s) => ({
  type: "group",
  children: [
    { type: "slider", value: s.position, min: 0, max: Math.max(1, s.duration, s.position), live: false, showValue: false, width: "fill", onChange: (v) => act(() => App.player.seek(v)) },
    {
      type: "bar",
      left: [
        s.backend === "native" && { type: "volume", stream: s.stream },
        { type: "label", text: s.ended ? "Ended" : `${clock(s.position)} / ${s.duration ? clock(s.duration) : "live"}`, monospace: true, color: "dim" },
        s.loading && { type: "spinner" },
      ],
      center: [
        { type: "button", variant: "icon", label: "⏪", tooltip: "Back 10 seconds, for everyone", onClick: () => skip(s, -10) },
        { type: "button", variant: "icon", size: 24, label: s.playing ? "⏸" : "▶", tooltip: s.ended ? "Play again, for everyone" : s.playing ? "Pause, for everyone" : "Play, for everyone", onClick: () => act(() => (s.playing ? App.player.pause() : App.player.resume())) },
        { type: "button", variant: "icon", label: "⏩", tooltip: "Forward 10 seconds, for everyone", onClick: () => skip(s, 10) },
      ],
      right: [
        { type: "button", variant: "icon", label: "⚙", selected: settings, tooltip: "Audio track and subtitles", onClick: () => (settings = !settings) },
        s.backend === "native" && { type: "fullscreen", stream: s.stream },
      ],
    },
  ],
});

// Who is in the room, who is on the way, and the room's own actions.
const people = () => {
  const status = new Map(App.p2p.sessions().map((x) => [x.id, x.status]));
  const host = video.host && peers.get(video.host);
  const watching = members();
  const coming = video.host ? [] : [...peers.values()].filter((p) => p.invited && !p.member);
  const connecting = coming.filter((p) => status.get(p.session) === "connecting");
  const asked = coming.filter((p) => !connecting.includes(p));
  const uninvited = video.host ? [] : channelMates().filter((m) => ![...peers.values()].some((p) => p.invited && p.connection === m.connection && p.clientId === m.clientId));
  const names = (list) => list.map((p) => p.name).join(", ");
  return {
    type: "bar",
    left: [
      watching.length
        ? { type: "label", text: `Watching with ${names(watching)}${host && host.member ? " (shared it)" : ""}`, strong: true }
        : { type: "label", text: video.host ? "Watching on your own" : "Nobody has joined yet", color: "dim" },
      connecting.length > 0 && { type: "spinner" },
      connecting.length > 0 && { type: "label", text: `${names(connecting)} joining…`, color: "dim", small: true },
      asked.length > 0 && { type: "label", text: `Invited: ${names(asked)}`, color: "dim", small: true },
    ],
    right: [
      uninvited.length > 0 && { type: "button", label: `Invite ${uninvited.length === 1 ? uninvited[0].name : `${uninvited.length} more`}`, tooltip: `Invite ${names(uninvited)} to this video`, onClick: inviteMates },
      { type: "button", label: "New video", selected: picking, tooltip: "Share a different video with your channel", onClick: () => (picking = !picking) },
      { type: "button", label: "Leave", tooltip: "Stop watching. The others keep watching.", onClick: leave },
    ],
  };
};

const subtitleValue = (s) =>
  typeof s.subtitle === "string" ? (shared.find((x) => x.file === s.subtitle || x.file.slice(5) === s.subtitle) || {}).file || s.subtitle : s.subtitle;

const tracks = (s) => ({
  type: "row",
  children: [
    s.audioTracks.length > 1 && { type: "label", text: "Audio", color: "dim" },
    s.audioTracks.length > 1 && { type: "select", value: s.audio, options: s.audioTracks.map((t, i) => ({ value: i, label: t })), onChange: (v) => App.player.setTracks({ audio: v }) },
    { type: "label", text: "Subtitles", color: "dim" },
    {
      type: "select",
      value: subtitleValue(s),
      options: [
        { value: -1, label: "Off" },
        ...s.subtitleTracks.map((t, i) => ({ value: i, label: `${t.label}${t.kind === "text" ? "" : ` (${t.kind})`}` })),
        ...shared.map((x) => ({ value: x.file, label: `${x.name}${x.from ? ` · from ${x.from}` : ""}` })),
      ],
      onChange: (v) => App.player.setTracks({ subtitle: v }),
    },
    s.subtitleLoading && { type: "spinner" },
    s.subtitle !== -1 && { type: "button", label: "−", tooltip: "Show subtitles 0.1 s earlier", onClick: () => App.player.setTracks({ subDelay: Math.round(s.subDelay * 10 - 1) / 10 }) },
    s.subtitle !== -1 && { type: "label", text: `${s.subDelay >= 0 ? "+" : ""}${s.subDelay.toFixed(1)} s`, monospace: true },
    s.subtitle !== -1 && { type: "button", label: "+", tooltip: "Show subtitles 0.1 s later", onClick: () => App.player.setTracks({ subDelay: Math.round(s.subDelay * 10 + 1) / 10 }) },
  ],
});

const subtitleOptions = (s, b) => ({
  type: "group",
  children: [
    { type: "label", text: "Audio and subtitles", strong: true },
    { type: "label", text: "These stay yours; a subtitle you add is shared with everyone watching.", color: "dim", small: true },
    { type: "space", size: 6 },
    tracks(s),
    {
      type: "row",
      children: [
        { type: "button", label: "Add a subtitle file…", tooltip: "Load a subtitle file and share it with everyone watching", onClick: shareSubtitle },
        { type: "input", value: subUrl, hint: "or paste a subtitle address", width: 260, onChange: (v) => (subUrl = v), onSubmit: shareSubtitleUrl },
        { type: "button", label: "Share", enabled: !!subUrl.trim(), onClick: shareSubtitleUrl },
      ],
    },
    typeof s.subtitle === "string" && { type: "row", children: [{ type: "label", text: "Character set", color: "dim" }, { type: "select", value: s.charset, options: CHARSETS, onChange: (v) => App.player.setTracks({ charset: v }) }] },
    s.backend === "native" && {
      type: "row",
      children: [
        { type: "slider", label: "Text size", value: b.subtitleSize, min: 12, max: 72, step: 1, onChange: (v) => setPrefs({ subtitleSize: v }) },
        { type: "checkbox", label: "Box behind the text", checked: b.subtitleBox, onChange: (v) => setPrefs({ subtitleBox: v }) },
      ],
    },
  ],
});

// Subtitles on their way to us.
const arriving = () =>
  [...incoming.values()].map((g) => ({ type: "progress", value: g.parts.filter((x) => x != null).length / g.of, text: `Subtitles from ${g.from}: ${g.name}` }));

const problems = (s) =>
  [error, s.error].filter(Boolean).map((text) => ({ type: "row", children: [{ type: "label", text, color: "red" }, text === error && { type: "button", label: "Dismiss", onClick: () => (error = null) }] }));

const render = () => {
  const b = backends();
  const s = App.player.state();
  const can = b.ffmpeg || b.vlc || b.mpv;
  const watching = video && s.open;
  return [
    setup(b),
    invites.map((inv) => inviteCard(inv, can)),
    problems(s),
    !watching && idle(b, can),
    watching && [
      s.backend === "native" ? { type: "video", stream: s.stream, height: "70%", controls: false } : { type: "label", text: `Playing in ${s.backend === "mpv" ? "mpv" : "VLC"}'s own window; its volume and subtitle settings apply there.`, color: "dim" },
      controls(s),
      settings && subtitleOptions(s, b),
      { type: "space", size: 4 },
      people(),
      picking && { type: "group", children: [{ type: "label", text: "Share a different video", strong: true }, { type: "label", text: "You leave this one; everyone in your channel gets an invitation to the new one.", color: "dim", small: true }, { type: "space", size: 6 }, urlField(can, "Share")] },
    ],
    arriving(),
  ];
};

App.ui.registerWindow({ id: "watch", title: "Watch together", width: 900, height: 780, render });
const menuButton = () => App.ui.registerMenu({ id: "watch", label: "Watch together", icon: "🎬", active: App.ui.isOpen("watch"), onClick: () => App.ui.toggle("watch") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", menuButton);
menuButton();
// Starting P2P right away lets the others find us before the window is ever opened.
App.p2p.peers();
