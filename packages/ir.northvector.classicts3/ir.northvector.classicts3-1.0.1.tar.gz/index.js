// Colors of the stock TeamSpeak 3 client skin; the theme API sets colors only, so the layout stays the app's.
App.theme.register("Classic TS3", {
  bg: "#f0f0f0",
  surface: "#ffffff",
  text: "#000000",
  textDim: "#6d6d6d",
  outline: "#a0a0a0",
  accent: "#3399ff",
  link: "#0066cc",
  talking: "#1e90ff",
});
