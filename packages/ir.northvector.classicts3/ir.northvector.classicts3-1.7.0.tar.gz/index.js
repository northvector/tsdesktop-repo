// The stock TeamSpeak 3 client skin, all of it here: colors, tight metrics, the pictures (SVGs in icons/,
// see THIRD_PARTY.md), the text menu bar and the Options-style settings page. The app only provides the
// generic parts.
const tree = {
  "tree.channel.green": "icons/channel_green.svg", "tree.channel.green.subscribed": "icons/channel_green_subscribed.svg",
  "tree.channel.yellow": "icons/channel_yellow.svg", "tree.channel.yellow.subscribed": "icons/channel_yellow_subscribed.svg",
  "tree.channel.red": "icons/channel_red.svg", "tree.channel.red.subscribed": "icons/channel_red_subscribed.svg",
  "tree.client": "icons/player_off.svg", "tree.client.talking": "icons/player_on.svg",
  "tree.client.commander": "icons/player_commander_off.svg", "tree.client.commander.talking": "icons/player_commander_on.svg",
  "tree.client.away": "icons/away.svg", "tree.client.input_muted": "icons/input_muted.svg",
  "tree.client.output_muted": "icons/output_muted.svg", "tree.client.query": "icons/server_query.svg",
};
const action = {
  "action.mic": "icons/capture.svg", "action.mic.muted": "icons/input_muted.svg",
  "action.speakers": "icons/volume.svg", "action.speakers.muted": "icons/output_muted.svg",
  "action.away": "icons/away.svg", "action.record": "icons/recording_start.svg", "action.record.on": "icons/recording_stop.svg",
  "action.permissions": "icons/permission_server_groups.svg", "action.collected": "icons/weblist.svg",
  "action.friends": "icons/edit_friend_foe_status.svg", "action.market": "icons/addon.svg",
  "action.chat": "icons/player_chat.svg", "action.info": "icons/info.svg", "action.settings": "icons/settings.svg",
};
const other = {
  "tab.server": "icons/player_off.svg", "tab.chat": "icons/player_chat.svg", "tab.close": "icons/tab_close_button.svg",
  "chat.emoticon": "icons/emoticon.svg", "chat.attach": "icons/upload.svg",
  "signal.1": "icons/ping_1.svg", "signal.2": "icons/ping_2.svg", "signal.3": "icons/ping_3.svg", "signal.4": "icons/ping_4.svg",
};
const item = (label, command, shortcut = "") => ({ label, command, shortcut });
const line = item("", "-");

// Everything but the colors, shared by the light and the dark skin.
const base = {
  layout: { radius: 3, widgetRadius: 2, gap: 3, rowHeight: 24, treeRow: 17, fontSize: 12, borders: true, chrome: true },
  images: { ...tree, ...action, ...other },
  menus: [
    { label: "Connections", items: [item("Connect…", "connect", "connect"), item("Disconnect", "disconnect", "disconnect"), item("File Transfers", "files", "files")] },
    { label: "Bookmarks", items: [item("Add to Bookmarks", "addbookmark"), line, item("", "bookmark-list")] },
    { label: "Self", items: [item("", "away", "away"), item("", "mic", "toggle_mic"), item("", "speakers", "toggle_sound")] },
    { label: "Permissions", items: [item("", "permissions")] },
    { label: "Tools", items: [
      item("Identities", "identities", "identities"), item("Contacts", "friends"), item("Collected URLs", "collected"), line,
      item("", "record"), line, item("", "market"), item("", "chat"), item("", "info"), line, item("Options", "settings", "settings"),
    ] },
  ],
};
const glyphs = ["🎤", "🔊", "⌨", "🖌", "👤", "🔑", "⚙", "🧩", "ℹ"];

App.theme.register("Classic TS3", {
  ...base,
  bg: "#f0f0f0",
  surface: "#ffffff",
  text: "#000000",
  textDim: "#6d6d6d",
  outline: "#d9d9d9",
  accent: "#3399ff",
  link: "#0066cc",
  talking: "#1e90ff",
  select: "#cce8ff",
  selectEdge: "#99d1ff",
  hover: "#e5f3ff",
  title: "#1c1c8c",
  rule: "#a0a0a0",
  settings: { glyphs, bannerTop: [0x86, 0xa4, 0xce], bannerBottom: [0xe4, 0xeb, 0xf5], bannerText: [0x1a, 0x1a, 0x1a], bannerGlyph: [0x2b, 0x3a, 0x55] },
});

// The same window in the greys of a dark Windows desktop, for night use.
App.theme.register("Dark Classic TS3", {
  ...base,
  bg: "#2d2d30",
  surface: "#1e1e1e",
  text: "#e8e8e8",
  textDim: "#9a9a9a",
  outline: "#3f3f46",
  accent: "#3399ff",
  link: "#6cb4ff",
  talking: "#4aa8ff",
  select: "#264f78",
  selectEdge: "#3a78b8",
  hover: "#2a3a4c",
  title: "#9cb8ff",
  rule: "#555555",
  settings: { glyphs, bannerTop: [0x2b, 0x3a, 0x55], bannerBottom: [0x2d, 0x2d, 0x30], bannerText: [0xe8, 0xe8, 0xe8], bannerGlyph: [0x9c, 0xb8, 0xff] },
});
