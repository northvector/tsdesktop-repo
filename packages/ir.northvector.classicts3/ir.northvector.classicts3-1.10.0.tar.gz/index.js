// The stock TeamSpeak 3 client skin, all of it here: colors, tight metrics, the pictures (SVGs in icons/,
// see THIRD_PARTY.md), the text menu bar and the Options-style settings page. The app only provides the
// generic parts.
const tree = {
  "tree.channel.green": "icons/channel_green.svg", "tree.channel.green.subscribed": "icons/channel_green_subscribed.svg",
  "tree.channel.yellow": "icons/channel_yellow.svg", "tree.channel.yellow.subscribed": "icons/channel_yellow_subscribed.svg",
  "tree.channel.red": "icons/channel_red.svg", "tree.channel.red.subscribed": "icons/channel_red_subscribed.svg",
  "tree.client": "icons/player_off.svg", "tree.client.talking": "icons/player_on.svg",
  "tree.client.commander": "icons/player_commander_off.svg", "tree.client.commander.talking": "icons/player_commander_on.svg",
  "tree.client.away": "icons/away.svg", "tree.client.input_muted": "icons/input_muted.svg",
  "tree.client.output_muted": "icons/output_muted.svg", "tree.client.query": "icons/server_query.svg",
};
const action = {
  "action.mic": "icons/capture.svg", "action.mic.muted": "icons/input_muted.svg",
  "action.speakers": "icons/volume.svg", "action.speakers.muted": "icons/output_muted.svg",
  "action.away": "icons/away.svg", "action.record": "icons/recording_start.svg", "action.record.on": "icons/recording_stop.svg",
  "action.permissions": "icons/permission_server_groups.svg", "action.collected": "icons/weblist.svg",
  "action.friends": "icons/edit_friend_foe_status.svg", "action.market": "icons/addon.svg",
  "action.chat": "icons/player_chat.svg", "action.info": "icons/info.svg", "action.settings": "icons/settings.svg",
};
const other = {
  "tab.server": "icons/player_off.svg", "tab.chat": "icons/player_chat.svg", "tab.close": "icons/tab_close_button.svg",
  "chat.emoticon": "icons/emoticon.svg", "chat.attach": "icons/upload.svg",
  "signal.1": "icons/ping_1.svg", "signal.2": "icons/ping_2.svg", "signal.3": "icons/ping_3.svg", "signal.4": "icons/ping_4.svg",
};
const item = (label, command, shortcut = "") => ({ label, command, shortcut });
const line = item("", "-");

// Everything but the colors, shared by every Classic TS3 skin.
const base = {
  layout: { radius: 3, widgetRadius: 2, gap: 3, rowHeight: 24, treeRow: 17, fontSize: 12, borders: true, chrome: true },
  images: { ...tree, ...action, ...other },
  menus: [
    { label: "Connections", items: [item("Connect…", "connect", "connect"), item("Disconnect", "disconnect", "disconnect"), item("File Transfers", "files", "files")] },
    { label: "Bookmarks", items: [item("Add to Bookmarks", "addbookmark"), line, item("", "bookmark-list")] },
    { label: "Self", items: [item("", "away", "away"), item("", "mic", "toggle_mic"), item("", "speakers", "toggle_sound")] },
    { label: "Permissions", items: [item("", "permissions")] },
    { label: "Tools", items: [
      item("Identities", "identities", "identities"), item("Contacts", "friends"), item("Collected URLs", "collected"), line,
      item("", "record"), line, item("", "chat"), item("", "info"), line, item("Options", "settings", "settings"),
    ] },
    { label: "Plugins", items: [item("", "plugin-list"), line, item("Marketplace…", "market")] },
  ],
};
const glyphs = ["🎤", "🔊", "⌨", "🖌", "👤", "🔑", "⚙", "🧩", "ℹ"];

App.theme.register("Classic TS3", {
  ...base,
  bg: "#f0f0f0",
  surface: "#ffffff",
  text: "#000000",
  textDim: "#6d6d6d",
  outline: "#d9d9d9",
  accent: "#3399ff",
  link: "#0066cc",
  talking: "#1e90ff",
  select: "#cce8ff",
  selectEdge: "#99d1ff",
  hover: "#e5f3ff",
  title: "#1c1c8c",
  rule: "#a0a0a0",
  settings: { glyphs, bannerTop: [0x86, 0xa4, 0xce], bannerBottom: [0xe4, 0xeb, 0xf5], bannerText: [0x1a, 0x1a, 0x1a], bannerGlyph: [0x2b, 0x3a, 0x55] },
});

// The same window in the greys of a dark Windows desktop, for night use.
App.theme.register("Dark Classic TS3", {
  ...base,
  bg: "#2d2d30",
  surface: "#1e1e1e",
  text: "#e8e8e8",
  textDim: "#9a9a9a",
  outline: "#3f3f46",
  accent: "#3399ff",
  link: "#6cb4ff",
  talking: "#4aa8ff",
  select: "#264f78",
  selectEdge: "#3a78b8",
  hover: "#2a3a4c",
  title: "#9cb8ff",
  rule: "#555555",
  settings: { glyphs, bannerTop: [0x2b, 0x3a, 0x55], bannerBottom: [0x2d, 0x2d, 0x30], bannerText: [0xe8, 0xe8, 0xe8], bannerGlyph: [0x9c, 0xb8, 0xff] },
});

// Keep the panels black on all three OLED skins; only the highlights change.
const oled = {
  ...base,
  bg: "#000000", surface: "#000000", surfaceHigh: "#000000", surfaceHighest: "#000000",
  text: "#e8e8e8", textDim: "#a0a0a0", outline: "#242424", rule: "#303030",
};
for (const [name, accent, link, select, selectEdge, hover, bannerGlyph] of [
  ["Blue", "#4a9eff", "#77b8ff", "#10243a", "#235480", "#0b1b2b", [0x4a, 0x9e, 0xff]],
  ["Green", "#43c779", "#70dda0", "#103021", "#276b45", "#0b2418", [0x43, 0xc7, 0x79]],
  ["Red", "#ed5656", "#ff8989", "#361717", "#823333", "#2b1010", [0xed, 0x56, 0x56]],
]) {
  App.theme.register(`${name} OLED Classic TS3`, {
    ...oled, accent, link, talking: accent, select, selectEdge, hover, title: accent,
    settings: { glyphs, bannerTop: [0x0a, 0x0a, 0x0a], bannerBottom: [0x00, 0x00, 0x00], bannerText: [0xe8, 0xe8, 0xe8], bannerGlyph },
  });
}

// Imported pictures live in the plugin's private data directory, not in the shipped files.
const backgroundTheme = "Custom Background Classic TS3";
const store = App.storage;
let background = store.get("background", "");
if (typeof background !== "string" || !/^user:[a-zA-Z0-9_-][a-zA-Z0-9._-]*\.(png|jpe?g|webp)$/.test(background)) background = "";
let glass = store.get("glass", 0.55);
if (!Number.isFinite(glass) || glass < 0 || glass > 1) glass = 0.55;
let blur = store.get("blur", 12);
if (!Number.isFinite(blur) || blur < 0 || blur > 32) blur = 12;
const backgroundColors = { bg: "#20232a", surface: "#22262e", text: "#f2f2f2", accent: "#65aaff" };
const backgroundActive = () => {
  const current = App.theme.current();
  return current.bg.toLowerCase() === backgroundColors.bg && current.accent.toLowerCase() === backgroundColors.accent;
};
const registerBackground = () => App.theme.register(backgroundTheme, {
  ...base, ...backgroundColors,
  textDim: "#b4bac3", outline: "#454b55", link: "#86c3ff", talking: "#65aaff",
  select: "#294765", selectEdge: "#4585bb", hover: "#293542", title: "#b5d7ff", rule: "#626b76",
  layout: { ...base.layout, glass, glassBlur: blur },
  images: { ...base.images, ...(background ? { "app.background": background } : {}) },
  settings: { glyphs, bannerTop: [0x2b, 0x3a, 0x55], bannerBottom: [0x20, 0x23, 0x2a], bannerText: [0xe8, 0xe8, 0xe8], bannerGlyph: [0x65, 0xaa, 0xff] },
});
registerBackground();

App.ui.registerSettings(() => [
  { type: "heading", text: "Classic TS3 background" },
  { type: "label", text: "Choose Custom Background Classic TS3 in Appearance to see your picture. It stays private to this device.", small: true, color: "dim" },
  background && { type: "label", text: `Background: ${background.slice(5)}` },
  { type: "button", label: background ? "Change background…" : "Add background…", onClick: () => {
    try {
      const added = App.theme.importBackground();
      if (!added.length) return;
       const wasActive = backgroundActive();
      background = added[0];
      store.set("background", background);
      registerBackground();
      if (wasActive) App.theme.apply(backgroundTheme);
    } catch (e) {
      App.ui.notify(String(e), "error");
    }
   } },
  { type: "slider", label: "Glass opacity", value: Math.round(glass * 100), min: 0, max: 100, step: 5, suffix: "%", onChange: (value) => {
    glass = value / 100;
    store.set("glass", glass);
    registerBackground();
    if (backgroundActive()) App.theme.apply(backgroundTheme);
  } },
  { type: "slider", label: "Background blur", value: blur, min: 0, max: 32, step: 1, suffix: " px", onChange: (value) => {
    blur = value;
    store.set("blur", blur);
    registerBackground();
    if (backgroundActive()) App.theme.apply(backgroundTheme);
  } },
  background && { type: "button", label: "Clear background", onClick: () => {
    const wasActive = backgroundActive();
    background = "";
    store.remove("background");
    registerBackground();
    if (wasActive) App.theme.apply(backgroundTheme);
  } },
]);
