// @ts-check
/// <reference path="../../app.d.ts" />
// Polls over App.p2p. The asker's plugin is the ballot box: it sends the poll to everyone asked, keeps one
// vote per person (by TeamSpeak uid), and sends the totals back after every vote. Voters only talk to the asker.
// Messages: {t:"poll", id, question, options, counts, closed} and {t:"results", id, counts, closed} from the
// asker; {t:"vote", id, choice} to it. Everything that comes in is checked: it is another person's data.

const MAX_Q = 300;
const MAX_OPT = 100;
const MAX_OPTS = 10;

/**
 * By `connection:clientId`. `session`: ours (waiting or open); `request`: theirs, waiting for the user.
 * @type {Map<string, { key: string; uid: string; name: string; connection: number; clientId: number; session: string | null; request: string | null; open: boolean; outbox: string[] }>}
 */
const peers = new Map();
/**
 * Ours by our id; theirs by `<their key>/<their id>`. `host` is null for ours, else the asker's key.
 * Only ours have `votes` (uid → option) and `to` (keys asked).
 * @typedef {{ id: string; remoteId: string; question: string; options: string[]; counts: number[]; closed: boolean; gone: boolean; host: string | null; hostName: string; created: number; myVote: number; votes: Map<string, number>; to: Set<string> }} Poll
 * @type {Map<string, Poll>}
 */
const polls = new Map();
/** @type {{ uid: string; name: string }[]} */
let trusted = App.storage.get("trusted", []);
const form = { question: "", options: "", channelOnly: true };
let note = "";

// Starting P2P now lets others find us before the panel is opened.
App.p2p.peers();

const keyOf = (connection, clientId) => `${connection}:${clientId}`;
const peer = (connection, clientId, uid, name) => {
  const key = keyOf(connection, clientId);
  let p = peers.get(key);
  if (!p) peers.set(key, (p = { key, uid, name, connection, clientId, session: null, request: null, open: false, outbox: [] }));
  if (name) p.name = name;
  if (uid) p.uid = uid;
  return p;
};
const bySession = (session) => [...peers.values()].find((p) => p.session === session || p.request === session);
const isTrusted = (uid) => trusted.some((t) => t.uid === uid);
const hhmm = (t) => new Date(t).toTimeString().slice(0, 5);

// ---- sending ----

const flush = (p) => {
  while (p.open && p.outbox.length) {
    try {
      App.p2p.send(/** @type {string} */ (p.session), p.outbox[0]);
    } catch (e) {
      if (String(e.message).startsWith("busy")) setTimeout(() => flush(p), 1000);
      else App.log(`not sent to ${p.name}: ${e.message}`), p.outbox.shift();
      return;
    }
    p.outbox.shift();
  }
};
const send = (p, msg) => {
  p.outbox.push(JSON.stringify(msg));
  if (!p.session && !p.request) {
    try {
      p.session = App.p2p.connect(p.connection, p.clientId);
    } catch (e) {
      p.outbox = [];
      note = `Can't reach ${p.name}: ${e.message}`;
      return;
    }
  } else if (!p.session && p.request && isTrusted(p.uid)) accept(p);
  flush(p);
};

const recount = (poll) => {
  poll.counts = poll.options.map(() => 0);
  for (const v of poll.votes.values()) poll.counts[v]++;
};
const broadcast = (poll) => {
  for (const k of poll.to) {
    const p = peers.get(k);
    if (p) send(p, { t: "results", id: poll.id, counts: poll.counts, closed: poll.closed });
  }
};

// ---- sessions ----

const accept = (p) => {
  // Both asked at once: theirs wins, ours goes (what waited in its outbox goes over theirs).
  if (p.session && p.session !== p.request) App.p2p.close(p.session);
  p.session = p.request;
  p.request = null;
  p.open = false;
  App.p2p.accept(/** @type {string} */ (p.session));
};
const decline = (p) => {
  App.p2p.close(/** @type {string} */ (p.request));
  p.request = null;
  if (!p.session) p.outbox = [];
};

App.events.on("p2p.request", (r) => {
  const p = peer(r.connection, r.clientId, r.uid, r.name);
  p.request = r.session;
  if (isTrusted(r.uid)) return accept(p);
  App.ui.notify(`${r.name} wants to send you polls`);
  App.ui.open("main");
});
App.events.on("p2p.open", ({ session }) => {
  const p = bySession(session);
  if (!p || p.session !== session) return;
  p.open = true;
  flush(p);
});
App.events.on("p2p.closed", ({ session, reason }) => {
  const p = bySession(session);
  if (!p) return;
  if (p.request === session) p.request = null;
  if (p.session !== session) return;
  p.session = null;
  p.open = false;
  if (p.outbox.length) note = `${p.name} is gone${reason ? ` (${reason})` : ""}; ${p.outbox.length} message(s) not sent.`;
  p.outbox = [];
  for (const poll of polls.values()) if (poll.host === p.key && !poll.closed) poll.gone = true;
});

// ---- messages ----

const text = (v, max) => (typeof v === "string" && v.trim() && v.length <= max ? v : null);
const counts = (v, n) => (Array.isArray(v) && v.length === n && v.every((c) => Number.isInteger(c) && c >= 0) ? v : null);

App.events.on("p2p.message", ({ session, data }) => {
  const p = bySession(session);
  if (!p || p.session !== session) return;
  let m;
  try {
    m = JSON.parse(data);
  } catch {
    return;
  }
  const id = text(m?.id, 40);
  if (!id) return;

  if (m.t === "vote") {
    const poll = polls.get(id);
    if (!poll || poll.host !== null || poll.closed || !poll.to.has(p.key)) return;
    if (!Number.isInteger(m.choice) || m.choice < 0 || m.choice >= poll.options.length) return;
    poll.votes.set(p.uid, m.choice);
    recount(poll);
    broadcast(poll);
    return;
  }

  const local = `${p.key}/${id}`;
  if (m.t === "poll") {
    const question = text(m.question, MAX_Q);
    const options = Array.isArray(m.options) && m.options.length >= 2 && m.options.length <= MAX_OPTS ? m.options.map((o) => text(o, MAX_OPT)) : null;
    if (!question || !options || options.includes(null)) return;
    const c = counts(m.counts, options.length);
    if (!c) return;
    const known = polls.get(local);
    polls.set(local, {
      id: local, remoteId: id, question, options, counts: c, closed: !!m.closed, gone: false,
      host: p.key, hostName: p.name, created: known?.created ?? Date.now(), myVote: known?.myVote ?? -1, votes: new Map(), to: new Set(),
    });
    if (!known) {
      App.ui.notify(`${p.name} asks: ${question}`);
      App.ui.open("main");
    }
  } else if (m.t === "results") {
    const poll = polls.get(local);
    const c = poll && counts(m.counts, poll.options.length);
    if (!poll || !c) return;
    poll.counts = c;
    poll.closed = !!m.closed;
    poll.gone = false;
  }
});

// ---- actions ----

const targets = () => {
  const st = App.app.state();
  return App.p2p.peers().filter((x) => {
    if (!form.channelOnly) return true;
    const conn = st.connections.find((c) => c.id === x.connection);
    return !!conn && conn.clients.find((c) => c.id === x.clientId)?.channelId === conn.channelId;
  });
};

const ask = () => {
  const question = form.question.trim().slice(0, MAX_Q);
  const options = [...new Set(form.options.split("\n").map((o) => o.trim().slice(0, MAX_OPT)).filter(Boolean))].slice(0, MAX_OPTS);
  if (!question) return void (note = "Write a question first.");
  if (options.length < 2) return void (note = "Give at least two answers, one per line.");
  const who = targets();
  if (!who.length) return void (note = form.channelOnly ? "Nobody in your channel runs Polls." : "Nobody on your servers runs Polls.");
  const id = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  /** @type {Poll} */
  const poll = { id, remoteId: id, question, options, counts: options.map(() => 0), closed: false, gone: false, host: null, hostName: "You", created: Date.now(), myVote: -1, votes: new Map(), to: new Set() };
  polls.set(id, poll);
  for (const x of who) {
    const p = peer(x.connection, x.clientId, x.uid, x.name);
    poll.to.add(p.key);
    send(p, { t: "poll", id, question, options, counts: poll.counts, closed: false });
  }
  form.question = form.options = "";
  note = `Asked ${who.length} ${who.length === 1 ? "person" : "people"}.`;
};

const vote = (poll, i) => {
  poll.myVote = i;
  if (poll.host === null) {
    poll.votes.set("", i); // our own vote; uids are never empty
    recount(poll);
    broadcast(poll);
  } else {
    const p = peers.get(poll.host);
    if (p) send(p, { t: "vote", id: poll.remoteId, choice: i });
  }
};

const close = (poll) => {
  poll.closed = true;
  broadcast(poll);
};

const trust = (p) => {
  if (!isTrusted(p.uid)) App.storage.set("trusted", (trusted = [...trusted, { uid: p.uid, name: p.name }]));
  accept(p);
};

// ---- view ----

const pollView = (poll) => {
  const total = poll.counts.reduce((a, b) => a + b, 0);
  const mine = poll.host === null;
  const open = !poll.closed && !poll.gone;
  const state = poll.closed ? " · closed" : poll.gone ? " · the asker left" : "";
  const waiting = mine && open ? [...poll.to].map((k) => peers.get(k)).filter((p) => p && !poll.votes.has(p.uid)) : [];
  return {
    type: "group",
    children: [
      { type: "label", text: poll.question, strong: true },
      { type: "label", text: `${mine ? "You asked" : `${poll.hostName} asks`} at ${hhmm(poll.created)} · ${total} vote${total === 1 ? "" : "s"}${state}`, small: true, color: "dim" },
      ...poll.options.map((o, i) => ({
        type: "row",
        children: [
          { type: "button", label: o, width: 170, selected: poll.myVote === i, enabled: open, tooltip: open ? "Vote for this" : undefined, onClick: () => vote(poll, i) },
          { type: "progress", value: total ? poll.counts[i] / total : 0, text: `${poll.counts[i]}` },
        ],
      })),
      waiting.length > 0 && { type: "label", text: `Waiting for ${waiting.map((p) => (p.open ? p.name : `${p.name} (not connected)`)).join(", ")}`, small: true, color: "faint" },
      {
        type: "row",
        children: [
          mine && open && { type: "button", label: "Close poll", onClick: () => close(poll) },
          !open && { type: "button", label: "Remove", onClick: () => polls.delete(poll.id) },
        ],
      },
    ],
  };
};

const requestView = (p) => ({
  type: "group",
  children: [
    `${p.name} wants to send you polls. Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`,
    {
      type: "row",
      children: [
        { type: "button", label: "Accept", variant: "filled", onClick: () => accept(p) },
        { type: "button", label: "Always accept", tooltip: `Accept ${p.name} without asking from now on`, onClick: () => trust(p) },
        { type: "button", label: "Decline", onClick: () => decline(p) },
      ],
    },
  ],
});

App.ui.registerPanel({
  id: "main",
  title: "Polls",
  width: 480,
  height: 600,
  render: () => {
    const who = targets().length;
    const list = [...polls.values()].sort((a, b) => b.created - a.created);
    return [
      ...[...peers.values()].filter((p) => p.request && !p.open).map(requestView),
      {
        type: "collapsing",
        title: "New poll",
        children: [
          { type: "input", value: form.question, hint: "Question", width: 420, onChange: (v) => (form.question = v) },
          { type: "input", value: form.options, hint: "Answers, one per line", multiline: true, width: 420, onChange: (v) => (form.options = v) },
          { type: "checkbox", label: "Only people in my channel", checked: form.channelOnly, onChange: (v) => (form.channelOnly = v) },
          {
            type: "row",
            children: [
              { type: "button", label: "Ask", variant: "filled", enabled: who > 0, onClick: ask },
              { type: "label", text: who ? `${who} ${who === 1 ? "person runs" : "people run"} Polls` : "Nobody here runs Polls yet", small: true, color: "dim" },
            ],
          },
        ],
      },
      note && { type: "label", text: note, small: true, color: "dim" },
      { type: "scroll", spacing: 8, children: list.length ? list.map(pollView) : [{ type: "label", text: "No polls yet.", color: "faint" }] },
    ];
  },
});

App.ui.registerSettings(() => [
  { type: "label", text: "People whose polls are accepted without asking:" },
  ...(trusted.length
    ? trusted.map((t) => ({
        type: "row",
        children: [t.name, { type: "button", label: "Remove", onClick: () => App.storage.set("trusted", (trusted = trusted.filter((x) => x.uid !== t.uid))) }],
      }))
    : [{ type: "label", text: "Nobody yet.", color: "faint" }]),
]);

App.ui.registerMenu({ id: "main", label: "Polls", icon: "📊", onClick: () => App.ui.toggle("main") });
