// @ts-check
/// <reference path="../../app.d.ts" />
// Tic-tac-toe over App.p2p, one game per opponent. Whoever starts a game plays X and moves first.
// Messages: {t:"new"} (sender is X, a fresh board) and {t:"move", cell: 0-8}. Both sides keep the board
// and check every incoming move: it is another person's data.
// Spectators: a player invites someone to watch over a session of its own and sends them {t:"watch", x, o, board,
// turn, note} after every change; the watcher only draws it. Leaving a game in progress forfeits it.

const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
/** "X", "O", "draw", or null while the game goes on. */
const winner = (b) => {
  for (const [a, c, d] of LINES) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  return b.every(Boolean) ? "draw" : null;
};
if (winner(["X", "X", "X", "", "", "", "", "", ""]) !== "X" || winner(["X", "O", "X", "X", "O", "O", "O", "X", "X"]) !== "draw") App.log("XO: winner() is broken");

/**
 * By `connection:clientId`. `session`: the open or pending one; `request`: theirs, waiting for the user.
 * `watch`: the game this peer invited me to watch, as they last sent it. `confirm`: asking before leaving; `inviting`: the watch invite list is open.
 * @type {Map<string, { key: string; name: string; connection: number; clientId: number; session: string | null; request: string | null; open: boolean; outbox: string[]; board: string[]; me: "X" | "O"; turn: "X" | "O"; playing: boolean; missing: boolean; note: string; watch: null | { x: string; o: string; board: string[]; turn: string; note: string }; confirm: boolean; inviting?: boolean }>}
 */
const games = new Map();
/** People I invited to watch one of my games, by session. `game`: that game's key. */
const watchers = new Map();
App.p2p.peers(); // start P2P now so others can find us before the panel opens
const myName = () => {
  const st = App.app.state();
  const c = st.connections.find((c) => c.id === st.active) || st.connections[0];
  return c?.clients.find((x) => x.id === c.ownClientId)?.name || "Me";
};

const game = (connection, clientId, name) => {
  const key = `${connection}:${clientId}`;
  let g = games.get(key);
  if (!g) games.set(key, (g = { key, name, connection, clientId, session: null, request: null, open: false, outbox: [], board: Array(9).fill(""), me: "X", turn: "X", playing: false, missing: false, note: "", watch: null, confirm: false }));
  if (name) g.name = name;
  return g;
};
const bySession = (s) => [...games.values()].find((g) => g.session === s || g.request === s);

const flush = (g) => {
  while (g.open && g.outbox.length) {
    try {
      App.p2p.send(/** @type {string} */ (g.session), g.outbox[0]);
    } catch (e) {
      if (String(e.message).startsWith("busy")) setTimeout(() => flush(g), 1000);
      else (g.note = `Not sent: ${e.message}`), g.outbox.shift();
      return;
    }
    g.outbox.shift();
  }
};
const send = (g, msg) => {
  g.outbox.push(JSON.stringify(msg));
  if (!g.session && !g.request) {
    try {
      g.session = App.p2p.connect(g.connection, g.clientId);
    } catch (e) {
      g.outbox = [];
      g.note = `Can't reach ${g.name}: ${e.message}`;
      return;
    }
  }
  flush(g);
};

const reset = (g, me) => Object.assign(g, { board: Array(9).fill(""), me, turn: "X", playing: true, missing: false, note: "", watch: null, confirm: false });
const start = (g) => {
  reset(g, "X");
  send(g, { t: "new" });
  tell(g);
};
const play = (g, i) => {
  if (!g.playing || g.turn !== g.me || g.board[i] || winner(g.board)) return;
  g.board[i] = g.me;
  g.turn = g.me === "X" ? "O" : "X";
  send(g, { t: "move", cell: i });
  tell(g);
};

// ---- spectators ----

/** The game as its watchers see it, to each open one. */
const tell = (g) => {
  const [x, o] = g.me === "X" ? [myName(), g.name] : [g.name, myName()];
  const msg = JSON.stringify({ t: "watch", x, o, board: g.board, turn: g.turn, note: g.playing ? "" : g.note || "The game ended." });
  for (const [session, w] of watchers)
    if (w.game === g.key && w.open)
      try {
        App.p2p.send(session, msg);
      } catch (e) {
        App.log(`XO: not sent to a watcher: ${e.message}`);
      }
};
const inviteWatcher = (g, peer) => {
  try {
    watchers.set(App.p2p.connect(peer.connection, peer.clientId), { name: peer.name, key: `${peer.connection}:${peer.clientId}`, game: g.key, open: false });
  } catch (e) {
    g.note = `Can't reach ${peer.name}: ${e.message}`;
  }
};
const validWatch = (m) => typeof m.x === "string" && typeof m.o === "string" && typeof m.note === "string" && (m.turn === "X" || m.turn === "O") && Array.isArray(m.board) && m.board.length === 9 && m.board.every((c) => c === "" || c === "X" || c === "O");

// ---- sessions ----

const accept = (g) => {
  if (g.session && g.session !== g.request) App.p2p.close(g.session); // both asked at once: theirs wins
  g.session = g.request;
  g.request = null;
  g.open = false;
  App.p2p.accept(/** @type {string} */ (g.session));
};
const decline = (g) => {
  App.p2p.close(/** @type {string} */ (g.request));
  g.request = null;
};

// The invite chime, on your own speakers only.
const invited = () => {
  try {
    App.audio.play("sounds/invite.wav", { volume: 0.6, mic: false });
  } catch (e) {
    App.log(`XO: no sound: ${e.message}`);
  }
};
App.events.on("p2p.request", (r) => {
  game(r.connection, r.clientId, r.name).request = r.session;
  App.ui.notify(`${r.name} invites you to XO`);
  invited();
  App.ui.open("main");
});
App.events.on("p2p.open", ({ session }) => {
  const w = watchers.get(session);
  if (w) {
    w.open = true;
    const g = games.get(w.game);
    if (g) tell(g);
    return;
  }
  const g = bySession(session);
  if (!g || g.session !== session) return;
  g.open = true;
  flush(g);
});
App.events.on("p2p.closed", ({ session, reason }) => {
  if (watchers.delete(session)) return;
  const g = bySession(session);
  if (!g) return;
  if (g.request === session) g.request = null;
  if (g.session !== session) return;
  const wasOpen = g.open;
  Object.assign(g, { session: null, open: false, outbox: [] });
  // The app answers this way when their side doesn't run XO: the peer list holds every app user, not only XO players.
  if (reason && reason.includes("plugin running")) return void Object.assign(g, { playing: false, missing: true, note: `${g.name} doesn't have XO installed and enabled. Ask them to get it from the Marketplace.` });
  if (g.watch) return void Object.assign(g, { watch: null, note: "The game you were watching ended." });
  if (g.playing && !winner(g.board)) (g.playing = false), (g.note = wasOpen ? `${g.name} left the game: you win by forfeit.` : `Couldn't connect to ${g.name}${reason ? ` (${reason})` : ""}.`), tell(g);
});
App.events.on("p2p.message", ({ session, data }) => {
  const g = bySession(session);
  if (!g || g.session !== session) return;
  let m;
  try {
    m = JSON.parse(data);
  } catch {
    return;
  }
  if (m?.t === "watch" && validWatch(m) && !g.playing) {
    if (!g.watch) App.ui.notify(`Watching ${m.x} and ${m.o} play XO`);
    g.watch = { x: m.x, o: m.o, board: m.board, turn: m.turn, note: m.note };
  } else if (m?.t === "new") {
    reset(g, "O");
    App.ui.notify(`${g.name} started an XO game`);
    App.ui.open("main");
    tell(g);
  } else if (m?.t === "move") {
    const them = g.me === "X" ? "O" : "X";
    const i = m.cell;
    if (!g.playing || g.turn !== them || !Number.isInteger(i) || i < 0 || i > 8 || g.board[i] || winner(g.board)) return;
    g.board[i] = them;
    g.turn = g.me;
    tell(g);
  }
});

// ---- view ----

const status = (g) => {
  const w = winner(g.board);
  if (w === "draw") return "Draw.";
  if (w) return w === g.me ? "You won!" : `${g.name} won.`;
  return g.turn === g.me ? `Your turn (${g.me})` : `${g.name}'s turn`;
};

// Nobody plays until the session is open: before that, moves would only queue up.
const connectingView = (g) => {
  const waiting = App.p2p.sessions().find((x) => x.id === g.session)?.status === "waiting";
  return {
    type: "group",
    children: [
      { type: "label", text: `vs ${g.name}`, strong: true },
      { type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text: waiting ? `Waiting for ${g.name} to accept...` : `Connecting to ${g.name}...`, small: true, color: "dim" }] },
      { type: "button", label: "Cancel", onClick: () => cancel(g) },
    ],
  };
};
const cancel = (g) => {
  if (g.session) App.p2p.close(g.session);
  const forfeit = g.playing && !winner(g.board);
  Object.assign(g, { session: null, open: false, outbox: [], playing: false, watch: null, confirm: false, note: forfeit ? `You left the game: ${g.name} wins.` : "" });
  if (forfeit) tell(g);
};

/** A read-only board: a game someone invited you to watch. */
const watchView = (g) => {
  const w = g.watch;
  const won = winner(w.board);
  const cell = (i) => ({ type: "button", label: w.board[i] || " ", width: 56, height: 56, size: 28, color: w.board[i] === "X" ? "#e5534b" : w.board[i] === "O" ? "#4c8eda" : undefined, enabled: false });
  return {
    type: "group",
    children: [
      { type: "label", text: `👁 ${w.x} (X) vs ${w.o} (O)`, strong: true },
      { type: "label", text: w.note || (won === "draw" ? "Draw." : won ? `${won === "X" ? w.x : w.o} won.` : `${w.turn === "X" ? w.x : w.o}'s turn`), small: true, color: "dim" },
      { type: "column", spacing: 4, children: [0, 3, 6].map((r) => ({ type: "row", children: [r, r + 1, r + 2].map(cell) })) },
      { type: "button", label: "Stop watching", onClick: () => cancel(g) },
    ],
  };
};
/** Under a game you play: who's watching, and people to invite to watch. */
const watchersView = (g) => {
  const mine = [...watchers].filter(([, w]) => w.game === g.key);
  const asked = new Set(mine.map(([, w]) => w.key));
  const peers = App.p2p.peers().filter((p) => `${p.connection}:${p.clientId}` !== g.key && !asked.has(`${p.connection}:${p.clientId}`));
  return {
    type: "column",
    spacing: 2,
    children: [
      ...mine.map(([session, w]) => ({ type: "bar", left: { type: "label", text: w.open ? `👁 ${w.name}` : `Asking ${w.name} to watch...`, small: true }, right: { type: "button", label: "Remove", onClick: () => (App.p2p.close(session), watchers.delete(session)) } })),
      ...peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name, small: true }, right: { type: "button", label: "Invite to watch", enabled: mine.length < 6, onClick: () => inviteWatcher(g, p) } })),
      !mine.length && !peers.length && { type: "label", text: "Nobody else to invite.", small: true, color: "faint" },
    ],
  };
};

const gameView = (g) => {
  if (g.session && !g.open) return connectingView(g);
  if (g.watch && g.open) return watchView(g);
  const over = !!winner(g.board);
  const live = g.playing && !over && g.open;
  const watching = [...watchers.values()].filter((w) => w.game === g.key && w.open).length;
  const cell = (i) => ({
    type: "button", label: g.board[i] || " ", width: 56, height: 56, size: 28,
    color: g.board[i] === "X" ? "#e5534b" : g.board[i] === "O" ? "#4c8eda" : undefined,
    enabled: g.playing && !over && !g.board[i] && g.turn === g.me,
    onClick: () => play(g, i),
  });
  return {
    type: "group",
    children: [
      { type: "label", text: `vs ${g.name}`, strong: true },
      g.playing && { type: "label", text: status(g), small: true, color: "dim" },
      g.playing && { type: "column", spacing: 4, children: [0, 3, 6].map((r) => ({ type: "row", children: [r, r + 1, r + 2].map(cell) })) },
      g.note && { type: "label", text: g.note, small: true, color: "dim" },
      watching > 0 && { type: "label", text: `👁 ${watching} watching`, small: true, color: "dim" },
      {
        type: "row",
        children: [
          (!g.playing || over) && { type: "button", label: g.playing ? "Rematch" : g.missing ? "Try again" : "Invite", variant: "filled", onClick: () => start(g) },
          // Leaving a game in progress forfeits it, so it asks first.
          live && (g.confirm ? { type: "button", label: "Forfeit and leave", variant: "filled", onClick: () => cancel(g) } : { type: "button", label: "Leave game", onClick: () => (g.confirm = true) }),
          live && g.confirm && { type: "button", label: "Stay", onClick: () => (g.confirm = false) },
          g.playing && g.open && { type: "button", label: "👁", selected: !!g.inviting, tooltip: "Invite someone to watch this game", onClick: () => (g.inviting = !g.inviting) },
        ],
      },
      g.playing && g.open && g.inviting && watchersView(g),
    ],
  };
};

const requestView = (g) => ({
  type: "group",
  children: [
    `${g.name} invites you to play or watch XO. Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`,
    {
      type: "row",
      children: [
        { type: "button", label: "Accept", variant: "filled", onClick: () => accept(g) },
        { type: "button", label: "Decline", onClick: () => decline(g) },
      ],
    },
  ],
});

App.ui.registerPanel({
  id: "main",
  title: "XO",
  width: 360,
  height: 560,
  render: () => {
    for (const x of App.p2p.peers()) game(x.connection, x.clientId, x.name);
    const list = [...games.values()].sort((a, b) => +a.missing - +b.missing);
    return [
      ...list.filter((g) => g.request && !g.open).map(requestView),
      {
        type: "scroll",
        spacing: 8,
        children: list.length ? list.map(gameView) : [{ type: "label", text: "Nobody on your servers runs XO yet.", color: "faint" }],
      },
    ];
  },
});

App.ui.registerMenu({ id: "main", label: "XO", icon: "⭕", onClick: () => App.ui.toggle("main") });
