// @ts-check
/// <reference path="../../app.d.ts" />
// Tic-tac-toe over App.p2p, one game per opponent. Whoever starts a game plays X and moves first.
// Messages: {t:"new"} (sender is X, a fresh board) and {t:"move", cell: 0-8}. Both sides keep the board
// and check every incoming move: it is another person's data.

const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
/** "X", "O", "draw", or null while the game goes on. */
const winner = (b) => {
  for (const [a, c, d] of LINES) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  return b.every(Boolean) ? "draw" : null;
};
if (winner(["X", "X", "X", "", "", "", "", "", ""]) !== "X" || winner(["X", "O", "X", "X", "O", "O", "O", "X", "X"]) !== "draw") App.log("XO: winner() is broken");

/**
 * By `connection:clientId`. `session`: the open or pending one; `request`: theirs, waiting for the user.
 * @type {Map<string, { key: string; name: string; connection: number; clientId: number; session: string | null; request: string | null; open: boolean; outbox: string[]; board: string[]; me: "X" | "O"; turn: "X" | "O"; playing: boolean; note: string }>}
 */
const games = new Map();
App.p2p.peers(); // start P2P now so others can find us before the panel opens

const game = (connection, clientId, name) => {
  const key = `${connection}:${clientId}`;
  let g = games.get(key);
  if (!g) games.set(key, (g = { key, name, connection, clientId, session: null, request: null, open: false, outbox: [], board: Array(9).fill(""), me: "X", turn: "X", playing: false, note: "" }));
  if (name) g.name = name;
  return g;
};
const bySession = (s) => [...games.values()].find((g) => g.session === s || g.request === s);

const flush = (g) => {
  while (g.open && g.outbox.length) {
    try {
      App.p2p.send(/** @type {string} */ (g.session), g.outbox[0]);
    } catch (e) {
      if (String(e.message).startsWith("busy")) setTimeout(() => flush(g), 1000);
      else (g.note = `Not sent: ${e.message}`), g.outbox.shift();
      return;
    }
    g.outbox.shift();
  }
};
const send = (g, msg) => {
  g.outbox.push(JSON.stringify(msg));
  if (!g.session && !g.request) {
    try {
      g.session = App.p2p.connect(g.connection, g.clientId);
    } catch (e) {
      g.outbox = [];
      g.note = `Can't reach ${g.name}: ${e.message}`;
      return;
    }
  }
  flush(g);
};

const reset = (g, me) => Object.assign(g, { board: Array(9).fill(""), me, turn: "X", playing: true, note: "" });
const start = (g) => {
  reset(g, "X");
  send(g, { t: "new" });
};
const play = (g, i) => {
  if (!g.playing || g.turn !== g.me || g.board[i] || winner(g.board)) return;
  g.board[i] = g.me;
  g.turn = g.me === "X" ? "O" : "X";
  send(g, { t: "move", cell: i });
};

// ---- sessions ----

const accept = (g) => {
  if (g.session && g.session !== g.request) App.p2p.close(g.session); // both asked at once: theirs wins
  g.session = g.request;
  g.request = null;
  g.open = false;
  App.p2p.accept(/** @type {string} */ (g.session));
};
const decline = (g) => {
  App.p2p.close(/** @type {string} */ (g.request));
  g.request = null;
};

App.events.on("p2p.request", (r) => {
  game(r.connection, r.clientId, r.name).request = r.session;
  App.ui.notify(`${r.name} wants to play XO`);
  App.ui.open("main");
});
App.events.on("p2p.open", ({ session }) => {
  const g = bySession(session);
  if (!g || g.session !== session) return;
  g.open = true;
  flush(g);
});
App.events.on("p2p.closed", ({ session, reason }) => {
  const g = bySession(session);
  if (!g) return;
  if (g.request === session) g.request = null;
  if (g.session !== session) return;
  Object.assign(g, { session: null, open: false, outbox: [] });
  if (g.playing && !winner(g.board)) (g.playing = false), (g.note = `${g.name} left${reason ? ` (${reason})` : ""}.`);
});
App.events.on("p2p.message", ({ session, data }) => {
  const g = bySession(session);
  if (!g || g.session !== session) return;
  let m;
  try {
    m = JSON.parse(data);
  } catch {
    return;
  }
  if (m?.t === "new") {
    reset(g, "O");
    App.ui.notify(`${g.name} started an XO game`);
    App.ui.open("main");
  } else if (m?.t === "move") {
    const them = g.me === "X" ? "O" : "X";
    const i = m.cell;
    if (!g.playing || g.turn !== them || !Number.isInteger(i) || i < 0 || i > 8 || g.board[i] || winner(g.board)) return;
    g.board[i] = them;
    g.turn = g.me;
  }
});

// ---- view ----

const status = (g) => {
  const w = winner(g.board);
  if (w === "draw") return "Draw.";
  if (w) return w === g.me ? "You won!" : `${g.name} won.`;
  return g.turn === g.me ? `Your turn (${g.me})` : `${g.name}'s turn`;
};

const gameView = (g) => {
  const over = !!winner(g.board);
  const cell = (i) => ({
    type: "button", label: g.board[i] || " ", width: 56, height: 56, size: 28,
    color: g.board[i] === "X" ? "#e5534b" : g.board[i] === "O" ? "#4c8eda" : undefined,
    enabled: g.playing && !over && !g.board[i] && g.turn === g.me,
    onClick: () => play(g, i),
  });
  return {
    type: "group",
    children: [
      { type: "label", text: `vs ${g.name}`, strong: true },
      g.playing && { type: "label", text: status(g), small: true, color: "dim" },
      g.playing && { type: "column", spacing: 4, children: [0, 3, 6].map((r) => ({ type: "row", children: [r, r + 1, r + 2].map(cell) })) },
      g.note && { type: "label", text: g.note, small: true, color: "dim" },
      (!g.playing || over) && { type: "button", label: g.playing ? "Rematch" : "Start game", variant: "filled", onClick: () => start(g) },
    ],
  };
};

const requestView = (g) => ({
  type: "group",
  children: [
    `${g.name} wants to play XO. Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`,
    {
      type: "row",
      children: [
        { type: "button", label: "Accept", variant: "filled", onClick: () => accept(g) },
        { type: "button", label: "Decline", onClick: () => decline(g) },
      ],
    },
  ],
});

App.ui.registerPanel({
  id: "main",
  title: "XO",
  width: 360,
  height: 560,
  render: () => {
    for (const x of App.p2p.peers()) game(x.connection, x.clientId, x.name);
    const list = [...games.values()];
    return [
      ...list.filter((g) => g.request && !g.open).map(requestView),
      {
        type: "scroll",
        spacing: 8,
        children: list.length ? list.map(gameView) : [{ type: "label", text: "Nobody on your servers runs XO yet.", color: "faint" }],
      },
    ];
  },
});

App.ui.registerMenu({ id: "main", label: "XO", icon: "⭕", onClick: () => App.ui.toggle("main") });
