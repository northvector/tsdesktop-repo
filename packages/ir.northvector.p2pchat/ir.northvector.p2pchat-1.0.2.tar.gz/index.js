// Private chat with other TeamSpeak Desktop users over App.p2p. Messages go straight between you over an
// encrypted WebRTC channel (directly, or through a TURN relay that only sees ciphertext); when neither
// connects, they go through the TeamSpeak server and the chat says so. Nothing is kept after closing the app.

// By `connection:clientId`: the person, the session with them, the lines, what waits for the session to open.
const chats = new Map();
// Starting P2P right away lets others find us before the panel is ever opened.
App.p2p.peers();
let current = null;
let draft = "";

const keyOf = (connection, clientId) => `${connection}:${clientId}`;
const chat = (connection, clientId, name) => {
  const k = keyOf(connection, clientId);
  if (!chats.has(k)) chats.set(k, { key: k, connection, clientId, name, session: null, route: null, request: null, lines: [], outbox: [], unread: 0 });
  const c = chats.get(k);
  if (name) c.name = name;
  return c;
};
const bySession = (session) => [...chats.values()].find((c) => c.session === session || c.request === session);
const note = (c, text) => c.lines.push({ who: null, text });
const ROUTES = {
  direct: "Connected directly, end-to-end encrypted.",
  relay: "Connected through a TURN relay, end-to-end encrypted.",
  server: "No direct route: messages go through the TeamSpeak server, which can read them.",
};

// Sends what waits, once the session is open; "busy" (the server route is slow) tries again shortly.
const flush = (c) => {
  while (c.outbox.length && c.route) {
    try {
      App.p2p.send(c.session, JSON.stringify({ text: c.outbox[0] }));
    } catch (e) {
      if (String(e.message).startsWith("busy")) {
        setTimeout(() => flush(c), 1000);
      } else {
        note(c, `Not sent: ${e.message}`);
        c.outbox.shift();
      }
      return;
    }
    c.lines.push({ who: "me", text: c.outbox.shift() });
  }
};

const send = (c) => {
  const text = draft.trim();
  if (!text) return;
  draft = "";
  c.outbox.push(text.slice(0, 4000));
  if (c.session) return flush(c);
  try {
    c.session = App.p2p.connect(c.connection, c.clientId);
    note(c, `Asking ${c.name} to connect…`);
  } catch (e) {
    c.outbox.pop();
    note(c, `Can't connect: ${e.message}`);
  }
};

App.events.on("p2p.request", (r) => {
  const c = chat(r.connection, r.clientId, r.name);
  c.request = r.session;
  if (!current) current = c;
  App.ui.notify(`${r.name} wants to chat privately`);
  App.ui.open("chat");
});
App.events.on("p2p.open", ({ session, route }) => {
  const c = bySession(session);
  if (!c || c.session !== session) return;
  c.route = route;
  note(c, ROUTES[route] || route);
  flush(c);
});
App.events.on("p2p.message", ({ session, data }) => {
  const c = bySession(session);
  if (!c || c.session !== session) return;
  let m;
  try { m = JSON.parse(data); } catch { return; }
  if (typeof m.text !== "string") return;
  c.lines.push({ who: c.name, text: m.text.slice(0, 4000) });
  if (current !== c || !App.ui.isOpen("chat")) c.unread++;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  const c = bySession(session);
  if (!c) return;
  if (c.request === session) c.request = null;
  if (c.session !== session) return;
  c.session = null;
  c.route = null;
  if (c.outbox.length) note(c, `${c.outbox.length} message(s) not sent`);
  c.outbox = [];
  note(c, reason ? `Disconnected: ${reason}` : "Disconnected");
});

const accept = (c) => {
  // Both asked at once: theirs wins, ours goes.
  if (c.session && c.session !== c.request) App.p2p.close(c.session);
  c.session = c.request;
  c.request = null;
  App.p2p.accept(c.session);
  note(c, "Connecting…");
};
const decline = (c) => {
  App.p2p.close(c.request);
  c.request = null;
};

const conversation = (c) => [
  c.request && {
    type: "group",
    children: [
      `${c.name} wants to chat privately. Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`,
      { type: "row", children: [{ type: "button", label: "Accept", variant: "filled", onClick: () => accept(c) }, { type: "button", label: "Decline", onClick: () => decline(c) }] },
    ],
  },
  c.route && { type: "label", text: ROUTES[c.route], small: true, color: c.route === "server" ? "orange" : "green" },
  {
    type: "scroll",
    reserve: 40,
    children: c.lines.length
      ? c.lines.map((l) => (l.who ? { type: "label", text: `${l.who === "me" ? "You" : l.who}: ${l.text}`, color: l.who === "me" ? "dim" : undefined } : { type: "label", text: l.text, small: true, color: "faint" }))
      : [{ type: "label", text: "No messages yet.", color: "faint" }],
  },
  {
    type: "row",
    children: [
      { type: "input", value: draft, hint: `Message ${c.name}`, width: 330, onChange: (v) => (draft = v), onSubmit: () => send(c) },
      { type: "button", label: "Send", onClick: () => send(c) },
      c.session && { type: "button", label: "Disconnect", onClick: () => App.p2p.close(c.session) },
    ],
  },
];

App.ui.registerPanel({
  id: "chat",
  title: "Private chat",
  width: 520,
  height: 440,
  render: () => {
    const peers = App.p2p.peers();
    for (const p of peers) chat(p.connection, p.clientId, p.name);
    const here = new Set(peers.map((p) => keyOf(p.connection, p.clientId)));
    // People still on the server, and the ones we talked to.
    const list = [...chats.values()].filter((c) => here.has(c.key) || c.lines.length || c.request);
    if (current && !list.includes(current)) current = null;
    if (!current && list.length) current = list[0];
    if (current) current.unread = 0;
    if (!list.length) return [{ type: "heading", text: "Private chat" }, { type: "label", text: "Nobody on your servers runs TeamSpeak Desktop with Private chat yet.", color: "dim" }];
    return [
      {
        type: "select",
        value: current.key,
        options: list.map((c) => ({ value: c.key, label: `${c.name}${c.unread ? ` (${c.unread})` : ""}${c.request ? " — wants to chat" : ""}` })),
        onChange: (k) => (current = chats.get(k) || current),
      },
      conversation(current),
    ];
  },
});
App.ui.registerMenu({ id: "chat", label: "Private chat", icon: "🔒", onClick: () => App.ui.toggle("chat") });
