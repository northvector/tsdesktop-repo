// @ts-check
/// <reference path="../../app.d.ts" />
// A card table for 1-4 players over App.p2p: Blackjack against a dealer, Crazy Eights and Judgement. Built like Ludo:
// the host invites the others (one session each) and keeps the game; guests send {t:"act", a, ...}, the host checks it
// against the rules and sends each player {t:"state", v, you}, a view with every card that player may not see (the
// others' hands, the deck, the dealer's hole card) left blank, so reading the messages shows nothing extra.
// Spectators are members without a seat (`you` -1), shown nobody's cards. A player who left can be invited back to
// their seat; meanwhile Judgement plays that seat by itself and the other games skip it.
// shortcut: the host shuffles and holds every card; fine among friends, add a mental-poker shuffle for strangers.
// Cards: Byron Knoll's public-domain Vector Playing Cards (back drawn for this plugin). Sounds: Kenney's Casino Audio (CC0).

const RANKS = "23456789TJQKA";
const SUITS = "CDHS";
const SUIT_GLYPH = { C: "♣", D: "♦", H: "♥", S: "♠" };
const SUIT_NAME = { C: "Clubs", D: "Diamonds", H: "Hearts", S: "Spades" };
const SUIT_COLOR = { C: "#eef2ef", D: "#ff6b6b", H: "#ff6b6b", S: "#eef2ef" };
const GAMES = { bj: "Blackjack", ce: "Crazy Eights", jd: "Judgement" };
const BETS = [5, 10, 25, 50];
const START_CHIPS = 100;

const shuffle = (d) => {
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
};
/** A shuffled deck of codes like "AS", "TD", "7H". */
const newDeck = () => shuffle([...SUITS].flatMap((s) => [...RANKS].map((r) => r + s)));

/**
 * @typedef {{ name: string; gone?: boolean }} Player
 * `base`: the bet chosen (`bet` doubles with a double).
 * @typedef {{ cards: string[]; bet: number; base: number; chips: number; ready: boolean; done: boolean; result: string; won: number }} Hand
 * @typedef {{ stage: "bet" | "turns" | "dealer" | "settled"; dealer: string[]; deck: string[]; hands: Hand[]; turn: number }} Bj
 * @typedef {{ hands: string[][]; pile: string[]; deck: string[]; suit: string; turn: number; drew: boolean; winner: number }} Ce
 * @typedef {{ round: number; size: number; trump: string; dealer: number; stage: "bid" | "play" | "trick" | "scored" | "over"; hands: string[][]; bids: number[]; won: number[]; scores: number[]; trick: { pi: number; card: string }[]; turn: number; take: number }} Jd
 * @typedef {{ phase: "lobby" | "play"; game: "bj" | "ce" | "jd"; players: Player[]; n: number; round: number; log: string; bj?: Bj; ce?: Ce; jd?: Jd }} State
 */
const active = (s) => s.players.flatMap((p, i) => (p.gone ? [] : [i]));

// ---- Blackjack. Everyone plays the dealer; dealer peeks for blackjack and stands on every 17; blackjack pays 3:2. ----
// shortcut: no splitting or insurance; add them if people ask.

const points = (cards) => {
  let t = 0;
  let aces = 0;
  for (const c of cards.filter(Boolean)) {
    if (c[0] === "A") (t += 11), aces++;
    else t += "TJQK".includes(c[0]) ? 10 : Number(c[0]);
  }
  while (t > 21 && aces) (t -= 10), aces--;
  return { t, soft: aces > 0 };
};
const natural = (cards) => cards.length === 2 && points(cards).t === 21;

/** @returns {Bj} */
const bjNew = (n) => ({ stage: "bet", dealer: [], deck: [], turn: -1, hands: Array.from({ length: n }, () => ({ cards: [], bet: 10, base: 10, chips: START_CHIPS, ready: false, done: false, result: "", won: 0 })) });

const bjBet = (s, pi, amount) => {
  const h = s.bj.hands[pi];
  if (s.bj.stage === "bet" && !h.ready && BETS.includes(amount) && amount <= h.chips) h.bet = h.base = amount;
};
const bjReady = (s, pi) => {
  if (s.bj.stage !== "bet") return;
  s.bj.hands[pi].ready = true;
  s.log = `${s.players[pi].name} is in`;
  bjMaybeDeal(s);
};
/** Deals once everyone still at the table has bet. */
const bjMaybeDeal = (s) => {
  const b = s.bj;
  const on = active(s);
  if (b.stage !== "bet" || !on.length || on.some((i) => !b.hands[i].ready)) return;
  b.deck = newDeck();
  b.dealer = [];
  s.round++;
  for (const i of on) Object.assign(b.hands[i], { cards: [], done: false, result: "", won: 0, chips: b.hands[i].chips - b.hands[i].bet });
  for (let k = 0; k < 2; k++) {
    for (const i of on) b.hands[i].cards.push(b.deck.pop());
    b.dealer.push(b.deck.pop());
  }
  for (const i of on) if (natural(b.hands[i].cards)) b.hands[i].done = true;
  if (natural(b.dealer)) return bjSettle(s); // the dealer peeks: the round ends at once
  Object.assign(b, { stage: "turns", turn: -1 });
  bjNextTurn(s);
};
const bjNextTurn = (s) => {
  const b = s.bj;
  for (let i = b.turn + 1; i < s.players.length; i++)
    if (!s.players[i].gone && !b.hands[i].done) return void ((b.turn = i), (s.log = `${s.players[i].name}'s turn`));
  Object.assign(b, { stage: "dealer", turn: -1 });
  s.log = "The dealer turns the hole card";
};
const bjDone = (s, pi, log) => {
  s.bj.hands[pi].done = true;
  bjNextTurn(s);
  s.log = log;
};
const bjHit = (s, pi) => {
  const b = s.bj;
  if (b.stage !== "turns" || b.turn !== pi) return;
  const h = b.hands[pi];
  const name = s.players[pi].name;
  h.cards.push(b.deck.pop());
  const t = points(h.cards).t;
  if (t > 21) bjDone(s, pi, `${name} busts with ${t}`);
  else if (t === 21) bjDone(s, pi, `${name} has 21`);
  else s.log = `${name} hits: ${t}`;
};
const bjStand = (s, pi) => {
  if (s.bj.stage === "turns" && s.bj.turn === pi) bjDone(s, pi, `${s.players[pi].name} stands on ${points(s.bj.hands[pi].cards).t}`);
};
const bjDouble = (s, pi) => {
  const b = s.bj;
  const h = b.hands[pi];
  if (b.stage !== "turns" || b.turn !== pi || h.cards.length !== 2 || h.chips < h.bet) return;
  h.chips -= h.bet;
  h.bet *= 2;
  h.cards.push(b.deck.pop());
  bjDone(s, pi, `${s.players[pi].name} doubles: ${points(h.cards).t}`);
};
/** One dealer move, run by the host on a timer so everyone watches the cards come. */
const bjDealerStep = (s) => {
  const b = s.bj;
  const live = active(s).some((i) => points(b.hands[i].cards).t <= 21);
  if (live && points(b.dealer).t < 17) return void (b.dealer.push(b.deck.pop()), (s.log = `Dealer draws: ${points(b.dealer).t}`));
  bjSettle(s);
};
const bjSettle = (s) => {
  const b = s.bj;
  const d = points(b.dealer).t;
  const dn = natural(b.dealer);
  for (const i of active(s)) {
    const h = b.hands[i];
    const t = points(h.cards).t;
    const nat = natural(h.cards);
    /** @type {[string, number]} */
    const [result, back] =
      t > 21 ? ["Bust", 0]
      : nat && dn ? ["Push", h.bet]
      : nat ? ["Blackjack!", h.bet + Math.floor((h.bet * 3) / 2)]
      : dn ? ["Dealer blackjack", 0]
      : d > 21 || t > d ? ["Win", 2 * h.bet]
      : t === d ? ["Push", h.bet]
      : ["Lose", 0];
    Object.assign(h, { result, won: back, chips: h.chips + back, done: true });
  }
  Object.assign(b, { stage: "settled", turn: -1 });
  s.log = dn ? "Dealer has blackjack" : d > 21 ? `Dealer busts with ${d}` : `Dealer stands on ${d}`;
};
const bjNextRound = (s) => {
  const b = s.bj;
  if (b.stage !== "settled") return;
  Object.assign(b, { stage: "bet", dealer: [], turn: -1 });
  const broke = [];
  b.hands.forEach((h, i) => {
    if (h.chips < BETS[0]) (h.chips = START_CHIPS), s.players[i].gone || broke.push(s.players[i].name);
    const bet = [...BETS].reverse().find((x) => x <= Math.min(h.base, h.chips)) || BETS[0];
    Object.assign(h, { cards: [], ready: false, done: !!s.players[i].gone, result: "", won: 0, bet });
  });
  s.log = broke.length ? `The house gives ${broke.join(" and ")} ${START_CHIPS} fresh chips` : "Place your bets";
};

// ---- Crazy Eights. Match the top card's suit or rank; an 8 goes on anything and names the suit. Can't go: draw one,
// then play or pass. First to empty their hand wins. ----

const ceCanPlay = (c, top, suit) => c[0] === "8" || c[1] === suit || c[0] === top[0];
/** @returns {Ce} */
const ceNew = (n) => {
  const deck = newDeck();
  const k = n === 2 ? 7 : 5;
  const hands = Array.from({ length: n }, () => deck.splice(-k));
  const pile = deck.splice(deck.findIndex((c) => c[0] !== "8"), 1);
  return { hands, pile, deck, suit: pile[0][1], turn: 0, drew: false, winner: -1 };
};
const ceNext = (s) => {
  const c = s.ce;
  c.drew = false;
  for (let i = 1; i <= s.players.length; i++) {
    const t = (c.turn + i) % s.players.length;
    if (!s.players[t].gone) return void (c.turn = t);
  }
};
const cePlay = (s, pi, card, suit) => {
  const c = s.ce;
  const h = c.hands[pi];
  const k = typeof card === "string" ? h.indexOf(card) : -1;
  if (c.winner >= 0 || c.turn !== pi || k < 0 || !ceCanPlay(card, c.pile[c.pile.length - 1], c.suit)) return;
  const eight = card[0] === "8";
  if (eight && !(typeof suit === "string" && suit.length === 1 && SUITS.includes(suit))) return;
  h.splice(k, 1);
  c.pile.push(card);
  c.suit = eight ? suit : card[1];
  const name = s.players[pi].name;
  if (!h.length) return void ((c.winner = pi), (s.log = `${name} played the last card and won!`));
  s.log = eight ? `${name} played an 8 and named ${SUIT_NAME[suit]}` : `${name} played`;
  ceNext(s);
};
const ceDraw = (s, pi) => {
  const c = s.ce;
  if (c.winner >= 0 || c.turn !== pi || c.drew) return;
  if (!c.deck.length) c.deck = shuffle(c.pile.splice(0, c.pile.length - 1)); // the pile but its top card becomes the deck
  const card = c.deck.pop();
  if (card) c.hands[pi].push(card);
  c.drew = true;
  s.log = card ? `${s.players[pi].name} drew a card` : "No cards left to draw";
};
const cePass = (s, pi) => {
  const c = s.ce;
  if (c.winner < 0 && c.turn === pi && c.drew) (s.log = `${s.players[pi].name} passed`), ceNext(s);
};

// ---- Judgement: seven rounds, of 7 cards down to 1. Everyone bids the tricks they'll take; the dealer bids last and
// may not make the bids add up to the cards in hand. Follow suit if you can; the highest trump, else the highest card
// of the suit led, takes the trick. Trumps go ♠ ♦ ♣ ♥. Taking exactly your bid scores 10 + the bid, anything else 0. ----

const JD_SIZES = [7, 6, 5, 4, 3, 2, 1];
const JD_TRUMPS = "SDCH";
const higher = (a, b) => RANKS.indexOf(a[0]) - RANKS.indexOf(b[0]);
/** @returns {Jd} */
const jdNew = (n) => ({ round: -1, size: 0, trump: "S", dealer: 0, stage: "bid", hands: [], bids: [], won: [], scores: Array(n).fill(0), trick: [], turn: 0, take: -1 });
const jdDeal = (s) => {
  const j = s.jd;
  const n = s.players.length;
  const deck = newDeck();
  j.round++;
  Object.assign(j, { size: JD_SIZES[j.round], trump: JD_TRUMPS[j.round % 4], dealer: j.round % n, stage: "bid", bids: Array(n).fill(-1), won: Array(n).fill(0), trick: [], take: -1 });
  j.hands = Array.from({ length: n }, () => deck.splice(-j.size));
  j.turn = (j.dealer + 1) % n;
  s.round++;
  s.log = `${s.players[j.dealer].name} deals ${j.size}; ${s.players[j.turn].name} bids first`;
};
/** The bid player `pi` may not make: for the dealer, the one that makes the bids add up to the tricks; else -1. */
const jdHook = (j, pi) => {
  if (pi !== j.dealer) return -1;
  const rest = j.size - j.bids.reduce((a, b, i) => a + (i === pi ? 0 : Math.max(0, b)), 0);
  return rest >= 0 ? rest : -1;
};
const jdLegal = (hand, trick) => {
  const led = trick[0]?.card[1];
  return led && hand.some((c) => c[1] === led) ? hand.filter((c) => c[1] === led) : hand;
};
const jdWinner = (trick, trump) => trick.reduce((best, t) => ((t.card[1] === best.card[1] ? higher(t.card, best.card) > 0 : t.card[1] === trump) ? t : best)).pi;
const jdBid = (s, pi, bid) => {
  const j = s.jd;
  if (j.stage !== "bid" || j.turn !== pi || !Number.isInteger(bid) || bid < 0 || bid > j.size || bid === jdHook(j, pi)) return;
  j.bids[pi] = bid;
  s.log = `${s.players[pi].name} bids ${bid}`;
  j.turn = (pi + 1) % s.players.length; // after the dealer: the first bidder, who leads
  if (pi === j.dealer) j.stage = "play";
};
const jdPlay = (s, pi, card) => {
  const j = s.jd;
  const h = j.hands[pi];
  if (j.stage !== "play" || j.turn !== pi || typeof card !== "string" || !jdLegal(h, j.trick).includes(card)) return;
  h.splice(h.indexOf(card), 1);
  j.trick.push({ pi, card });
  s.log = `${s.players[pi].name} played`;
  if (j.trick.length < s.players.length) return void (j.turn = (pi + 1) % s.players.length);
  Object.assign(j, { take: jdWinner(j.trick, j.trump), stage: "trick", turn: -1 });
  s.log = `${s.players[j.take].name} takes the trick`;
};
/** Run by the host after a pause, so everyone sees the trick before it goes. */
const jdCollect = (s) => {
  const j = s.jd;
  if (j.stage !== "trick") return;
  j.won[j.take]++;
  Object.assign(j, { trick: [], turn: j.take, take: -1, stage: "play" });
  if (j.hands[0].length) return;
  const made = s.players.flatMap((p, i) => (j.won[i] === j.bids[i] ? [p.name] : []));
  j.scores = j.scores.map((x, i) => (j.won[i] === j.bids[i] ? x + 10 + j.bids[i] : x));
  Object.assign(j, { stage: j.round === JD_SIZES.length - 1 ? "over" : "scored", turn: -1 });
  s.log = made.length ? `${made.join(" and ")} made their bid` : "Nobody made their bid";
};
/** A seat whose player left plays on: the lowest bid it may make, then its lowest legal card. */
const jdAuto = (s) => {
  const j = s.jd;
  if (j.stage === "bid") jdBid(s, j.turn, jdHook(j, j.turn) === 0 ? 1 : 0);
  else if (j.stage === "play") jdPlay(s, j.turn, [...jdLegal(j.hands[j.turn], j.trick)].sort(higher)[0]);
};

// ---- the table: starting games, actions, people leaving, and what each player is shown ----

const newGame = (s, game) => {
  s.game = game;
  s.round++;
  if (game === "bj") (s.bj = bjNew(s.players.length)), (s.log = "Place your bets"), s.players.forEach((p, i) => p.gone && (s.bj.hands[i].done = true));
  else if (game === "ce") (s.ce = ceNew(s.players.length)), (s.log = `${s.players[0].name} starts`);
  else (s.jd = jdNew(s.players.length)), jdDeal(s);
};
/** A player's action, checked against the rules; false when it isn't one. */
const apply = (s, pi, m) => {
  if (s.phase !== "play" || !m || s.players[pi]?.gone) return false;
  if (s.game === "bj")
    switch (m.a) {
      case "bet": return bjBet(s, pi, m.amount), true;
      case "ready": return bjReady(s, pi), true;
      case "hit": return bjHit(s, pi), true;
      case "stand": return bjStand(s, pi), true;
      case "double": return bjDouble(s, pi), true;
    }
  else if (s.game === "jd")
    switch (m.a) {
      case "bid": return jdBid(s, pi, m.bid), true;
      case "play": return jdPlay(s, pi, m.card), true;
    }
  else
    switch (m.a) {
      case "play": return cePlay(s, pi, m.card, m.suit), true;
      case "draw": return ceDraw(s, pi), true;
      case "pass": return cePass(s, pi), true;
    }
  return false;
};
const dropOut = (s, pi) => {
  s.players[pi].gone = true;
  s.log = `${s.players[pi].name} left`;
  if (s.phase !== "play") return;
  if (s.game === "bj") {
    s.bj.hands[pi].done = true;
    if (s.bj.stage === "bet") bjMaybeDeal(s);
    else if (s.bj.stage === "turns" && s.bj.turn === pi) bjNextTurn(s);
    return;
  }
  const left = active(s);
  if (s.game === "jd") {
    // Their seat plays on by itself (see `pending`), unless nobody is left to play against.
    if (left.length < 2 && s.jd.stage !== "over") Object.assign(s.jd, { stage: "over", turn: -1 }), (s.log = "Everyone else left");
    return;
  }
  if (s.ce.winner < 0 && left.length < 2) (s.ce.winner = left[0] ?? 0), (s.log = "Everyone else left");
  else if (s.ce.turn === pi) ceNext(s);
};
/** A player who left takes their seat again (the host invited them back). */
const rejoin = (s, pi) => {
  s.players[pi].gone = false;
  s.log = `${s.players[pi].name} is back`;
  if (s.game === "bj" && s.bj.stage === "bet") Object.assign(s.bj.hands[pi], { done: false, ready: false });
};
/** Whether the table moves by itself next (the dealer draws, a trick is taken, an empty seat plays). */
const pending = (s) =>
  s.phase === "play" &&
  (s.game === "bj" ? s.bj.stage === "dealer" : s.game === "jd" && (s.jd.stage === "trick" || ((s.jd.stage === "bid" || s.jd.stage === "play") && !!s.players[s.jd.turn]?.gone)));
const step = (s) => (s.game === "bj" ? bjDealerStep(s) : s.jd.stage === "trick" ? jdCollect(s) : jdAuto(s));
/** What player `me` sees: the dealer's hole card stays down until the dealer plays; others' hands and the deck are backs. */
const viewFor = (s, me) => {
  const v = { phase: s.phase, game: s.game, players: s.players, n: s.n, round: s.round, log: s.log };
  if (s.phase !== "play") return v;
  if (s.game === "bj") {
    const b = s.bj;
    return { ...v, bj: { stage: b.stage, turn: b.turn, hands: b.hands, dealer: b.dealer.map((c, i) => (b.stage === "turns" && i === 1 ? "" : c)) } };
  }
  if (s.game === "jd") {
    const j = s.jd;
    return { ...v, jd: { ...j, hands: j.hands.map((h, i) => (i === me ? h : h.map(() => ""))) } };
  }
  const c = s.ce;
  return { ...v, ce: { hands: c.hands.map((h, i) => (i === me ? h : h.map(() => ""))), top: c.pile[c.pile.length - 1], deck: c.deck.length + c.pile.length - 1, suit: c.suit, turn: c.turn, drew: c.drew, winner: c.winner } };
};

/** The host's view is another person's data: check its shape before drawing it. */
const validView = (v) => {
  const int = (x, lo, hi) => Number.isInteger(x) && x >= lo && x <= hi;
  const isCard = (c) => typeof c === "string" && /^([2-9TJQKA][CDHS])?$/.test(c);
  const cards = (a, max) => Array.isArray(a) && a.length <= max && a.every(isCard);
  const names = (a) => Array.isArray(a) && a.length <= 8 && a.every((x) => typeof x === "string");
  if (!v || (v.phase !== "lobby" && v.phase !== "play") || !Object.hasOwn(GAMES, v.game) || !names(v.watchers) || typeof v.log !== "string" || !int(v.n, 0, 1e9) || !int(v.round, 0, 1e9)) return false;
  if (!Array.isArray(v.players) || !int(v.players.length, 1, 4) || !v.players.every((p) => p && typeof p.name === "string")) return false;
  if (v.phase === "lobby") return true;
  const np = v.players.length;
  if (v.game === "bj") {
    const b = v.bj;
    return (
      !!b && ["bet", "turns", "dealer", "settled"].includes(b.stage) && int(b.turn, -1, np - 1) && cards(b.dealer, 12) &&
      Array.isArray(b.hands) && b.hands.length === np &&
      b.hands.every((h) => h && cards(h.cards, 12) && h.cards.every(Boolean) && int(h.bet, 0, 1e6) && int(h.chips, 0, 1e9) && int(h.won, 0, 1e9) && typeof h.result === "string" && typeof h.ready === "boolean" && typeof h.done === "boolean")
    );
  }
  if (v.game === "jd") {
    const j = v.jd;
    const each = (a, lo, hi) => Array.isArray(a) && a.length === np && a.every((x) => int(x, lo, hi));
    return (
      !!j && int(j.round, 0, JD_SIZES.length - 1) && int(j.size, 1, 7) && typeof j.trump === "string" && j.trump.length === 1 && SUITS.includes(j.trump) &&
      int(j.dealer, 0, np - 1) && ["bid", "play", "trick", "scored", "over"].includes(j.stage) && Array.isArray(j.hands) && j.hands.length === np && j.hands.every((h) => cards(h, 7)) &&
      each(j.bids, -1, 7) && each(j.won, 0, 7) && each(j.scores, 0, 1e6) && int(j.turn, -1, np - 1) && int(j.take, -1, np - 1) &&
      Array.isArray(j.trick) && j.trick.length <= np && j.trick.every((t) => t && int(t.pi, 0, np - 1) && isCard(t.card) && !!t.card)
    );
  }
  const c = v.ce;
  return (
    !!c && Array.isArray(c.hands) && c.hands.length === np && c.hands.every((h) => cards(h, 52)) && isCard(c.top) && !!c.top &&
    int(c.deck, 0, 52) && typeof c.suit === "string" && c.suit.length === 1 && SUITS.includes(c.suit) && int(c.turn, 0, np - 1) && typeof c.drew === "boolean" && int(c.winner, -1, np - 1)
  );
};

// Self-check of the rules.
{
  const ok = (c, what) => c || App.log(`Card Table: ${what} is broken`);
  ok(newDeck().length === 52 && new Set(newDeck()).size === 52, "newDeck");
  ok(points(["AS", "KD"]).t === 21 && points(["AS", "AD", "9C"]).t === 21 && points(["TS", "6D", "AC"]).t === 17 && points(["5S", ""]).t === 5, "points");
  const s = /** @type {State} */ ({ phase: "play", game: "bj", players: [{ name: "a" }, { name: "b" }], n: 0, round: 0, log: "" });
  newGame(s, "bj");
  bjBet(s, 0, 25);
  bjReady(s, 0);
  bjReady(s, 1);
  const b = /** @type {Bj} */ (s.bj);
  ok(b.hands[0].bet === 25 && b.hands[0].cards.length === 2 && b.dealer.length === 2 && s.round === 2, "dealing");
  // A fixed round: a stands on 20, b busts, the dealer draws to 17 from 16.
  Object.assign(b, { stage: "turns", turn: 0, dealer: ["TS", "6H"], deck: ["9D", "KC", "AC"] });
  Object.assign(b.hands[0], { cards: ["KS", "QH"], chips: 75 });
  b.hands[1].cards = ["TD", "5C"];
  b.hands.forEach((h) => (h.done = false));
  ok(viewFor(s, 1).bj.dealer[1] === "", "the hole card");
  bjStand(s, 0);
  bjHit(s, 1); // AC: 16
  bjHit(s, 1); // KC: bust
  ok(b.stage === "dealer", "turns");
  bjDealerStep(s); // 16 draws 9D: 25, a bust
  bjDealerStep(s);
  ok(b.stage === "settled" && b.hands[0].result === "Win" && b.hands[0].chips === 125 && b.hands[1].result === "Bust", "settling");
  b.hands[0].bet = 50; // as after doubling 25
  bjNextRound(s);
  ok(b.stage === "bet" && b.hands[0].bet === 25, "the next round's bet");
  newGame(s, "ce");
  const c = /** @type {Ce} */ (s.ce);
  ok(c.hands[0].length === 7 && c.pile[0][0] !== "8" && c.deck.length === 52 - 15, "crazy eights deal");
  Object.assign(c, { pile: ["5H"], suit: "H", hands: [["8C", "KS"], ["2D"]] });
  ok(viewFor(s, 0).ce.hands[1][0] === "", "hidden hands");
  cePlay(s, 0, "KS", undefined); // neither suit nor rank: refused
  ok(c.turn === 0 && c.hands[0].length === 2, "a wrong card");
  cePlay(s, 0, "8C", "D");
  ok(c.suit === "D" && c.turn === 1, "an 8");
  cePlay(s, 1, "2D", undefined);
  ok(c.winner === 1, "winning");
  newGame(s, "jd");
  const j = /** @type {Jd} */ (s.jd);
  ok(j.hands[0].length === 7 && j.dealer === 0 && j.turn === 1 && j.trump === "S", "judgement deal");
  Object.assign(j, { size: 2, hands: [["AH", "2S"], ["KH", "3D"]] });
  jdBid(s, 1, 1);
  ok(jdHook(j, 0) === 1, "the dealer's hook");
  jdBid(s, 0, 1); // refused: the bids would add up to 2 tricks
  jdBid(s, 0, 0);
  ok(j.stage === "play" && j.turn === 1, "bidding");
  jdPlay(s, 1, "3D"); // b leads a diamond
  jdPlay(s, 0, "AH"); // a has none: any card, but only a trump would win
  ok(j.take === 1 && j.stage === "trick", "a trick");
  jdCollect(s);
  jdPlay(s, 1, "KH");
  jdPlay(s, 0, "2S"); // a trump
  jdCollect(s);
  ok(j.won[0] === 1 && j.won[1] === 1 && j.scores[1] === 11 && j.scores[0] === 0 && j.stage === "scored", "judgement scoring");
  ok(viewFor(s, -1).jd.hands.every((h) => h.every((x) => x === "")) && validView({ ...viewFor(s, 0), watchers: [] }), "a spectator's view");
}

// ---- network (as in Ludo) ----

/**
 * The host's room holds members (one session each); a guest's holds the host's session and the last view.
 * `watch`: a spectator. `session` is "" once a seated player left (the host may invite them back).
 * @typedef {{ key: string; name: string; connection: number; clientId: number; session: string; open: boolean; watch: boolean }} Member
 * @type {null | { host: true; members: Map<string, Member>; keys: string[]; s: State; note: string } | { host: false; name: string; session: string | null; open: boolean; v: any; you: number; note: string }}
 */
let room = null;
/** Invitations waiting for the user, by session. */
const requests = new Map();
App.p2p.peers(); // start P2P now so others can find us before the window opens

const myName = () => {
  const st = App.app.state();
  const c = st.connections.find((c) => c.id === st.active) || st.connections[0];
  return c?.clients.find((x) => x.id === c.ownClientId)?.name || "Host";
};

const sendRaw = (session, msg, tries = 0) => {
  try {
    App.p2p.send(session, msg);
  } catch (e) {
    if (String(e.message).startsWith("busy") && tries < 10) setTimeout(() => sendRaw(session, msg, tries + 1), 500);
    else App.log(`Card Table: not sent: ${e.message}`);
  }
};
let hostTimer = 0;
const seated = (r) => [...r.members.values()].filter((m) => !m.watch);
const watchers = (r) => [...r.members.values()].filter((m) => m.watch);
const MAX_WATCHERS = 6;
/** Each open member's own view; `n` lets guests drop a late copy of an older one. Then the table's own next move, if any. */
const broadcast = () => {
  if (!room?.host) return;
  const r = room;
  if (r.s.phase === "lobby") r.s.players = [myName(), ...seated(r).map((m) => m.name)].map((name) => ({ name }));
  r.s.n++;
  const watching = watchers(r).filter((m) => m.open).map((m) => m.name);
  for (const m of r.members.values()) {
    const you = r.keys.indexOf(m.key);
    if (m.open) sendRaw(m.session, JSON.stringify({ t: "state", v: { ...viewFor(r.s, you), watchers: watching }, you }));
  }
  const s = r.s;
  if (pending(s) && !hostTimer)
    hostTimer = setTimeout(() => {
      hostTimer = 0;
      if (room?.host && room.s === s && pending(s)) step(s), broadcast();
    }, s.game === "jd" && s.jd?.stage === "trick" ? 1500 : 950);
};
const lobby = () => ({ host: /** @type {true} */ (true), members: new Map(), keys: [""], note: "", s: /** @type {State} */ ({ phase: "lobby", game: "bj", players: [], n: 0, round: 0, log: "" }) });
const keyOf = (peer) => `${peer.connection}:${peer.clientId}`;
/** A seated player who left and isn't being asked back yet. */
const leftSeat = (r, m) => !m.watch && !m.session && r.s.phase === "play" && !!r.s.players[r.keys.indexOf(m.key)]?.gone;

/** Asks a peer to a seat (in the lobby), back to the seat they left, or to watch. */
const invite = (peer, watch = false) => {
  if (room && !room.host) leave();
  if (!room) room = lobby();
  const r = room;
  const key = keyOf(peer);
  const old = r.members.get(key);
  const back = !!old && leftSeat(r, old);
  if (old && !back) return;
  if (!back && (watch ? watchers(r).length >= MAX_WATCHERS : r.s.phase !== "lobby" || seated(r).length >= 3)) return;
  try {
    r.members.set(key, { key, name: peer.name, connection: peer.connection, clientId: peer.clientId, session: App.p2p.connect(peer.connection, peer.clientId), open: false, watch: watch && !back });
    r.note = "";
  } catch (e) {
    r.note = `Can't reach ${peer.name}: ${e.message}`;
  }
  broadcast();
};
const removeMember = (m) => {
  if (!room?.host) return;
  if (m.session) App.p2p.close(m.session);
  room.members.delete(m.key);
  broadcast();
};
const canStart = (r) => {
  const ms = seated(r);
  return ms.every((m) => m.open) && ms.length >= (r.s.game === "bj" ? 0 : 1);
};
const start = () => {
  if (!room?.host || !canStart(room)) return; // hold everyone until all seated players' sessions are open
  const ms = seated(room);
  room.keys = ["", ...ms.map((m) => m.key)];
  const s = /** @type {State} */ ({ phase: "play", game: room.s.game, players: [myName(), ...ms.map((m) => m.name)].map((name) => ({ name })), n: room.s.n, round: 0, log: "" });
  newGame(s, s.game);
  room.s = s;
  broadcast();
};
/** The host deals the next Blackjack round, or starts a game (another, or the other one) with whoever is still here. */
const hostNext = (game) => {
  if (!room?.host || room.s.phase !== "play" || (game !== "bj" && active(room.s).length < 2)) return;
  if (game === "bj" && room.s.game === "bj") bjNextRound(room.s);
  else if (game === "jd" && room.s.game === "jd" && room.s.jd?.stage === "scored") jdDeal(room.s);
  else newGame(room.s, game);
  broadcast();
};
const leave = () => {
  if (room?.host) for (const m of room.members.values()) m.session && App.p2p.close(m.session);
  else if (room?.session) App.p2p.close(room.session);
  room = null;
  confirming = false;
  inviting = false;
};
/** The local player's action: applied by the host, sent to the host by a guest. */
const act = (m) => {
  if (!room) return;
  if (room.host) apply(room.s, 0, m) && broadcast();
  else if (room.session && room.open) sendRaw(room.session, JSON.stringify({ t: "act", ...m }));
};

const accept = (req) => {
  leave();
  requests.delete(req.session);
  App.p2p.accept(req.session);
  room = { host: false, name: req.name, session: req.session, open: false, v: null, you: -1, note: "" };
};
const decline = (req) => {
  requests.delete(req.session);
  App.p2p.close(req.session);
};
const memberBy = (session) => (room?.host ? [...room.members.values()].find((m) => m.session === session) : undefined);

App.events.on("p2p.request", (r) => {
  requests.set(r.session, r);
  App.ui.notify(`${r.name} invites you to the Card Table`);
  sfx("invite.wav", 0.6);
  App.ui.open("cards");
});
App.events.on("p2p.open", ({ session }) => {
  const m = memberBy(session);
  if (m && room?.host) {
    const pi = room.keys.indexOf(m.key);
    if (!m.open && pi > 0 && room.s.phase === "play" && room.s.players[pi].gone) rejoin(room.s, pi);
    return void ((m.open = true), broadcast());
  }
  if (room && !room.host && room.session === session) room.open = true;
});
App.events.on("p2p.closed", ({ session, reason }) => {
  requests.delete(session);
  // The app answers this way when their side doesn't run this plugin: the peer list holds every app user.
  const why = reason && reason.includes("plugin running") ? " doesn't have Card Table installed and enabled" : ` left${reason ? ` (${reason})` : ""}`;
  const m = memberBy(session);
  if (m && room?.host) {
    const r = room;
    const pi = r.keys.indexOf(m.key);
    const wasIn = m.open && !m.watch && pi > 0 && r.s.phase === "play";
    if (m.watch) r.note = m.open ? `${m.name} stopped watching.` : `${m.name}${why}.`;
    else if (wasIn) r.note = `${m.name} left. You can invite them back to their seat.`;
    else r.note = `${m.name}${why}.`;
    if (wasIn) dropOut(r.s, pi), Object.assign(m, { open: false, session: "" });
    else if (pi > 0 && r.s.phase === "play") Object.assign(m, { open: false, session: "" }); // asked back, didn't come
    else r.members.delete(m.key);
    return void broadcast();
  }
  if (room && !room.host && room.session === session)
    Object.assign(room, { session: null, open: false, note: room.v ? `${room.name} (the host)${why}. The table is closed.` : `Couldn't connect to ${room.name}${reason ? ` (${reason})` : ""}.` });
});
App.events.on("p2p.message", ({ session, data }) => {
  let msg;
  try {
    msg = JSON.parse(data);
  } catch {
    return;
  }
  const m = memberBy(session);
  if (m && room?.host) {
    const pi = room.keys.indexOf(m.key);
    if (pi >= 1 && msg?.t === "act" && apply(room.s, pi, msg)) broadcast();
    return;
  }
  if (!room || room.host || room.session !== session || msg?.t !== "state" || !validView(msg.v)) return;
  if (room.v && msg.v.n <= room.v.n) return;
  if (msg.v.phase === "play" && room.v?.phase !== "play") App.ui.notify(`${GAMES[msg.v.game]} with ${room.name} started`);
  room.v = msg.v;
  room.you = Number.isInteger(msg.you) && msg.you < msg.v.players.length ? msg.you : -1;
});

// ---- sound and motion ----

// Sounds on your own speakers only (never the mic).
// shortcut: mute lasts until the plugin restarts; keep it in App.storage if people ask (a new permission).
let muted = false;
const sfx = (file, volume = 0.5) => {
  if (muted) return;
  try {
    App.audio.play(`sounds/${file}`, { volume, mic: false });
  } catch (e) {
    App.log(`Card Table: no sound: ${e.message}`);
  }
};

// Every card on the table by slot, as it looked last frame. A new card is dealt in: it waits its turn in a short
// queue (so a deal goes round the table card by card), then grows into place with a swish. A card turned face up
// (the dealer's hole card) shrinks as its back and grows back as its face.
/** @type {Map<string, { code: string; start: number; kind: "deal" | "flip"; sound: string; sounded?: boolean; frame: number }>} */
let slots = new Map();
let dealAt = 0;
let frame = 0;
let now = 0;
let busy = false;
const DEAL_GAP = 150;
const GROW = 230;
/** Its scale (0: not dealt yet) and whether it shows its back right now. */
const motionOf = (key, code, sound) => {
  let a = slots.get(key);
  if (!a || (a.code && a.code !== code)) {
    dealAt = Math.max(dealAt, now);
    a = { code, start: dealAt, kind: "deal", sound, frame };
    dealAt += DEAL_GAP;
    slots.set(key, a);
  } else if (!a.code && code) Object.assign(a, { code, start: now, kind: "flip", sound: "flip.ogg", sounded: false });
  a.frame = frame;
  const t = now - a.start;
  if (t < 0) return (busy = true), { scale: 0, back: false };
  if (!a.sounded) (a.sounded = true), sfx(a.sound, 0.55);
  if (a.kind === "flip" && t < 2 * GROW) return (busy = true), t < GROW ? { scale: 1 - (0.85 * t) / GROW, back: true } : { scale: 0.15 + (0.85 * (t - GROW)) / GROW, back: false };
  if (a.kind === "deal" && t < GROW) {
    const e = 1 - (1 - t / GROW) ** 3; // ease out
    return (busy = true), { scale: 0.3 + 0.7 * e, back: false };
  }
  return { scale: 1, back: false };
};
/** Slots not drawn this frame are gone (a new round, a played card). */
const pruneSlots = () => {
  for (const [k, a] of slots) if (a.frame !== frame) slots.delete(k);
};

let ticker = 0;
const ticking = (on) => {
  if (on && !ticker) ticker = setInterval(() => {}, 30);
  else if (!on && ticker) (clearInterval(ticker), (ticker = 0));
};

// ---- view ----

const W = 90; // a card's width in points; its height is ~1.46 times that
const pics = new Map();
const pic = (code) => {
  const file = `cards/${code || "back"}.png`;
  let s = pics.get(file);
  if (!s) pics.set(file, (s = App.ui.image(file)));
  return s;
};
/** A card (code "" is its back) in slot `key`, dealt in and turned over as above. */
const card = (code, key, w = W, more = {}, sound = "deal.ogg") => {
  const m = motionOf(key, code, sound);
  if (!m.scale) return { type: "space", size: 0 };
  const cw = Math.max(4, Math.round(w * m.scale));
  return { type: "video", stream: pic(m.back ? "" : code), controls: false, width: cw, height: Math.round(cw * 1.46), text: " ", ...more };
};
const GAP = 8; // the app's space between the items of a row
/** Room for a row of cards across the felt at the window's opening width (720), past its margins. */
const FELT = 560;
/** A hand that narrows its cards (down to `min`) to fit `room` points, gaps included; too many, it takes even lines. */
const handRow = (codes, keyOf, room, w = W, more = () => ({}), min = 36) => {
  const per = Math.max(1, Math.floor((room + GAP) / (min + GAP)));
  if (codes.length > per) {
    const each = Math.ceil(codes.length / Math.ceil(codes.length / per));
    const lines = [];
    for (let k = 0; k < codes.length; k += each) lines.push(handRow(codes.slice(k, k + each), (c, i) => keyOf(c, k + i), room, w, (c, i) => more(c, k + i), min));
    return { type: "column", spacing: 6, children: lines };
  }
  const cw = codes.length ? Math.max(min, Math.min(w, Math.floor((room + GAP) / codes.length) - GAP)) : w;
  return { type: "row", children: codes.map((c, i) => card(c, keyOf(c, i), cw, more(c, i))) };
};

const muteButton = () => ({ type: "button", variant: "icon", label: muted ? "🔇" : "🔊", size: 18, tooltip: muted ? "Turn sounds on" : "Mute sounds", onClick: () => (muted = !muted) });
// Leaving a game in progress asks first: the host's leaving closes the table for everyone.
let confirming = false;
/** The host's panel for asking people back to their seat or to watch, under the table. */
let inviting = false;
const leaveWarning = () =>
  !room || (room.host ? room.s.phase !== "play" && !room.members.size : !room.session || room.you < 0 || room.v?.phase !== "play") ? ""
  : room.host ? "This closes the table for everyone." : "You can come back if the host invites you.";
const leaveButtons = () => {
  const warn = leaveWarning();
  if (confirming && warn) return [{ type: "label", text: warn, small: true, color: "dim" }, pill("Stay", () => (confirming = false)), pill("Leave", leave, { variant: "filled" })];
  return [
    room?.host && room.s.phase === "play" && { type: "button", variant: "icon", label: "👁", size: 18, selected: inviting, tooltip: "Invite someone to watch, or back to their seat", onClick: () => (inviting = !inviting) },
    { type: "button", label: room?.host ? "Close table" : "Leave table", radius: 14, onClick: () => (warn ? (confirming = true) : leave()) },
  ];
};
const header = (title, detail, tint) => ({
  type: "bar",
  left: [{ type: "space", size: 4 }, { type: "column", spacing: 2, children: [{ type: "label", text: title, color: tint, strong: true }, { type: "label", text: detail, color: "dim", small: true }] }],
  right: [...leaveButtons(), muteButton()],
});
/** Centred on the window's width, however wide it is. */
const mid = (node) => ({ type: "bar", center: node });
const waiting = (text) => ({ type: "row", children: [{ type: "spinner", size: 14 }, { type: "label", text, color: "dim" }] });
const pill = (label, onClick, more = {}) => ({ type: "button", label, radius: 16, height: 32, onClick, ...more });
const GOLD = "#f2c14e";

/** Sounds that follow the game rather than a card: a shuffle for a new deal, chips, your turn, a win. */
let heard = { round: 0, stage: "", turn: false, won: false };
const turnOf = (v) =>
  v.game === "bj" ? (v.bj.stage === "turns" ? v.bj.turn : -1)
  : v.game === "ce" ? (v.ce.winner < 0 ? v.ce.turn : -1)
  : v.jd.stage === "bid" || v.jd.stage === "play" ? v.jd.turn : -1;
const best = (j) => Math.max(...j.scores);
const listen = (v, me) => {
  const myTurn = me >= 0 && turnOf(v) === me;
  const stage = v.game === "bj" ? v.bj.stage : v.game === "ce" ? (v.ce.winner >= 0 ? "over" : "play") : v.jd.stage;
  const won =
    me < 0 ? false
    : v.game === "bj" ? stage === "settled" && (v.bj.hands[me]?.won || 0) > (v.bj.hands[me]?.bet || 0)
    : v.game === "ce" ? v.ce.winner === me
    : stage === "over" && v.jd.scores[me] === best(v.jd);
  if (v.round !== heard.round) sfx("shuffle.ogg", 0.6);
  else if (stage !== heard.stage && ["turns", "settled", "scored", "over"].includes(stage)) sfx("chips.ogg", 0.5);
  if (won && !heard.won) setTimeout(() => sfx("win.wav", 0.5), 300);
  else if (myTurn && !heard.turn) sfx("turn.wav", 0.4);
  heard = { round: v.round, stage, turn: myTurn, won };
};

const bjView = (v, me, host) => {
  const b = v.bj;
  const mine = b.hands[me] || { cards: [], ready: true, result: "", won: 0, bet: 0, chips: 0 }; // a spectator
  const myTurn = b.stage === "turns" && b.turn === me;
  const dealt = b.dealer.length > 0;
  const dp = points(b.dealer);
  const title =
    b.stage === "bet" ? (mine.ready ? "Waiting for bets" : "Place your bet")
    : b.stage === "turns" ? (myTurn ? `Your turn: ${points(mine.cards).t}` : `${v.players[b.turn].name}'s turn`)
    : b.stage === "dealer" ? "Dealer plays"
    : mine.result || "Round over";
  const tint = b.stage === "settled" && mine.won > mine.bet ? "#5fd38d" : b.stage === "settled" && !mine.won && mine.result ? "#ff7b72" : GOLD;
  // A seat's share of the felt, inside its panel's padding.
  const seatRoom = [0, 300, 280, 180, 128][v.players.length];
  const seat = (p, i) => {
    const h = b.hands[i];
    const up = b.stage === "turns" && b.turn === i;
    const { t: pts, soft } = points(h.cards);
    const status = p.gone ? "Left" : h.result ? `${h.result}${h.won ? ` +${h.won}` : ""}` : h.cards.length ? (natural(h.cards) ? "Blackjack" : pts > 21 ? `Bust (${pts})` : `${soft ? "Soft " : ""}${pts}`) : h.ready ? "In" : "Betting...";
    const tone = h.result === "Win" || h.result === "Blackjack!" ? "#5fd38d" : h.result && h.result !== "Push" ? "#ff7b72" : p.gone || !h.cards.length ? "dim" : undefined;
    return {
      type: "group",
      padding: 14,
      children: [
        mid({ type: "label", text: `${up ? "▶ " : ""}${p.name}${i === me ? " (you)" : ""}`, strong: true, color: up ? GOLD : p.gone ? "faint" : undefined }),
        h.cards.length ? mid(handRow(h.cards, (c, k) => `p${i}:${k}`, seatRoom, 70, undefined, 12)) : { type: "space", size: 102 },
        mid({ type: "label", text: status, strong: true, color: tone }),
        mid({ type: "label", text: `🪙 ${h.chips}  ·  bet ${h.bet}`, small: true, color: "dim" }),
      ],
    };
  };
  const actions =
    b.stage === "bet" && !mine.ready ? [{ type: "row", children: [...BETS.map((x) => ({ type: "button", variant: "pill", label: `🪙 ${x}`, selected: mine.bet === x, enabled: x <= mine.chips, onClick: () => (sfx("chip.ogg", 0.5), act({ a: "bet", amount: x })) })), pill("Deal me in", () => act({ a: "ready" }), { variant: "filled" })] }]
    : myTurn ? [{ type: "row", children: [pill("Hit", () => act({ a: "hit" }), { variant: "filled" }), pill("Stand", () => act({ a: "stand" })), pill(`Double (${mine.bet})`, () => act({ a: "double" }), { enabled: mine.cards.length === 2 && mine.chips >= mine.bet })] }]
    : b.stage === "settled" ? [nextButtons(v, host, "bj", "Next round", "Waiting for the host to deal again...")]
    : [];
  return [
    header(title, v.log, tint),
    { type: "space", size: 14 },
    // The dealer sits across the felt from the players, with no panel of their own.
    mid([{ type: "label", text: "Dealer", color: "dim" }, dealt && { type: "label", text: b.dealer.every(Boolean) ? `${dp.t}${dp.t > 21 ? " bust" : ""}` : `${dp.t} + ?`, strong: true }]),
    dealt ? mid(handRow(b.dealer, (c, k) => `d:${k}`, FELT)) : { type: "space", size: Math.round(W * 1.46) },
    { type: "space", size: 18 },
    // A slot of fixed height, so the seats don't jump when the buttons come and go.
    actions.length ? mid(actions) : { type: "space", size: 34 },
    { type: "space", size: 18 },
    { type: "grid", columns: v.players.length, fill: true, minWidth: 150, children: v.players.map(seat) },
    { type: "space", size: 10 },
    mid({ type: "label", text: "Bets of 5 to 50 chips. Blackjack pays 3:2, doubling takes one card, and the dealer stands on every 17.", small: true, color: "faint" }),
  ];
};

let pick8 = /** @type {string | null} */ (null);
const ceView = (v, me, host) => {
  const c = v.ce;
  const myTurn = c.winner < 0 && c.turn === me;
  if (!myTurn) pick8 = null;
  const hand = c.hands[me] || [];
  const turner = v.players[c.turn].name;
  const title = c.winner >= 0 ? (c.winner === me ? "You won!" : `${v.players[c.winner].name} won`) : myTurn ? "Your turn" : `${turner}'s turn`;
  const detail = c.winner >= 0 ? v.log : myTurn ? (pick8 ? "Name the suit for your 8" : c.drew ? "Play a card or pass" : "Play a card that matches, an 8, or draw") : v.log;
  const playable = (code) => myTurn && !pick8 && ceCanPlay(code, c.top, c.suit);
  const play = (code) => (code[0] === "8" ? (pick8 = code) : act({ a: "play", card: code }));
  const others = v.players.flatMap((p, i) => (i === me ? [] : [{ p, i }]));
  return [
    header(title, detail, c.winner >= 0 && c.winner !== me ? "#ff7b72" : c.winner === me ? "#5fd38d" : GOLD),
    {
      type: "grid",
      columns: Math.max(1, others.length),
      fill: true,
      minWidth: 170,
      children: others.map(({ p, i }) => {
        const up = c.winner < 0 && c.turn === i;
        const n = c.hands[i].length;
        return {
          type: "group",
          children: [
            mid({ type: "label", text: `${up ? "▶ " : ""}${p.name}${p.gone ? " (left)" : ""}  ·  ${n} card${n === 1 ? "" : "s"}`, strong: true, color: up ? GOLD : p.gone ? "faint" : undefined }),
            mid(handRow(c.hands[i].slice(0, 7), (code, k) => `o${i}:${k}`, Math.floor(FELT / others.length) - 30, 32, undefined, 12)),
          ],
        };
      }),
    },
    { type: "space", size: 22 },
    mid({
      type: "row",
      children: [
        c.deck
          ? card("", "deck", W, { tooltip: myTurn && !c.drew ? "Draw a card" : `${c.deck} cards left`, selected: myTurn && !c.drew && !pick8, onClick: myTurn && !c.drew && !pick8 ? () => act({ a: "draw" }) : undefined })
          : { type: "label", text: "No cards left", color: "faint" },
        { type: "space", size: 24 },
        card(c.top, "top", W, { tooltip: "The top of the pile" }, "place.ogg"),
        { type: "space", size: 20 },
        {
          type: "column",
          spacing: 2,
          children: [
            { type: "label", text: "Play on", small: true, color: "dim" },
            { type: "button", variant: "icon", label: SUIT_GLYPH[c.suit], size: 44, color: SUIT_COLOR[c.suit], tooltip: SUIT_NAME[c.suit] },
          ],
        },
      ],
    }),
    { type: "space", size: 22 },
    // One slot for whichever controls apply, of fixed height so your hand doesn't jump.
    pick8
      ? mid({
          type: "row",
          children: [
            { type: "label", text: "Name a suit:", strong: true },
            ...[...SUITS].map((su) => ({ type: "button", variant: "icon", label: SUIT_GLYPH[su], size: 34, color: SUIT_COLOR[su], fill: "#1f4d39", radius: 10, tooltip: SUIT_NAME[su], onClick: () => (act({ a: "play", card: pick8, suit: su }), (pick8 = null)) })),
            pill("Cancel", () => (pick8 = null)),
          ],
        })
      : myTurn && c.drew ? mid(pill("Pass", () => act({ a: "pass" })))
      : c.winner >= 0 ? mid(nextButtons(v, host, "ce", "Play again", "Waiting for the host..."))
      : { type: "space", size: 34 },
    { type: "space", size: 10 },
    me >= 0 && mid({ type: "label", text: `Your hand  ·  ${hand.length} card${hand.length === 1 ? "" : "s"}`, color: "dim" }),
    // Your own cards are keyed by card, so playing one doesn't re-deal the rest.
    me >= 0 && mid(handRow(hand, (code) => `h:${code}`, FELT, W, (code) => ({ selected: playable(code), tooltip: playable(code) ? (code[0] === "8" ? "Play this 8 and name a suit" : "Play this card") : undefined, onClick: playable(code) ? () => play(code) : undefined }))),
    { type: "space", size: 14 },
    mid({ type: "label", text: "Match the suit or rank of the top card. Eights are wild: play one on anything and name the suit. Can't go? Draw one, then play it or pass. First to empty their hand wins.", small: true, color: "faint" }),
  ];
};

const jdView = (v, me, host) => {
  const j = v.jd;
  const myTurn = me >= 0 && turnOf(v) === me;
  const hand = j.hands[me] || [];
  const legal = myTurn && j.stage === "play" ? jdLegal(hand, j.trick) : [];
  const hook = myTurn && j.stage === "bid" ? jdHook(j, me) : -1;
  const top = best(j);
  const leaders = v.players.flatMap((p, i) => (j.scores[i] === top ? [p.name] : []));
  const title =
    j.stage === "over" ? (j.scores[me] === top ? "You won!" : `${leaders.join(" and ")} won`)
    : j.stage === "scored" ? (me < 0 ? "Round over" : j.won[me] === j.bids[me] ? `You made your bid: +${10 + j.bids[me]}` : `You took ${j.won[me]} of the ${j.bids[me]} you bid`)
    : j.stage === "trick" ? `${v.players[j.take].name} takes the trick`
    : myTurn ? (j.stage === "bid" ? "Your bid" : "Your turn")
    : `${v.players[j.turn].name} ${j.stage === "bid" ? "is bidding" : "to play"}`;
  const detail = myTurn ? (j.stage === "bid" ? `How many tricks will you take with these ${j.size}?` : j.trick.length ? "Follow suit if you can" : "Lead any card") : v.log;
  const tint = j.stage === "over" && me >= 0 ? (j.scores[me] === top ? "#5fd38d" : "#ff7b72") : GOLD;
  const seat = (p, i) => {
    const up = turnOf(v) === i;
    const bid = j.bids[i] < 0 ? "Bidding..." : `Bid ${j.bids[i]}  ·  took ${j.won[i]}`;
    const made = (j.stage === "scored" || j.stage === "over") && j.bids[i] === j.won[i];
    return {
      type: "group",
      padding: 10,
      children: [
        mid({ type: "label", text: `${up ? "▶ " : ""}${p.name}${i === me ? " (you)" : ""}${i === j.dealer ? "  ·  dealer" : ""}`, strong: true, color: up ? GOLD : p.gone ? "faint" : undefined }),
        mid({ type: "label", text: p.gone ? `Left, playing itself  ·  ${bid}` : bid, small: true, color: made ? "#5fd38d" : "dim" }),
        mid({ type: "label", text: `${j.scores[i]} points`, strong: true, color: j.scores[i] === top && top > 0 ? GOLD : undefined }),
        i !== me && mid(handRow(j.hands[i], (code, k) => `o${i}:${k}`, Math.floor(FELT / v.players.length) - 20, 26, undefined, 10)),
      ],
    };
  };
  // The trick in the middle, each card over its player's name; empty, a column of the same height. No `mid` in here:
  // a bar takes the whole width, which would push the rest of the row off the window.
  const TW = 80;
  const trick = j.trick.length
    ? j.trick.map((t) => ({
        type: "column",
        spacing: 4,
        children: [card(t.card, `t:${t.pi}`, TW, { tooltip: v.players[t.pi].name }, "place.ogg"), { type: "label", text: v.players[t.pi].name.slice(0, 12), small: true, strong: t.pi === j.take, color: t.pi === j.take ? GOLD : "dim" }],
      }))
    : [{ type: "column", children: [{ type: "space", size: Math.round(TW * 1.46) + 22 }] }];
  const trumps = { type: "column", spacing: 2, children: [{ type: "label", text: "Trumps", small: true, color: "dim" }, { type: "button", variant: "icon", label: SUIT_GLYPH[j.trump], size: 44, color: SUIT_COLOR[j.trump], tooltip: SUIT_NAME[j.trump] }] };
  const bids = j.bids.reduce((a, b) => a + Math.max(0, b), 0);
  const actions =
    myTurn && j.stage === "bid"
      ? mid({
          type: "row",
          children: [
            { type: "label", text: "Bid:", strong: true },
            ...Array.from({ length: j.size + 1 }, (_, b) => ({ type: "button", variant: "pill", label: String(b), enabled: b !== hook, tooltip: b === hook ? `The dealer may not bid ${b}: the bids would add up to ${j.size}` : `Take exactly ${b} trick${b === 1 ? "" : "s"}`, onClick: () => act({ a: "bid", bid: b }) })),
          ],
        })
      : j.stage === "scored" ? mid(nextButtons(v, host, "jd", "Next round", "Waiting for the host to deal..."))
      : j.stage === "over" ? mid(nextButtons(v, host, "jd", "Play again", "Waiting for the host..."))
      : { type: "space", size: 34 };
  return [
    header(title, detail, tint),
    mid({ type: "label", text: `Round ${j.round + 1} of ${JD_SIZES.length}  ·  ${j.size} card${j.size === 1 ? "" : "s"}  ·  ${j.bids.every((b) => b >= 0) ? `${bids} bid for ${j.size} tricks` : `${SUIT_NAME[j.trump]} are trumps`}`, small: true, color: "dim" }),
    { type: "grid", columns: v.players.length, fill: true, minWidth: 140, children: v.players.map(seat) },
    { type: "space", size: 14 },
    mid({ type: "row", children: [...trick, { type: "space", size: 24 }, trumps] }),
    { type: "space", size: 14 },
    actions,
    { type: "space", size: 10 },
    me >= 0 && mid({ type: "label", text: `Your hand  ·  ${hand.length} card${hand.length === 1 ? "" : "s"}`, color: "dim" }),
    me >= 0 && mid(handRow(hand, (code) => `h:${code}`, FELT, W, (code) => ({ selected: legal.includes(code), tooltip: legal.includes(code) ? "Play this card" : undefined, onClick: legal.includes(code) ? () => act({ a: "play", card: code }) : undefined }))),
    { type: "space", size: 14 },
    mid({ type: "label", text: "Bid the exact number of tricks you'll take; the dealer can't make the bids add up. Follow suit if you can; trumps beat the suit led. Making your bid scores 10 + the bid.", small: true, color: "faint" }),
  ];
};

/** The host's next deal (or another game) once a hand is over; everyone else waits for it. */
const nextButtons = (v, host, game, again, wait) =>
  host
    ? { type: "row", children: [pill(again, () => hostNext(game), { variant: "filled", enabled: game === "bj" || active(v).length >= 2 }), ...Object.entries(GAMES).filter(([g]) => g !== game).map(([g, label]) => pill(label, () => hostNext(g), { enabled: g === "bj" || active(v).length >= 2 }))] }
    : waiting(wait);

/** Under the host's table: players who left, to invite back to their seat, and people to invite to watch. */
const hostTools = (r) => {
  const peers = App.p2p.peers();
  const away = [...r.members.values()].filter((m) => !m.watch && r.keys.indexOf(m.key) > 0 && r.s.players[r.keys.indexOf(m.key)]?.gone);
  const others = peers.filter((p) => !r.members.has(keyOf(p)));
  const full = watchers(r).length >= MAX_WATCHERS;
  return {
    type: "group",
    padding: 14,
    children: [
      { type: "label", text: "Invite back, or to watch", color: "dim", small: true },
      ...away.map((m) => {
        const peer = peers.find((p) => keyOf(p) === m.key);
        return { type: "bar", left: { type: "label", text: `${m.name} left their seat` }, right: m.session ? waiting(`Asking ${m.name}...`) : peer ? pill("Invite back", () => invite(peer)) : { type: "label", text: "Offline", small: true, color: "faint" } };
      }),
      ...watchers(r).map((m) => ({ type: "bar", left: m.open ? { type: "label", text: `👁 ${m.name}` } : waiting(`Asking ${m.name} to watch...`), right: pill("Remove", () => removeMember(m)) })),
      ...others.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: pill("Invite to watch", () => invite(p, true), { enabled: !full }) })),
      !away.length && !others.length && !watchers(r).length && { type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" },
    ],
  };
};

const tableView = (v, me, host, note) => {
  listen(v, me);
  const watching = v.watchers || [];
  return [
    ...(v.game === "bj" ? bjView : v.game === "ce" ? ceView : jdView)(v, me, host),
    note && mid({ type: "label", text: note, small: true, color: "dim" }),
    (me < 0 || watching.length) && mid({ type: "label", text: `${me < 0 ? "You're watching  ·  " : ""}👁 ${watching.length} watching${watching.length ? `: ${watching.join(", ")}` : ""}`, small: true, color: "dim" }),
    host && inviting && room?.host && hostTools(room),
  ];
};

const requestView = (req) => ({
  type: "group",
  padding: 14,
  children: [
    {
      type: "bar",
      left: { type: "column", spacing: 2, children: [{ type: "label", text: `${req.name} invites you to play cards`, strong: true, color: GOLD }, { type: "label", text: `Accepting lets them see your IP address, unless "relay only" is on in Settings > Plugins.`, small: true, color: "dim" }] },
      right: [pill("Decline", () => decline(req)), pill("Accept", () => accept(req), { variant: "filled" })],
    },
  ],
});

const GAME_NOTES = { bj: "Everyone plays the dealer. 1 to 4 players.", ce: "Match suit or rank, eights are wild. 2 to 4 players.", jd: "Bid the tricks you'll take, then take exactly that many. 2 to 4 players." };
/** A static fan of cards over the felt: what this window is, before anything is dealt. */
const fan = () => mid({ type: "row", children: ["AS", "KH", "QD", "JC"].map((code) => ({ type: "video", stream: pic(code), controls: false, width: 78, height: 114, text: " " })) });
/** The four seats: who sits in each (a node, with what goes on its right), the rest open. */
const seats = (taken) => ({
  type: "group",
  padding: 14,
  children: [
    { type: "label", text: "At the table", color: "dim", small: true },
    ...[0, 1, 2, 3].map((k) => (taken[k] ? { type: "bar", left: taken[k][0], right: taken[k][1] } : { type: "bar", left: { type: "label", text: "Open seat", color: "faint" } })),
  ],
});
/** `seats`: whether there's a seat left to invite to; anyone can be invited to watch. */
const peersView = (peers, seats = true) => ({
  type: "group",
  padding: 14,
  children: [
    { type: "label", text: "People you can invite", color: "dim", small: true },
    ...(peers.length
      ? peers.map((p) => ({ type: "bar", left: { type: "label", text: p.name }, right: [pill("To watch", () => invite(p, true), { tooltip: "Invite them to watch, without a seat" }), seats && pill("To play", () => invite(p), { variant: "filled" })] }))
      : [{ type: "label", text: "Nobody else on your servers runs TeamSpeak Desktop with P2P right now.", color: "faint" }]),
  ],
});
/** A screen with one thing going on (connecting, a message), in the middle of the felt. */
const notice = (node, button) => [{ type: "space", size: 60 }, fan(), { type: "space", size: 18 }, mid(node), { type: "space", size: 10 }, mid(button)];

const hostLobby = (r) => {
  const ms = seated(r);
  const statusOf = (m) => App.p2p.sessions().find((x) => x.id === m.session)?.status;
  const peers = App.p2p.peers().filter((p) => !r.members.has(keyOf(p)));
  const ready = canStart(r);
  const pickGame = (g) => (r.s.game = g) && broadcast();
  const ws = watchers(r);
  return [
    header("Your table", ms.length ? "Deal once everyone has connected" : "Invite up to three people, or play Blackjack alone", GOLD),
    { type: "space", size: 14 },
    mid({ type: "row", children: Object.entries(GAMES).map(([g, label]) => ({ type: "button", variant: "pill", label, selected: r.s.game === g, onClick: () => pickGame(g) })) }),
    mid({ type: "label", text: GAME_NOTES[r.s.game], small: true, color: "dim" }),
    { type: "space", size: 14 },
    seats([
      [{ type: "label", text: `${myName()} (you)`, strong: true }, { type: "label", text: "Host", small: true, color: "dim" }],
      ...ms.map((m) => [m.open ? { type: "label", text: m.name } : waiting(statusOf(m) === "waiting" ? `Waiting for ${m.name} to accept...` : `Connecting to ${m.name}...`), pill("Remove", () => removeMember(m))]),
    ]),
    ws.length > 0 && {
      type: "group",
      padding: 14,
      children: [{ type: "label", text: "Watching", color: "dim", small: true }, ...ws.map((m) => ({ type: "bar", left: m.open ? { type: "label", text: `👁 ${m.name}` } : waiting(`Asking ${m.name} to watch...`), right: pill("Remove", () => removeMember(m)) }))],
    },
    r.note && mid({ type: "label", text: r.note, small: true, color: "dim" }),
    { type: "space", size: 10 },
    mid(pill(ms.length ? "Deal" : "Play alone", start, { variant: "filled", enabled: ready })),
    !ready && mid({ type: "label", text: ms.length ? "Waiting for everyone to connect..." : `${GAMES[r.s.game]} needs at least one more player.`, small: true, color: "faint" }),
    { type: "space", size: 14 },
    peersView(peers, ms.length < 3),
  ];
};

const render = () => {
  now = Date.now();
  frame++;
  busy = false;
  const out = body();
  pruneSlots();
  ticking(busy);
  return out;
};
const body = () => {
  const reqs = [...requests.values()].map(requestView);
  if (!room) (slots = new Map()), (heard.round = 0), (pick8 = null), (confirming = false), (inviting = false);
  if (!room)
    return [
      ...reqs,
      { type: "bar", right: muteButton() },
      { type: "space", size: 20 },
      fan(),
      { type: "space", size: 18 },
      mid({ type: "heading", text: "Card Table" }),
      mid({ type: "label", text: "Blackjack against the dealer, alone or with up to three others; Crazy Eights and Judgement for 2 to 4.", color: "dim" }),
      mid({ type: "label", text: "Everyone needs Card Table installed.", small: true, color: "faint" }),
      { type: "space", size: 12 },
      mid(pill("Open a table", () => (room = lobby()), { variant: "filled" })),
      { type: "space", size: 24 },
      peersView(App.p2p.peers()),
    ];
  if (room.host) return [...reqs, ...(room.s.phase === "lobby" ? hostLobby(room) : tableView(viewFor(room.s, 0), 0, true, room.note))];
  const r = room;
  // The host gone: the table is closed, whatever was on it.
  if (!r.session) return [...reqs, ...notice({ type: "label", text: r.note, color: "dim" }, pill(r.v ? "Close" : "Back", leave))];
  if (!r.open && r.session) return [...reqs, ...notice(waiting(`Connecting to ${r.name}...`), pill("Cancel", leave))];
  if (!r.v) return [...reqs, ...notice(waiting(`Joining ${r.name}'s table...`), pill("Cancel", leave))];
  if (r.v.phase === "lobby")
    return [
      ...reqs,
      header(`${r.name}'s table`, `${GAMES[r.v.game]}  ·  ${GAME_NOTES[r.v.game]}`, GOLD),
      { type: "space", size: 14 },
      seats(r.v.players.map((p, i) => [{ type: "label", text: p.name, strong: i === 0 }, i === 0 && { type: "label", text: "Host", small: true, color: "dim" }])),
      r.v.watchers?.length > 0 && mid({ type: "label", text: `👁 Watching: ${r.v.watchers.join(", ")}`, small: true, color: "dim" }),
      { type: "space", size: 14 },
      mid(waiting(r.you < 0 ? "You'll watch once the host deals..." : "Waiting for the host to deal...")),
    ];
  return [...reqs, ...tableView(r.v, r.you, false, r.note)];
};

// Its own felt-table look, whatever the app's theme.
App.ui.registerWindow({
  id: "cards",
  title: "Card Table",
  width: 720,
  height: 900,
  colors: { bg: "#0d2417", text: "#f1f5f2", accent: GOLD, surface: "#123322", surfaceHigh: "#184030", surfaceHighest: "#1f4d39", outline: "#2b5c45", textDim: "#b5c9bd", textFaint: "#7d9888" },
  background: "pictures/table.png",
  render,
});
const menuButton = () => App.ui.registerMenu({ id: "cards", label: "Card Table", icon: "🃏", active: App.ui.isOpen("cards"), onClick: () => App.ui.toggle("cards") });
App.events.on("window.opened", menuButton);
App.events.on("window.closed", (w) => (menuButton(), w?.id === "cards" && ticking(false)));
menuButton();
App.onUnload(leave);
