// Two dark themes, listed in Settings > Appearance beside the built-in ones.
App.theme.register("Dark Red", {
  bg: "#170a0c",
  text: "#f3e6e7",
  accent: "#d23a3a",
  surface: "#1f0d10",
  surfaceHigh: "#2b1216",
  surfaceHighest: "#38181d",
  outline: "#4a2228",
  textDim: "#c4a6aa",
  textFaint: "#8a6a6e",
  link: "#ff8080",
  talking: "#ff4d4d",
  select: "#4a1a21",
  hover: "#2b1216",
});

// True black wherever the app paints a background: OLED pixels stay off.
App.theme.register("OLED Dark", {
  bg: "#000000",
  text: "#e6e6e6",
  accent: "#5b8cff",
  surface: "#000000",
  surfaceHigh: "#0e0e0e",
  surfaceHighest: "#181818",
  outline: "#222222",
  textDim: "#a0a0a0",
  textFaint: "#666666",
  link: "#7aa2ff",
  talking: "#3ddc84",
  select: "#121a2e",
  hover: "#0b0b0b",
});
